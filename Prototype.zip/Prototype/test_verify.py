import re

with open(r'c:\Users\arbax\Downloads\Prototype\app.js', 'r', encoding='utf-8') as f:
    js = f.read()

with open(r'c:\Users\arbax\Downloads\Prototype\index.html', 'r', encoding='utf-8') as f:
    html = f.read()

ids_in_js = set(re.findall(r"getElementById\(['\"](.*?)['\"]\)", js))
print(f"Unique getElementById calls: {len(ids_in_js)}")
missing = [i for i in ids_in_js if f'id="{i}"' not in html]
if missing:
    print("MISSING IDS:", missing)
else:
    print("SUCCESS: ALL getElementById IDs match index.html perfectly!")

classes_in_js = set(re.findall(r"querySelector(All)?\(['\"]\.([a-zA-Z0-9_-]+)['\"]\)", js))
print(f"QuerySelector classes: {len(classes_in_js)}")
missing_classes = [c[1] for c in classes_in_js if c[1] not in html]
if missing_classes:
    print("MISSING CLASSES:", missing_classes)
else:
    print("SUCCESS: ALL querySelector classes exist in index.html!")
