import urllib.request
import re

print("=== CHECKING DEPLOYED NETLIFY SITE ===")

# 1. Check index.html
req = urllib.request.Request('https://vpn-block-prototype.netlify.app/index.html', headers={'User-Agent': 'Mozilla/5.0'})
with urllib.request.urlopen(req) as resp:
    index_html = resp.read().decode('utf-8', errors='ignore')
print(f"Deployed index.html size: {len(index_html):,} bytes")

# 2. Check app.js
req = urllib.request.Request('https://vpn-block-prototype.netlify.app/app.js', headers={'User-Agent': 'Mozilla/5.0'})
with urllib.request.urlopen(req) as resp:
    app_js = resp.read().decode('utf-8', errors='ignore')
print(f"Deployed app.js size: {len(app_js):,} bytes")

# 3. Check reports.html
req = urllib.request.Request('https://vpn-block-prototype.netlify.app/reports.html', headers={'User-Agent': 'Mozilla/5.0'})
with urllib.request.urlopen(req) as resp:
    reports_html = resp.read().decode('utf-8', errors='ignore')
print(f"Deployed reports.html size: {len(reports_html):,} bytes")

print("\n--- APP.JS INSPECTION ---")
netflix_idx = app_js.find("'netflix.com': {")
if netflix_idx != -1:
    print("Found 'netflix.com': { in app.js:")
    print(app_js[netflix_idx:netflix_idx+400])
else:
    print("NOT FOUND 'netflix.com': { in app.js")

print("\n--- REPORTS.HTML INSPECTION ---")
if 'c:\\Users' in reports_html or 'reports.json' in reports_html:
    print("WARNING: Found filesystem or reports.json in reports.html!")
    for l in reports_html.splitlines():
        if 'c:\\' in l or 'reports.json' in l:
            print("  ", l.strip()[:100])
else:
    print("Clean: No filesystem paths in reports.html")

if 'Live • Checking' in reports_html:
    print("WARNING: Found 'Live • Checking' in reports.html")
else:
    print("Clean: No 'Live • Checking' in reports.html")

res_idx = reports_html.find('id="kpiResolution"')
if res_idx != -1:
    print("kpiResolution markup:", repr(reports_html[res_idx:res_idx+60]))

print("\n--- SECURITY HEADERS INSPECTION ---")
with urllib.request.urlopen(req) as resp:
    for k, v in resp.headers.items():
        print(f"  {k}: {v}")
