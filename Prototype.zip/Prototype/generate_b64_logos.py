import os
import base64
import json

icons = {
    'netflix.com': 'logos/netflix.png',
    'ticketmaster.com': 'logos/ticketmaster.png',
    'chatgpt.com': 'logos/chatgpt.png',
    'github.com': 'logos/github.png',
    'hulu.com': 'logos/hulu.png',
    'coinbase.com': 'logos/coinbase.png',
    'disneyplus.com': 'logos/disneyplus.png',
    'spotify.com': 'logos/spotify.png',
    'amazon.com': 'logos/amazon.png',
    'nordvpn': 'logos/nordvpn.png',
    'expressvpn': 'logos/expressvpn.png',
    'surfshark': 'logos/surfshark.png',
    'protonvpn': 'logos/protonvpn.png'
}

b64_dict = {}
for key, path in icons.items():
    if os.path.exists(path):
        with open(path, 'rb') as f:
            b64 = base64.b64encode(f.read()).decode('utf-8')
            mime = 'image/png'
            b64_dict[key] = f"data:{mime};base64,{b64}"
            print(f"Loaded {key:18} -> {len(b64)} chars")
    else:
        print(f"Warning: {path} not found")

with open('b64_logos.json', 'w') as f:
    json.dump(b64_dict, f, indent=2)

print("\nSaved b64_logos.json successfully!")
