import re
import os

print("="*60)
print("COMPREHENSIVE FINAL AUDIT AGAINST INSTRUCTIONS 1 & 1A")
print("="*60)

with open("app.js", "r", encoding="utf-8") as f:
    app_js = f.read()

with open("index.html", "r", encoding="utf-8") as f:
    index_html = f.read()

with open("reports.html", "r", encoding="utf-8") as f:
    reports_html = f.read()

with open("styles.css", "r", encoding="utf-8") as f:
    styles_css = f.read()

with open("server.py", "r", encoding="utf-8") as f:
    server_py = f.read()

audit_failed = False

def check(condition, desc):
    global audit_failed
    if condition:
        print(f" [PASS] {desc}")
    else:
        print(f" [FAIL] {desc}")
        audit_failed = True

# 1. Prohibited motive words in app.js
motive_words = ['licensing', 'fraud prevention', ' anti-fraud', 'aml', 'anti-scalp', 'broadcast agreements', 'blocks vpn connections']
found_motives = []
for w in motive_words:
    if re.search(r'\b' + re.escape(w) + r'\b', app_js, re.IGNORECASE):
        found_motives.append(w)
check(len(found_motives) == 0, f"No unsupported motive statements in app.js (Found: {found_motives})")

# 2. Measurement contradictions (Working (Not measured))
contradiction = "Working (Not measured)"
check(contradiction not in app_js and contradiction not in index_html, "No 'Working (Not measured)' contradiction")

# 3. Text glitch check: ( Not measured ) or redundant parentheses
check("(Not measured)" not in index_html, "No redundant '(Not measured)' in index.html")
check("controlLatencyText" not in app_js, "No controlLatencyText element in app.js")
check("controlLatencyText" not in index_html, "No controlLatencyText element in index.html")

# 4. Footer removal check in index.html
check("<footer class=\"site-footer-simple\">" not in index_html, "Unnecessary prototype footer removed from index.html")
check("Prototype V0.5)" not in index_html, "No 'Prototype V0.5)' footer in index.html")

# 5. Technical example data clearly labelled
check("Illustrative Telemetry Schema" in index_html and "Sample Fields (Not Live Measurements)" in index_html, "Technical accordion clearly labelled as illustrative schema")
check("(SAMPLE FIELD)" in index_html, "Telemetry cells have (SAMPLE FIELD) tags")
check("(PLANNED SCHEMA)" in index_html, "Probe node cell has (PLANNED SCHEMA) tag")

# 6. Reports Log truthfulness
check("Live • Checking for new reports" not in reports_html, "No unsupported 'Live • Checking' in reports.html")
check("c:\\Users\\arbax" not in reports_html, "No Windows filesystem paths in reports.html UI")
check("c:/Users/arbax" not in reports_html, "No unix-style Windows paths in reports.html UI")
check("Storage Mode: Prototype Demonstration Storage" in reports_html, "Reports storage badge uses honest prototype storage label")

# 7. Zero-data metric in reports.html
check('id="kpiResolution">&mdash;</div>' in reports_html, "Initial markup for Disconnect Resolution is &mdash;")
check('id="kpiResolutionSub">No data yet</div>' in reports_html, "Initial markup subtext is 'No data yet'")
check("kpiResolution.textContent = '—'" in reports_html, "JS zero-data handler sets '—'")

# 8. Report persistence accuracy in app.js
check("async function submitReport" in app_js or "addEventListener('submit', async" in app_js, "Report submission is async")
check("Your report has been recorded in prototype server storage." in app_js, "Success message reflects confirmed server storage without developer artifacts")
check("saved locally in browser demonstration storage" in app_js, "Fallback reflects browser demonstration cache")

# 9. Demo provider language
check("historical observation scenarios" not in index_html, "Removed 'historical observation scenarios' in index.html")
check("Illustrative compatibility example / Demo profile" in index_html, "Using approved 'Illustrative compatibility example / Demo profile'")

# 10. Future architecture terminology
check("commercial residential proxies" not in index_html.lower(), "No commercial residential proxy wording in index.html")
check("owned/consented ordinary-user baseline control" in index_html.lower(), "Uses 'owned/consented ordinary-user baseline control' in index.html")

# 11. Robots meta tag
check('<meta name="robots" content="noindex, nofollow">' in index_html, "noindex meta tag present in index.html")
check('<meta name="robots" content="noindex, nofollow">' in reports_html, "noindex meta tag present in reports.html")

# 12. Security headers in server.py
check("Content-Security-Policy" in server_py, "CSP header configured in server.py")
check("X-Content-Type-Options" in server_py, "nosniff header configured in server.py")
check("X-Frame-Options" in server_py, "DENY header configured in server.py")
check("Referrer-Policy" in server_py, "no-referrer header configured in server.py")
check("Permissions-Policy" in server_py, "Permissions-Policy header configured in server.py")

# 13. Third-party domain query leakage check
check("google.com/s2/favicons" not in app_js, "Zero third-party favicon query leakage in app.js")

# 14. Keyboard modal accessibility
check("Escape" in app_js, "Escape key closes reportModal in app.js")

# 15. Standalone bundles up to date
bundle_local = "bundled_preview.html"
bundle_art = r"C:\Users\arbax\.gemini\antigravity\brain\3032b61f-a6cf-4a18-af31-464b02d2c35f\vpn-access-check.html"
check(os.path.exists(bundle_local), "Local bundled preview exists")
check(os.path.exists(bundle_art), "Artifact bundled preview exists")
with open(bundle_local, "r", encoding="utf-8") as f:
    bundle_text = f.read()
check("<footer class=\"site-footer-simple\">" not in bundle_text, "Footer is removed from bundled preview as well")
check("controlLatencyText" not in bundle_text, "controlLatencyText is removed from bundle as well")

print("="*60)
if audit_failed:
    print("AUDIT FAILED - CORRECTIONS NEEDED")
    exit(1)
else:
    print("ALL AUDIT CHECKS PASSED WITH 100% COMPLIANCE!")
    exit(0)
