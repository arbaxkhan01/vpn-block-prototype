import json

transcript_path = r'C:\Users\arbax\.gemini\antigravity\brain\3032b61f-a6cf-4a18-af31-464b02d2c35f\.system_generated\logs\transcript.jsonl'
with open(transcript_path, 'r', encoding='utf-8') as f:
    for i, line in enumerate(f):
        if 'netlify' in line.lower():
            try:
                obj = json.loads(line)
                tc = obj.get('tool_calls', [])
                for t in tc:
                    if 'command' in str(t).lower() or 'netlify' in str(t).lower():
                        print(f"Line {i+1} Tool Call: {t.get('parameters', {})}")
                content = obj.get('content', '')
                if 'deploy' in content.lower():
                    print(f"Line {i+1} Content: {content[:150]}")
            except Exception as e:
                pass
