import os
import subprocess
import shutil

chrome = r"C:\Program Files\Google\Chrome\Application\chrome.exe"
if not os.path.exists(chrome):
    chrome = r"C:\Program Files (x86)\Google\Chrome\Application\chrome.exe"

proto_dir = r"c:\Users\arbax\Downloads\Prototype"
artifact_dir = r"C:\Users\arbax\.gemini\antigravity\brain\3032b61f-a6cf-4a18-af31-464b02d2c35f"
os.makedirs(artifact_dir, exist_ok=True)

html_content = """<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>VPN Access Check — Product Whitepaper &amp; Diagnostic Trust Framework</title>
  <style>
    @page {
      size: A4 portrait;
      margin: 12mm 14mm 12mm 14mm;
      @bottom-right {
        content: counter(page);
        font-size: 8.5px;
        color: #94a3b8;
        font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif;
      }
    }
    * { box-sizing: border-box; margin: 0; padding: 0; }
    body {
      font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, Helvetica, Arial, sans-serif;
      color: #0f172a;
      background: #ffffff;
      line-height: 1.45;
      font-size: 9.5px;
    }
    .cover-page {
      min-height: 88vh;
      display: flex;
      flex-direction: column;
      justify-content: space-between;
      padding: 24px 8px;
    }
    .cover-header {
      border-left: 6px solid #2563eb;
      padding-left: 20px;
      margin-top: 36px;
    }
    .cover-badge {
      display: inline-block;
      background: #eff6ff;
      color: #1d4ed8;
      font-weight: 700;
      font-size: 10px;
      padding: 4px 10px;
      border-radius: 4px;
      text-transform: uppercase;
      letter-spacing: 0.5px;
      margin-bottom: 12px;
      border: 1px solid #bfdbfe;
    }
    h1.cover-title {
      font-size: 25px;
      font-weight: 800;
      color: #0f172a;
      line-height: 1.25;
      margin-bottom: 8px;
    }
    .cover-subtitle {
      font-size: 12.5px;
      color: #475569;
      font-weight: 400;
      max-width: 620px;
      line-height: 1.5;
    }
    .cover-meta-grid {
      display: grid;
      grid-template-columns: repeat(2, 1fr);
      gap: 12px;
      background: #f8fafc;
      border: 1px solid #e2e8f0;
      border-radius: 8px;
      padding: 16px;
      margin: 24px 0;
    }
    .meta-item { display: flex; flex-direction: column; gap: 2px; }
    .meta-label { font-size: 8px; text-transform: uppercase; letter-spacing: 0.5px; color: #64748b; font-weight: 600; }
    .meta-value { font-size: 10.5px; font-weight: 600; color: #0f172a; }
    .cover-summary-box {
      background: #ffffff;
      border: 1px solid #cbd5e1;
      border-radius: 8px;
      padding: 14px 18px;
      box-shadow: 0 1px 3px rgba(0,0,0,0.05);
    }
    .cover-summary-box h3 { font-size: 11px; color: #1e293b; margin-bottom: 6px; font-weight: 700; }
    .cover-summary-box p { font-size: 9.5px; color: #334155; line-height: 1.5; }
    .cover-footer {
      border-top: 1px solid #e2e8f0;
      padding-top: 12px;
      display: flex;
      justify-content: space-between;
      color: #94a3b8;
      font-size: 8.5px;
    }
    .page-break { page-break-before: always; }
    .content-page { padding: 10px 4px; }
    .page-header {
      display: flex;
      justify-content: space-between;
      align-items: center;
      border-bottom: 1px solid #e2e8f0;
      padding-bottom: 8px;
      margin-bottom: 14px;
    }
    .page-header-title { font-size: 9px; font-weight: 700; color: #64748b; text-transform: uppercase; letter-spacing: 0.5px; }
    .page-header-date { font-size: 8.5px; color: #94a3b8; }
    .section { margin-bottom: 16px; }
    h2 {
      font-size: 12.5px;
      font-weight: 700;
      color: #0f172a;
      margin-bottom: 8px;
      padding-bottom: 4px;
      border-bottom: 1.5px solid #2563eb;
      display: flex;
      justify-content: space-between;
      align-items: center;
    }
    h3 { font-size: 10.5px; font-weight: 700; color: #1e293b; margin: 10px 0 4px 0; }
    p { margin-bottom: 8px; color: #334155; line-height: 1.5; }
    ul, ol { margin-left: 16px; margin-bottom: 8px; color: #334155; }
    li { margin-bottom: 4px; line-height: 1.45; }
    code {
      font-family: ui-monospace, SFMono-Regular, Menlo, monospace;
      font-size: 8.5px;
      background: #f1f5f9;
      padding: 1.5px 4px;
      border-radius: 3px;
      color: #0f172a;
      border: 1px solid #e2e8f0;
    }
    .table-custom {
      width: 100%;
      border-collapse: collapse;
      margin: 10px 0 14px 0;
      font-size: 8.5px;
    }
    .table-custom th {
      background: #f8fafc;
      color: #475569;
      font-weight: 700;
      text-align: left;
      padding: 6px 8px;
      border: 1px solid #cbd5e1;
      font-size: 8px;
      text-transform: uppercase;
      letter-spacing: 0.3px;
    }
    .table-custom td {
      padding: 5px 8px;
      border: 1px solid #cbd5e1;
      color: #334155;
      vertical-align: top;
    }
    .table-custom tr:nth-child(even) { background: #f8fafc; }
    .badge-pass { display: inline-block; background: #dcfce7; color: #15803d; font-weight: 700; padding: 2px 6px; border-radius: 3px; font-size: 7.5px; border: 1px solid #bbf7d0; }
    .badge-info { display: inline-block; background: #eff6ff; color: #1d4ed8; font-weight: 700; padding: 2px 6px; border-radius: 3px; font-size: 7.5px; border: 1px solid #bfdbfe; }
    .badge-warning { display: inline-block; background: #fffbeb; color: #b45309; font-weight: 700; padding: 2px 6px; border-radius: 3px; font-size: 7.5px; border: 1px solid #fde68a; }
    .callout { background: #f8fafc; border-left: 4px solid #2563eb; padding: 8px 12px; border-radius: 0 6px 6px 0; margin: 10px 0; font-size: 9px; }
    .section-tag { font-size: 7.5px; font-weight: 600; background: #f1f5f9; color: #475569; padding: 2px 6px; border-radius: 3px; text-transform: uppercase; letter-spacing: 0.3px; }
  </style>
</head>
<body>

  <!-- COVER PAGE -->
  <div class="cover-page">
    <div class="cover-header">
      <div class="cover-badge">Product Whitepaper &amp; Trust Architecture</div>
      <h1 class="cover-title">VPN Access Check Platform<br>Product Whitepaper</h1>
      <p class="cover-subtitle">
        Establishing the internet's definitive, independent diagnostic benchmark for VPN egress accessibility, transparent empirical telemetry, and consumer trust.
      </p>
    </div>

    <div class="cover-meta-grid">
      <div class="meta-item">
        <span class="meta-label">Product Vision</span>
        <span class="meta-value">Authoritative, Neutral Diagnostic Benchmark</span>
      </div>
      <div class="meta-item">
        <span class="meta-label">Primary Philosophy</span>
        <span class="meta-value">Truthfulness Over Simulation &bull; Zero Fabricated Telemetry</span>
      </div>
      <div class="meta-item">
        <span class="meta-label">Target Audience</span>
        <span class="meta-value">Global VPN Users, Network Engineers &amp; Industry Analysts</span>
      </div>
      <div class="meta-item">
        <span class="meta-label">Roadmap Stage</span>
        <span class="meta-value">Prototype V0.5 Transitioning to Alpha Measurement Pilot</span>
      </div>
    </div>

    <div class="cover-summary-box">
      <h3>Executive Summary</h3>
      <p>
        For two decades, internet access diagnostics have operated on an outdated assumption: that web connectivity is binary (either a site is online or offline). In today's threat landscape, edge security filters and content distribution platforms enforce sophisticated, silent access controls based on source IP classification. Over 1.6 billion VPN users routinely encounter access degradation, confusing WAF blocks with website outages.
      </p>
      <p style="margin-top: 6px;">
        VPN.com is engineering the <strong>VPN Access Check Platform</strong> to establish the first transparent, objective, and scientifically grounded reference utility. By decoupling origin reachability from VPN egress performance and replacing opaque affiliate rankings with verifiable evidence, the platform delivers immediate clarity to consumers and actionable telemetry to network operators.
      </p>
    </div>

    <div class="cover-footer">
      <span>VPN.com Prototype Development &bull; Product Whitepaper</span>
      <span>Document Ref: VPN-WP-V05-2026</span>
    </div>
  </div>

  <!-- PAGE BREAK: CONTENT -->
  <div class="page-break"></div>
  <div class="content-page">
    <div class="page-header">
      <span class="page-header-title">Product Whitepaper &bull; Trust Architecture &amp; Methodology</span>
      <span class="page-header-date">September 29, 2026</span>
    </div>

    <div class="section">
      <h2>1. The Core Problem: The Internet's Invisible Walls <span class="section-tag">Problem Space</span></h2>
      <p>
        The modern web is increasingly walled. While firewalls and bot management platforms protect web assets from automated threats, they inadvertently penalize legitimate users connecting through privacy-preserving VPNs:
      </p>
      <ul>
        <li><strong>Silent Rejection</strong>: TCP packets are silently dropped or met with HTTP 403 Forbidden screens without explaining why.</li>
        <li><strong>Cognitive Friction</strong>: Users cycle through endless CAPTCHA grids or step-up verification prompts.</li>
        <li><strong>Security Degradation</strong>: Frustrated users disconnect their VPN, exposing their domestic IP and unencrypted DNS requests to local networks and commercial trackers.</li>
      </ul>
      <p>
        Until now, users had no objective tool to answer the fundamental question: <em>"Is this website down for everyone, or is my VPN being blocked?"</em>
      </p>
    </div>

    <div class="section">
      <h2>2. The Diagnostic Trust Framework <span class="section-tag">Core Principles</span></h2>
      <p>
        The platform adheres to four inviolable engineering and product principles:
      </p>
      <table class="table-custom">
        <thead>
          <tr>
            <th style="width: 25%;">Trust Pillar</th>
            <th style="width: 75%;">Implementation Commitment</th>
          </tr>
        </thead>
        <tbody>
          <tr>
            <td><strong>1. Truthfulness Over Simulation</strong></td>
            <td>A user must never reasonably interpret simulated data as a real measurement. In prototype mode, demonstration profiles are clearly identified with disclosures, and custom domains truthfully state that live testing is not connected.</td>
          </tr>
          <tr>
            <td><strong>2. Independent Domain Model</strong></td>
            <td>Website Status, VPN Accessibility, and Evidence Strength are evaluated independently. An origin outage is never conflated with a VPN restriction. If a site is down, VPN accessibility strictly displays: <code>Unknown / Not Measurable</code>.</td>
          </tr>
          <tr>
            <td><strong>3. Provisional Evidence Strength</strong></td>
            <td>Rather than prematurely publishing arbitrary A–F letter grades or 0–100 scores before scientific validation is complete, the platform utilizes provisional evidence labels (<code>Insufficient evidence</code> &rarr; <code>Strong evidence</code>) based on observation density.</td>
          </tr>
          <tr>
            <td><strong>4. Calibrated Baseline Controls</strong></td>
            <td>Differential measurements are calibrated against <strong>owned/consented ordinary-user baseline controls</strong>, strictly prohibiting the use of commercial residential proxy networks.</td>
          </tr>
        </tbody>
      </table>
    </div>

    <div class="section">
      <h2>3. Actionable User Guidance: The Dual-Track Framework <span class="section-tag">UX Design</span></h2>
      <p>
        When a VPN restriction is diagnosed, the platform provides clear, non-motive, dual-track actionable guidance:
      </p>
      <ul>
        <li><strong>Option 1: Quick Fix (Immediate In-Session Resolution)</strong>: Concrete technical actions the user can take immediately (e.g., disconnecting and reconnecting to obtain a different egress IP address, switching server protocols, or clearing browser cache).</li>
        <li><strong>Option 2: Alternative Configuration (Long-Term Reliability)</strong>: Information regarding VPN configurations, specialized server ranges, or providers that maintain verified compatibility with the target service.</li>
      </ul>
    </div>

    <div class="section">
      <h2>4. Strategic Product Roadmap <span class="section-tag">Roadmap</span></h2>
      <table class="table-custom">
        <thead>
          <tr>
            <th>Milestone Phase</th>
            <th>Primary Objective</th>
            <th>Deliverables &amp; Status</th>
          </tr>
        </thead>
        <tbody>
          <tr>
            <td><strong>Phase 1: Prototype V0.5</strong></td>
            <td>UX Architecture &amp; Parity Gate</td>
            <td>Responsive SPA, truthful demonstration profiles, crowdsourced intake, edge security headers. <span class="badge-pass">ACTIVE &bull; COMPLETE</span></td>
          </tr>
          <tr>
            <td><strong>Phase 2: Alpha Measurement Pilot</strong></td>
            <td>Live Differential Engine Validation</td>
            <td>Connecting owned baseline nodes, automated WireGuard multi-egress probes, and live REST API. <span class="badge-info">PLANNED (Instructions 2)</span></td>
          </tr>
          <tr>
            <td><strong>Phase 3: Global Sensor Grid</strong></td>
            <td>Scale &amp; Coverage</td>
            <td>Multi-region egress nodes (15+ countries), real-time challenge classification, enterprise feed. <span class="badge-warning">ROADMAP</span></td>
          </tr>
        </tbody>
      </table>
    </div>
  </div>

</body>
</html>
"""

html_file = os.path.join(proto_dir, "VPN_Access_Check_Product_Whitepaper.html")
pdf_local = os.path.join(proto_dir, "VPN_Access_Check_Product_Whitepaper.pdf")
pdf_artifact = os.path.join(artifact_dir, "VPN_Access_Check_Product_Whitepaper.pdf")

with open(html_file, "w", encoding="utf-8") as f:
    f.write(html_content)

cmd = [
    chrome,
    "--headless=new",
    "--disable-gpu",
    "--no-pdf-header-footer",
    f"--print-to-pdf={pdf_local}",
    html_file
]
subprocess.run(cmd, check=True)
shutil.copy2(pdf_local, pdf_artifact)

size = os.path.getsize(pdf_local)
print(f"[OK] Compiled: VPN_Access_Check_Product_Whitepaper.pdf ({size:,} bytes)")
