import urllib.request

req = urllib.request.Request('https://vpn-block-prototype.netlify.app/index.html', headers={'User-Agent': 'Mozilla/5.0'})
with urllib.request.urlopen(req) as resp:
    index_html = resp.read().decode('utf-8', errors='ignore')

print("=== CHECKING NETLIFY INDEX.HTML ===")
for line in index_html.splitlines():
    if 'netflix' in line.lower() or 'blocks vpn' in line.lower() or 'catalog' in line.lower() or 'licensing' in line.lower():
        print("  -->", line.strip()[:100])
