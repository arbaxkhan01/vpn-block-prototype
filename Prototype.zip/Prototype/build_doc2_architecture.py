import os
import subprocess
import shutil

chrome = r"C:\Program Files\Google\Chrome\Application\chrome.exe"
if not os.path.exists(chrome):
    chrome = r"C:\Program Files (x86)\Google\Chrome\Application\chrome.exe"

proto_dir = r"c:\Users\arbax\Downloads\Prototype"
artifact_dir = r"C:\Users\arbax\.gemini\antigravity\brain\3032b61f-a6cf-4a18-af31-464b02d2c35f"
os.makedirs(artifact_dir, exist_ok=True)

html_content = """<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>VPN Access Check — System &amp; Infrastructure Architecture Specification</title>
  <style>
    @page {
      size: A4 portrait;
      margin: 12mm 14mm 12mm 14mm;
      @bottom-right {
        content: counter(page);
        font-size: 8.5px;
        color: #94a3b8;
        font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif;
      }
    }
    * { box-sizing: border-box; margin: 0; padding: 0; }
    body {
      font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, Helvetica, Arial, sans-serif;
      color: #0f172a;
      background: #ffffff;
      line-height: 1.45;
      font-size: 9.5px;
    }
    .cover-page {
      min-height: 88vh;
      display: flex;
      flex-direction: column;
      justify-content: space-between;
      padding: 24px 8px;
    }
    .cover-header {
      border-left: 6px solid #2563eb;
      padding-left: 20px;
      margin-top: 36px;
    }
    .cover-badge {
      display: inline-block;
      background: #eff6ff;
      color: #1d4ed8;
      font-weight: 700;
      font-size: 10px;
      padding: 4px 10px;
      border-radius: 4px;
      text-transform: uppercase;
      letter-spacing: 0.5px;
      margin-bottom: 12px;
      border: 1px solid #bfdbfe;
    }
    h1.cover-title {
      font-size: 25px;
      font-weight: 800;
      color: #0f172a;
      line-height: 1.25;
      margin-bottom: 8px;
    }
    .cover-subtitle {
      font-size: 12.5px;
      color: #475569;
      font-weight: 400;
      max-width: 620px;
      line-height: 1.5;
    }
    .cover-meta-grid {
      display: grid;
      grid-template-columns: repeat(2, 1fr);
      gap: 12px;
      background: #f8fafc;
      border: 1px solid #e2e8f0;
      border-radius: 8px;
      padding: 16px;
      margin: 24px 0;
    }
    .meta-item { display: flex; flex-direction: column; gap: 2px; }
    .meta-label { font-size: 8px; text-transform: uppercase; letter-spacing: 0.5px; color: #64748b; font-weight: 600; }
    .meta-value { font-size: 10.5px; font-weight: 600; color: #0f172a; }
    .cover-summary-box {
      background: #ffffff;
      border: 1px solid #cbd5e1;
      border-radius: 8px;
      padding: 14px 18px;
      box-shadow: 0 1px 3px rgba(0,0,0,0.05);
    }
    .cover-summary-box h3 { font-size: 11px; color: #1e293b; margin-bottom: 6px; font-weight: 700; }
    .cover-summary-box p { font-size: 9.5px; color: #334155; line-height: 1.5; }
    .cover-footer {
      border-top: 1px solid #e2e8f0;
      padding-top: 12px;
      display: flex;
      justify-content: space-between;
      color: #94a3b8;
      font-size: 8.5px;
    }
    .page-break { page-break-before: always; }
    .content-page { padding: 10px 4px; }
    .page-header {
      display: flex;
      justify-content: space-between;
      align-items: center;
      border-bottom: 1px solid #e2e8f0;
      padding-bottom: 8px;
      margin-bottom: 14px;
    }
    .page-header-title { font-size: 9px; font-weight: 700; color: #64748b; text-transform: uppercase; letter-spacing: 0.5px; }
    .page-header-date { font-size: 8.5px; color: #94a3b8; }
    .section { margin-bottom: 16px; }
    h2 {
      font-size: 12.5px;
      font-weight: 700;
      color: #0f172a;
      margin-bottom: 8px;
      padding-bottom: 4px;
      border-bottom: 1.5px solid #2563eb;
      display: flex;
      justify-content: space-between;
      align-items: center;
    }
    h3 { font-size: 10.5px; font-weight: 700; color: #1e293b; margin: 10px 0 4px 0; }
    p { margin-bottom: 8px; color: #334155; line-height: 1.5; }
    ul, ol { margin-left: 16px; margin-bottom: 8px; color: #334155; }
    li { margin-bottom: 4px; line-height: 1.45; }
    code {
      font-family: ui-monospace, SFMono-Regular, Menlo, monospace;
      font-size: 8.5px;
      background: #f1f5f9;
      padding: 1.5px 4px;
      border-radius: 3px;
      color: #0f172a;
      border: 1px solid #e2e8f0;
    }
    .table-custom {
      width: 100%;
      border-collapse: collapse;
      margin: 10px 0 14px 0;
      font-size: 8.5px;
    }
    .table-custom th {
      background: #f8fafc;
      color: #475569;
      font-weight: 700;
      text-align: left;
      padding: 6px 8px;
      border: 1px solid #cbd5e1;
      font-size: 8px;
      text-transform: uppercase;
      letter-spacing: 0.3px;
    }
    .table-custom td {
      padding: 5px 8px;
      border: 1px solid #cbd5e1;
      color: #334155;
      vertical-align: top;
    }
    .table-custom tr:nth-child(even) { background: #f8fafc; }
    .badge-pass { display: inline-block; background: #dcfce7; color: #15803d; font-weight: 700; padding: 2px 6px; border-radius: 3px; font-size: 7.5px; border: 1px solid #bbf7d0; }
    .badge-info { display: inline-block; background: #eff6ff; color: #1d4ed8; font-weight: 700; padding: 2px 6px; border-radius: 3px; font-size: 7.5px; border: 1px solid #bfdbfe; }
    .badge-warning { display: inline-block; background: #fffbeb; color: #b45309; font-weight: 700; padding: 2px 6px; border-radius: 3px; font-size: 7.5px; border: 1px solid #fde68a; }
    .callout { background: #f8fafc; border-left: 4px solid #2563eb; padding: 8px 12px; border-radius: 0 6px 6px 0; margin: 10px 0; font-size: 9px; }
    .callout-success { background: #f0fdf4; border-left-color: #16a34a; }
    .callout-warning { background: #fffbeb; border-left-color: #d97706; }
    .section-tag { font-size: 7.5px; font-weight: 600; background: #f1f5f9; color: #475569; padding: 2px 6px; border-radius: 3px; text-transform: uppercase; letter-spacing: 0.3px; }
  </style>
</head>
<body>

  <!-- COVER PAGE -->
  <div class="cover-page">
    <div class="cover-header">
      <div class="cover-badge">System &amp; Infrastructure Architecture</div>
      <h1 class="cover-title">VPN Access Check Platform<br>System Architecture Specification</h1>
      <p class="cover-subtitle">
        Architectural domain model, current V0.5 prototype topology, target production measurement infrastructure, owned/consented baseline calibration, and evidence validation framework.
      </p>
    </div>

    <div class="cover-meta-grid">
      <div class="meta-item">
        <span class="meta-label">Architecture Milestone</span>
        <span class="meta-value">Instructions 1 &amp; 1B Approved Architecture</span>
      </div>
      <div class="meta-item">
        <span class="meta-label">Domain Model</span>
        <span class="meta-value">Three-Pillar Independent Classification</span>
      </div>
      <div class="meta-item">
        <span class="meta-label">Baseline Calibration Standard</span>
        <span class="meta-value">Owned/Consented Ordinary-User Control (No Comm. Proxies)</span>
      </div>
      <div class="meta-item">
        <span class="meta-label">Measurement Validation State</span>
        <span class="meta-value">Prototype V0.5 Demonstration (Production Schema Planned)</span>
      </div>
    </div>

    <div class="cover-summary-box">
      <h3>Architecture Overview &amp; Core Principles</h3>
      <p>
        The VPN Access Check platform introduces an authoritative architectural framework to measure, diagnose, and explain network accessibility across commercial VPN egress networks. Per client instructions, current prototype functionality is strictly separated from planned future production infrastructure. The platform eliminates fabricated measurements, presents demonstration profiles with clear disclosures, and prepares a standardized evidence schema for future live measurement service integration.
      </p>
      <p style="margin-top: 6px;">
        Central to this architecture is the decoupling of three independent operational concepts: <strong>Website Status</strong> (origin reachability), <strong>VPN Accessibility</strong> (egress protocol behavior), and <strong>Evidence Strength</strong> (telemetry observation confidence).
      </p>
    </div>

    <div class="cover-footer">
      <span>VPN.com Prototype Development &bull; System Architecture</span>
      <span>Document Ref: VPN-ARCH-V05-2026</span>
    </div>
  </div>

  <!-- PAGE BREAK: CONTENT -->
  <div class="page-break"></div>
  <div class="content-page">
    <div class="page-header">
      <span class="page-header-title">System Architecture &bull; Domain Model &amp; Prototype Architecture</span>
      <span class="page-header-date">September 29, 2026</span>
    </div>

    <div class="section">
      <h2>1. The Three-Pillar Independent Domain Model <span class="section-tag">Core Domain</span></h2>
      <p>
        Previous industry paradigms conflated general site reachability with VPN-specific blocking. The VPN Access Check architecture enforces a clean separation of three independent entities:
      </p>
      <table class="table-custom">
        <thead>
          <tr>
            <th style="width: 25%;">Domain Pillar</th>
            <th style="width: 35%;">Definition &amp; Operational Scope</th>
            <th style="width: 40%;">Supported Permissible States</th>
          </tr>
        </thead>
        <tbody>
          <tr>
            <td><strong>Pillar 1: Website Status</strong></td>
            <td>Measures whether the target origin server is online, reachable, and responding to baseline network traffic globally, completely independent of VPNs.</td>
            <td>
              &bull; <code>Online (Working)</code>: Host responds cleanly to ordinary traffic.<br>
              &bull; <code>Site Unreachable (Outage)</code>: Host fails DNS, TCP handshake, or returns HTTP 500/503 server errors.
            </td>
          </tr>
          <tr>
            <td><strong>Pillar 2: VPN Accessibility</strong></td>
            <td>Measures whether client traffic routing across commercial VPN exit nodes succeeds or encounters IP-level or protocol-level restrictions.</td>
            <td>
              &bull; <code>Works on VPN</code>: Egress traffic succeeds.<br>
              &bull; <code>VPN Blocked</code>: WAF drops, HTTP 403, or proxy restriction codes.<br>
              &bull; <code>VPN Friction</code>: Elevated CAPTCHA loops or step-up 2FA re-auth.<br>
              &bull; <code>Unknown / Not Measurable</code>: Required state whenever website reachability cannot be established.
            </td>
          </tr>
          <tr>
            <td><strong>Pillar 3: Evidence Strength</strong></td>
            <td>Measures the empirical confidence, observation count, and geographic diversity of the diagnostic data backing the verdict.</td>
            <td>
              &bull; <code>Insufficient evidence</code>: Minimal telemetry.<br>
              &bull; <code>Limited evidence</code>: Sporadic or single-point observations.<br>
              &bull; <code>Moderate evidence</code>: Multiple observations with consistent patterns.<br>
              &bull; <code>Strong evidence</code>: Multi-region, validated observations.
            </td>
          </tr>
        </tbody>
      </table>

      <div class="callout callout-warning">
        <strong>Critical Architectural Invariant:</strong> An origin outage must never automatically produce a negative VPN result. If website reachability cannot be confirmed, VPN Accessibility must strictly transition to <code>Unknown / Not Measurable</code> with <code>Insufficient evidence</code>.
      </div>
    </div>

    <div class="section">
      <h2>2. Current Prototype Architecture (V0.5) <span class="section-tag">Current State</span></h2>
      <p>
        The active V0.5 deployment demonstrates the intended user experience, responsive visual hierarchy, and submission workflow without misrepresenting demonstration data as live measurements:
      </p>
      <ul>
        <li><strong>Single-Page Interface (SPA)</strong>: Fluid, zero-dependency HTML5/CSS3/Vanilla JS architecture supporting all viewports from 360px mobile to 1440px desktop.</li>
        <li><strong>Demonstration Scenario Profiles</strong>: Curated preset examples illustrating distinct interface states (streaming restrictions, WAF bot blocks, challenge friction, developer platforms, and outages) with clear demo disclosures.</li>
        <li><strong>Unknown / Custom Domain Guard</strong>: Arbitrary custom domains strictly return: <em>"Live testing not connected in this prototype"</em> with unpopulated technical schema cells (<code>&mdash;</code>, <code>Not measured</code>).</li>
        <li><strong>Dual-Mode Storage Resilience</strong>: Report submissions record to local server storage when connected, or fall back gracefully to browser local cache (<code>localStorage</code>) on static hosting (Netlify) without false server claims.</li>
        <li><strong>Crawler &amp; Privacy Protection</strong>: Full search engine exclusion via <code>&lt;meta name="robots" content="noindex, nofollow"&gt;</code> and HTTP <code>X-Robots-Tag</code>. Zero third-party favicon query leakage.</li>
      </ul>
    </div>

    <div class="section">
      <h2>3. Target Future Production Infrastructure <span class="section-tag">Future Roadmap</span></h2>
      <p>
        The production measurement architecture will deploy an active, distributed diagnostic engine structured around the following physical components:
      </p>
      <table class="table-custom">
        <thead>
          <tr>
            <th style="width: 25%;">Infrastructure Layer</th>
            <th style="width: 35%;">Target Component</th>
            <th style="width: 40%;">Operational Function</th>
          </tr>
        </thead>
        <tbody>
          <tr>
            <td><strong>Calibration Baseline</strong></td>
            <td><strong>Owned / Consented Ordinary-User Controls</strong></td>
            <td>Dedicated residential control nodes deployed in owned/consented environments to establish authentic, un-flagged baseline web reachability (strictly prohibiting commercial residential proxy networks).</td>
          </tr>
          <tr>
            <td><strong>VPN Probe Network</strong></td>
            <td>Distributed Multi-Provider Exit Nodes</td>
            <td>Containerized probe workers executing automated diagnostic fetches across commercial VPN provider wireguard/openvpn interfaces in North America, Europe, and Asia-Pacific.</td>
          </tr>
          <tr>
            <td><strong>Challenge Classifier</strong></td>
            <td>Edge Fingerprint &amp; WAF Engine</td>
            <td>Detects HTTP 403, 451, Cloudflare Turnstile, Akamai Bot Manager, and PerimeterX challenge tokens to distinguish hard blocks from friction.</td>
          </tr>
          <tr>
            <td><strong>Telemetry Pipeline</strong></td>
            <td>Time-Series Observation Store</td>
            <td>Aggregates probe telemetry, computes freshness windows, and publishes confidence-scored evidence records to public API endpoints.</td>
          </tr>
        </tbody>
      </table>
    </div>
  </div>

</body>
</html>
"""

html_file = os.path.join(proto_dir, "VPN_Access_Check_System_Architecture_Report.html")
pdf_local = os.path.join(proto_dir, "VPN_Access_Check_System_Architecture_Report.pdf")
pdf_artifact = os.path.join(artifact_dir, "VPN_Access_Check_System_Architecture_Report.pdf")

with open(html_file, "w", encoding="utf-8") as f:
    f.write(html_content)

cmd = [
    chrome,
    "--headless=new",
    "--disable-gpu",
    "--no-pdf-header-footer",
    f"--print-to-pdf={pdf_local}",
    html_file
]
subprocess.run(cmd, check=True)
shutil.copy2(pdf_local, pdf_artifact)

size = os.path.getsize(pdf_local)
print(f"[OK] Compiled: VPN_Access_Check_System_Architecture_Report.pdf ({size:,} bytes)")
