import os
import subprocess
import shutil

chrome = r"C:\Program Files\Google\Chrome\Application\chrome.exe"
if not os.path.exists(chrome):
    chrome = r"C:\Program Files (x86)\Google\Chrome\Application\chrome.exe"

proto_dir = r"c:\Users\arbax\Downloads\Prototype"
artifact_dir = r"C:\Users\arbax\.gemini\antigravity\brain\3032b61f-a6cf-4a18-af31-464b02d2c35f"
os.makedirs(artifact_dir, exist_ok=True)

targets = [
    # Responsive viewports for Deployed Netlify Home
    ("screen_netlify_1440.png", "https://vpn-block-prototype.netlify.app/", 1440, 900, 3000),
    ("screen_netlify_1024.png", "https://vpn-block-prototype.netlify.app/", 1024, 768, 3000),
    ("screen_netlify_768.png", "https://vpn-block-prototype.netlify.app/", 768, 1024, 3000),
    ("screen_netlify_430.png", "https://vpn-block-prototype.netlify.app/", 430, 932, 3000),
    ("screen_netlify_390.png", "https://vpn-block-prototype.netlify.app/", 390, 844, 3000),
    ("screen_netlify_360.png", "https://vpn-block-prototype.netlify.app/", 360, 780, 3000),

    # Result views on Netlify
    ("screen_netlify_netflix.png", "https://vpn-block-prototype.netlify.app/?domain=netflix.com", 1280, 900, 4000),
    ("screen_netlify_custom.png", "https://vpn-block-prototype.netlify.app/?domain=myunknownsite.io", 1280, 900, 4000),
    ("screen_netlify_outage.png", "https://vpn-block-prototype.netlify.app/?domain=down-example.test", 1280, 900, 4000),

    # Reports log views on Netlify
    ("screen_netlify_reports.png", "https://vpn-block-prototype.netlify.app/reports", 1440, 900, 3000),
    ("screen_netlify_reports_390.png", "https://vpn-block-prototype.netlify.app/reports", 390, 844, 3000),
    ("screen_netlify_reports_360.png", "https://vpn-block-prototype.netlify.app/reports", 360, 780, 3000),
]

print("Starting screenshot capture of live Netlify deployment...")
for filename, url, width, height, budget in targets:
    out_local = os.path.join(proto_dir, filename)
    out_artifact = os.path.join(artifact_dir, filename)
    cmd = [
        chrome,
        "--headless=new",
        "--disable-gpu",
        f"--virtual-time-budget={budget}",
        f"--window-size={width},{height}",
        f"--screenshot={out_local}",
        url
    ]
    res = subprocess.run(cmd, capture_output=True, text=True)
    if os.path.exists(out_local):
        shutil.copy2(out_local, out_artifact)
        size = os.path.getsize(out_local)
        print(f"[OK] {filename:30} ({width}x{height}) -> {size:,} bytes")
    else:
        print(f"[FAIL] {filename:30} failed to capture! Return code: {res.returncode}")

print("\nNetlify screenshot capture process complete!")
