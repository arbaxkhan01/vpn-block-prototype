import urllib.request
import ssl

ctx = ssl.create_default_context()

print("="*60)
print("AUDITING LIVE DEPLOYED NETLIFY SITE")
print("https://vpn-block-prototype.netlify.app/")
print("="*60)

req = urllib.request.Request('https://vpn-block-prototype.netlify.app/', headers={'User-Agent': 'Mozilla/5.0'})
with urllib.request.urlopen(req, context=ctx) as resp:
    print(f"Root HTTP Status: {resp.status}")
    headers = dict(resp.headers)
    print("Response Headers:")
    for h in ['x-robots-tag', 'content-security-policy', 'x-frame-options', 'x-content-type-options', 'referrer-policy', 'permissions-policy']:
        val = headers.get(h) or headers.get(h.title())
        print(f"  {h}: {val}")
    html = resp.read().decode('utf-8', errors='ignore')

print("\n--- HTML Content Verifications ---")
print(f"HTML Size: {len(html):,} bytes")
has_old_netflix = 'Netflix is online, but it blocks VPN connections' in html
has_motive = ('enforce region' in html) or ('regional catalog' in html)
has_new_scenario = 'Example Scenario: Illustrating a streaming restriction diagnosis' in html
has_footer = 'site-footer-simple' in html
has_meta_robots = '<meta name="robots" content="noindex, nofollow">' in html

print(f"Old 'Netflix blocks VPN' removed: {not has_old_netflix} (Found: {has_old_netflix})")
print(f"Motive claims removed: {not has_motive} (Found: {has_motive})")
print(f"Approved 'Example Scenario' present: {has_new_scenario}")
print(f"Unrequested footer removed: {not has_footer} (Found: {has_footer})")
print(f"Meta robots noindex present: {has_meta_robots}")

print("\n--- Reports Page Verification (https://vpn-block-prototype.netlify.app/reports) ---")
try:
    req_rep = urllib.request.Request('https://vpn-block-prototype.netlify.app/reports', headers={'User-Agent': 'Mozilla/5.0'})
    with urllib.request.urlopen(req_rep, context=ctx) as resp_rep:
        print(f"Reports HTTP Status: {resp_rep.status}")
        rep_html = resp_rep.read().decode('utf-8', errors='ignore')
        has_win_path = ('c:\\' in rep_html.lower()) or ('arbax' in rep_html.lower())
        has_live_check = 'Checking for new reports' in rep_html
        idx = rep_html.find('kpiResolution')
        kpi_snippet = rep_html[idx:idx+90] if idx != -1 else 'Not found'
        print(f"Windows path removed: {not has_win_path} (Found: {has_win_path})")
        print(f"'Live • Checking' removed: {not has_live_check} (Found: {has_live_check})")
        print(f"kpiResolution initial state: {kpi_snippet}")
except Exception as e:
    print(f"Reports check error: {e}")

print("\n--- App.js Verification ---")
try:
    req_js = urllib.request.Request('https://vpn-block-prototype.netlify.app/app.js', headers={'User-Agent': 'Mozilla/5.0'})
    with urllib.request.urlopen(req_js, context=ctx) as resp_js:
        js = resp_js.read().decode('utf-8', errors='ignore')
        print(f"App.js HTTP Status: {resp_js.status} | Size: {len(js):,} bytes")
        has_js_motives = any(m in js.lower() for m in ['regional licensing', 'anti-scalper', 'anti-fraud'])
        print(f"App.js motive claims removed: {not has_js_motives}")
        print(f"App.js has 'Example Scenario': {'Example Scenario' in js}")
        print(f"App.js has honest fallback storage: {'saved locally in browser demonstration storage' in js}")
except Exception as e:
    print(f"App.js check error: {e}")
