import urllib.request

req = urllib.request.Request('https://vpn-block-prototype.netlify.app/app.js', headers={'User-Agent': 'Mozilla/5.0'})
with urllib.request.urlopen(req) as resp:
    app_js = resp.read().decode('utf-8', errors='ignore')

idx = app_js.find("'netflix.com': {")
print("=== NETLIFY APP.JS NETFLIX ENTRY ===")
print(app_js[idx:idx+900])
