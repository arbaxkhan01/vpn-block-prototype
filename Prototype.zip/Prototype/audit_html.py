import re

files_to_check = ['index.html', 'reports.html']
forbidden = [
    'netflix blocks vpn', 'blocks vpn connections', 'regional catalog', 'enforce region',
    'enforcing regional', 'regional licensing', 'anti-scalper', 'checking for new reports',
    'c:\\users', 'users\\arbax', '100% with zero', 'grade a'
]

for filename in files_to_check:
    print(f"\n=== AUDITING {filename} ===")
    with open(filename, 'r', encoding='utf-8') as f:
        content = f.read()
    
    issues = 0
    for word in forbidden:
        if word in content.lower():
            print(f"  [ISSUE] Found forbidden term: '{word}'")
            issues += 1
    
    # Check noindex in index.html and reports.html
    has_meta_robots = 'name="robots" content="noindex' in content
    print(f"  Meta robots noindex present: {has_meta_robots}")
    if not has_meta_robots:
        print("  [ERROR] Meta robots noindex is missing!")
        issues += 1

    # Check footer in index.html
    if filename == 'index.html':
        has_footer = '<footer class="site-footer-simple">' in content
        print(f"  Unrequested footer present: {has_footer}")
        if has_footer:
            print("  [ERROR] Unrequested footer is present!")
            issues += 1

    if issues == 0:
        print(f"  PASS: {filename} is 100% compliant with Instructions 1, 1A, 1B.")
    else:
        print(f"  FAIL: Found {issues} issues in {filename}.")
