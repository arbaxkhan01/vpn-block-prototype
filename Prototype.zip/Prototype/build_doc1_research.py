import os, subprocess, shutil
proto_dir = r"c:\Users\arbax\Downloads\Prototype"
artifact_dir = r"C:\Users\arbax\.gemini\antigravity\brain\3032b61f-a6cf-4a18-af31-464b02d2c35f"
chrome = r"C:\Program Files\Google\Chrome\Application\chrome.exe"

html_content = """<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>The 1.6 Billion User VPN Diagnostic Gap — Market Research Report</title>
  <style>
    @page {
      size: A4 portrait;
      margin: 12mm 14mm 12mm 14mm;
      @bottom-right {
        content: counter(page);
        font-size: 8.5px;
        color: #94a3b8;
        font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif;
      }
    }
    * { box-sizing: border-box; margin: 0; padding: 0; }
    body {
      font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, Helvetica, Arial, sans-serif;
      color: #0f172a;
      background: #ffffff;
      line-height: 1.45;
      font-size: 9.5px;
    }
    .cover-page {
      min-height: 88vh;
      display: flex;
      flex-direction: column;
      justify-content: space-between;
      padding: 24px 8px;
    }
    .cover-header {
      border-left: 6px solid #2563eb;
      padding-left: 20px;
      margin-top: 36px;
    }
    .cover-badge {
      display: inline-block;
      background: #eff6ff;
      color: #1d4ed8;
      font-weight: 700;
      font-size: 10px;
      padding: 4px 10px;
      border-radius: 4px;
      text-transform: uppercase;
      letter-spacing: 0.5px;
      margin-bottom: 12px;
      border: 1px solid #bfdbfe;
    }
    h1.cover-title {
      font-size: 25px;
      font-weight: 800;
      color: #0f172a;
      line-height: 1.25;
      margin-bottom: 8px;
    }
    .cover-subtitle {
      font-size: 12.5px;
      color: #475569;
      font-weight: 400;
      max-width: 620px;
      line-height: 1.5;
    }
    .cover-meta-grid {
      display: grid;
      grid-template-columns: repeat(2, 1fr);
      gap: 12px;
      background: #f8fafc;
      border: 1px solid #e2e8f0;
      border-radius: 8px;
      padding: 16px;
      margin: 24px 0;
    }
    .meta-item { display: flex; flex-direction: column; gap: 2px; }
    .meta-label { font-size: 8px; text-transform: uppercase; letter-spacing: 0.5px; color: #64748b; font-weight: 600; }
    .meta-value { font-size: 10.5px; font-weight: 600; color: #0f172a; }
    .cover-summary-box {
      background: #ffffff;
      border: 1px solid #cbd5e1;
      border-radius: 8px;
      padding: 14px 18px;
      box-shadow: 0 1px 3px rgba(0,0,0,0.05);
    }
    .cover-summary-box h3 { font-size: 11px; color: #1e293b; margin-bottom: 6px; font-weight: 700; }
    .cover-summary-box p { font-size: 9.5px; color: #334155; line-height: 1.5; }
    .cover-footer {
      border-top: 1px solid #e2e8f0;
      padding-top: 12px;
      display: flex;
      justify-content: space-between;
      color: #94a3b8;
      font-size: 8.5px;
    }
    .page-break { page-break-before: always; }
    .content-page { padding: 10px 4px; }
    .page-header {
      display: flex;
      justify-content: space-between;
      align-items: center;
      border-bottom: 1px solid #e2e8f0;
      padding-bottom: 8px;
      margin-bottom: 14px;
    }
    .page-header-title { font-size: 9px; font-weight: 700; color: #64748b; text-transform: uppercase; letter-spacing: 0.5px; }
    .page-header-date { font-size: 8.5px; color: #94a3b8; }
    .section { margin-bottom: 16px; }
    h2 {
      font-size: 12.5px;
      font-weight: 700;
      color: #0f172a;
      margin-bottom: 8px;
      padding-bottom: 4px;
      border-bottom: 1.5px solid #2563eb;
      display: flex;
      justify-content: space-between;
      align-items: center;
    }
    h3 { font-size: 10.5px; font-weight: 700; color: #1e293b; margin: 10px 0 4px 0; }
    p { margin-bottom: 8px; color: #334155; line-height: 1.5; }
    ul, ol { margin-left: 16px; margin-bottom: 8px; color: #334155; }
    li { margin-bottom: 4px; line-height: 1.45; }
    code {
      font-family: ui-monospace, SFMono-Regular, Menlo, monospace;
      font-size: 8.5px;
      background: #f1f5f9;
      padding: 1.5px 4px;
      border-radius: 3px;
      color: #0f172a;
      border: 1px solid #e2e8f0;
    }
    .table-custom {
      width: 100%;
      border-collapse: collapse;
      margin: 10px 0 14px 0;
      font-size: 8.5px;
    }
    .table-custom th {
      background: #f8fafc;
      color: #475569;
      font-weight: 700;
      text-align: left;
      padding: 6px 8px;
      border: 1px solid #cbd5e1;
      font-size: 8px;
      text-transform: uppercase;
      letter-spacing: 0.3px;
    }
    .table-custom td {
      padding: 5px 8px;
      border: 1px solid #cbd5e1;
      color: #334155;
      vertical-align: top;
    }
    .table-custom tr:nth-child(even) { background: #f8fafc; }
    .badge-pass { display: inline-block; background: #dcfce7; color: #15803d; font-weight: 700; padding: 2px 6px; border-radius: 3px; font-size: 7.5px; border: 1px solid #bbf7d0; }
    .badge-info { display: inline-block; background: #eff6ff; color: #1d4ed8; font-weight: 700; padding: 2px 6px; border-radius: 3px; font-size: 7.5px; border: 1px solid #bfdbfe; }
    .badge-warning { display: inline-block; background: #fffbeb; color: #b45309; font-weight: 700; padding: 2px 6px; border-radius: 3px; font-size: 7.5px; border: 1px solid #fde68a; }
    .callout { background: #f8fafc; border-left: 4px solid #2563eb; padding: 8px 12px; border-radius: 0 6px 6px 0; margin: 10px 0; font-size: 9px; }
    .section-tag { font-size: 7.5px; font-weight: 600; background: #f1f5f9; color: #475569; padding: 2px 6px; border-radius: 3px; text-transform: uppercase; letter-spacing: 0.3px; }
  </style>
</head>
<body>

  <!-- COVER PAGE -->
  <div class="cover-page">
    <div class="cover-header">
      <div class="cover-badge">Strategic Market &amp; User Need Research</div>
      <h1 class="cover-title">The 1.6 Billion User<br>VPN Diagnostic Gap</h1>
      <p class="cover-subtitle">
        Analyzing consumer friction, silent access denial, false outage attribution, and the strategic market opportunity for an independent VPN accessibility diagnostic platform.
      </p>
    </div>

    <div class="cover-meta-grid">
      <div class="meta-item">
        <span class="meta-label">Document Purpose</span>
        <span class="meta-value">Market Research &amp; Consumer Problem Analysis</span>
      </div>
      <div class="meta-item">
        <span class="meta-label">Target Audience</span>
        <span class="meta-value">Product Strategy, Engineering, &amp; Leadership</span>
      </div>
      <div class="meta-item">
        <span class="meta-label">Global Market Context</span>
        <span class="meta-value">1.6B+ Active VPN Users &bull; $45B+ VPN Ecosystem</span>
      </div>
      <div class="meta-item">
        <span class="meta-label">Research Focus</span>
        <span class="meta-value">Silent Egress Blocks, WAF Friction, &amp; Diagnostic Void</span>
      </div>
    </div>

    <div class="cover-summary-box">
      <h3>Executive Summary</h3>
      <p>
        Over 1.6 billion individuals globally utilize Virtual Private Networks for privacy, remote work, public Wi-Fi security, and digital access. However, as edge security vendors (e.g., Cloudflare, Akamai, AWS WAF, PerimeterX) increasingly deploy automated IP classification algorithms, commercial VPN exit nodes frequently encounter silent blocks, HTTP 403 Access Denied responses, and persistent CAPTCHA verification challenges.
      </p>
      <p style="margin-top: 6px;">
        When a web service fails to load, users face a fundamental diagnostic vacuum: they cannot determine whether the target website is experiencing an outage, whether their VPN server IP is restricted, or whether local connectivity has degraded. Existing monitoring utilities (such as DownDetector) measure origin reachability from non-VPN perspectives, while review sites publish subjective, static affiliate tables. VPN.com possesses a distinct market opportunity to deliver the first objective, transparent, and independent diagnostic utility that decouples website uptime from VPN egress accessibility.
      </p>
    </div>

    <div class="cover-footer">
      <span>VPN.com Prototype Development &bull; Market Research</span>
      <span>Document Ref: VPN-MR-V05-2026</span>
    </div>
  </div>

  <!-- PAGE BREAK: CONTENT -->
  <div class="page-break"></div>
  <div class="content-page">
    <div class="page-header">
      <span class="page-header-title">VPN Market Research &bull; Consumer Friction &amp; Diagnostic Taxonomy</span>
      <span class="page-header-date">September 29, 2026</span>
    </div>

    <div class="section">
      <h2>1. The Global VPN Landscape &amp; The Diagnostic Dilemma <span class="section-tag">Market Scope</span></h2>
      <p>
        VPN adoption has evolved from a specialized cryptographic tool for corporate networks into a universal consumer utility. Global consumer surveys indicate that over 35% of adult internet users across North America, Europe, and Asia-Pacific routinely engage VPN connections. The primary drivers include:
      </p>
      <ul>
        <li><strong>Everyday Privacy &amp; Anti-Tracking</strong>: Shielding browsing telemetry from commercial Internet Service Providers (ISPs) and ad tech trackers.</li>
        <li><strong>Public Wi-Fi Encryption</strong>: Protecting mobile credentials in hospitality, transit, and shared workspaces.</li>
        <li><strong>Remote Workforce Security</strong>: Connecting distributed knowledge workers to corporate clouds and developer resources.</li>
        <li><strong>Digital Mobility &amp; Cross-Border Continuity</strong>: Maintaining access to domestic banking, media, and productivity tools while traveling.</li>
      </ul>
      <p>
        Concurrently, modern web infrastructure has centralized behind large-scale Cloud and Content Delivery Networks (CDNs). To defend against automated credential stuffing, distributed denial of service (DDoS) attacks, and bot activity, these platforms employ IP reputation scoring. Because commercial VPN services route thousands of users through multi-tenant datacenter Autonomous System Numbers (ASNs), edge firewalls routinely flag these addresses as elevated risk, resulting in silent access denial.
      </p>
    </div>

    <div class="section">
      <h2>2. The Four-Tier Friction Taxonomy <span class="section-tag">User Friction</span></h2>
      <p>
        Users attempting to browse while connected to a VPN encounter four distinct failure modes that are routinely conflated:
      </p>
      <table class="table-custom">
        <thead>
          <tr>
            <th style="width: 22%;">Failure Mode</th>
            <th style="width: 28%;">Technical Manifestation</th>
            <th style="width: 25%;">Representative Target Category</th>
            <th style="width: 25%;">User Behavior &amp; Harm</th>
          </tr>
        </thead>
        <tbody>
          <tr>
            <td><strong>1. Hard Egress Drop (WAF / HTTP 403)</strong></td>
            <td>Automated edge firewalls return HTTP 403 Forbidden or immediate TCP Reset based purely on datacenter ASN lookup.</td>
            <td>Ticketing platforms (e.g., Ticketmaster), high-volume retail checkout, event registration.</td>
            <td>User assumes site is broken or their account is suspended; abandons transaction.</td>
          </tr>
          <tr>
            <td><strong>2. Platform Restriction Codes</strong></td>
            <td>Web player or API gateway detects proxy IP range and renders client-side error codes (e.g., Netflix proxy code, Hulu P-DEV320, Disney+ Error 73).</td>
            <td>Streaming services, video-on-demand networks, regional media portals.</td>
            <td>User disconnects VPN entirely, exposing their real IP and baseline traffic.</td>
          </tr>
          <tr>
            <td><strong>3. Verification Challenge Friction</strong></td>
            <td>Target is theoretically reachable, but presents looping CAPTCHA verification (Cloudflare Turnstile, hCaptcha) or forces repeated multi-factor step-up re-authentication.</td>
            <td>AI platforms (e.g., ChatGPT), fintech/crypto exchanges (e.g., Coinbase), online banking.</td>
            <td>Severe UX degradation, high user frustration, repeated verification loops.</td>
          </tr>
          <tr>
            <td><strong>4. False Outage Attribution</strong></td>
            <td>Origin host is genuinely down (HTTP 500/503 or authoritative DNS outage), but user mistakenly assumes their VPN client is defective.</td>
            <td>Global web services experiencing infrastructure downtime or localized cloud outages.</td>
            <td>User cycles through multiple VPN servers or uninstalls software when the issue is an origin failure.</td>
          </tr>
        </tbody>
      </table>
    </div>

    <div class="section">
      <h2>3. The Competitive &amp; Diagnostic Vacuum <span class="section-tag">Competitive Landscape</span></h2>
      <p>
        Currently, no objective, transparent, and neutral tool exists to solve this diagnostic dilemma:
      </p>
      <ul>
        <li><strong>Generic Uptime Checkers (e.g., DownDetector, IsItDownRightNow)</strong>: These tools monitor origin health using traditional probe nodes located in standard hosting environments or residential connections without VPN simulation. When a user asks <em>"Is Netflix down or is my VPN blocked?"</em>, DownDetector indicates green ("No problems at Netflix"), leaving the user confused and assuming their personal setup is broken.</li>
        <li><strong>VPN Affiliate &amp; Review Portals</strong>: Review portals publish static recommendation tables (e.g., <em>"Best VPNs for Streaming in 2026"</em>). These tables are heavily monetized via affiliate commissions, updated manually once per quarter, and lack transparent telemetry, test methodology, or verifiable evidence.</li>
      </ul>
      <div class="callout">
        <strong>The Strategic Opportunity for VPN.com:</strong> By decoupling <em>Website Status</em> (Origin Reachability) from <em>VPN Accessibility</em> (Egress Status) and providing an objective <em>Evidence Strength</em> rating, VPN.com establishes itself as the authoritative, trust-first diagnostic referee for the global VPN industry.
      </div>
    </div>

    <div class="section">
      <h2>4. Crowdsourced Intelligence &amp; Community Signals <span class="section-tag">Crowdsourcing</span></h2>
      <p>
        Active automated network probes cannot test every domain across every regional server combination continuously. Integrating structured crowdsourced user reports bridges this telemetry gap:
      </p>
      <ul>
        <li><strong>Rapid Outage Detection</strong>: When hundreds of independent users report access failures on a specific target within minutes, the system surfaces immediate friction signals.</li>
        <li><strong>Resolution Verification</strong>: By capturing whether disconnecting the VPN resolved the problem, crowdsourced signals provide valuable real-world differential evidence.</li>
        <li><strong>Privacy-Preserving Intake</strong>: The prototype demonstrates how community reports can be ingested without harvesting user IP addresses, tracking cookies, or personal identifiers.</li>
      </ul>
    </div>
  </div>

</body>
</html>
"""

html_file = os.path.join(proto_dir, "VPN_Access_Check_Market_Research_Report.html")
pdf_local = os.path.join(proto_dir, "VPN_Access_Check_Market_Research_Report.pdf")
pdf_artifact = os.path.join(artifact_dir, "VPN_Access_Check_Market_Research_Report.pdf")

with open(html_file, "w", encoding="utf-8") as f:
    f.write(html_content)

cmd = [chrome, "--headless=new", "--disable-gpu", "--no-pdf-header-footer", f"--print-to-pdf={pdf_local}", html_file]
subprocess.run(cmd, check=True)
shutil.copy2(pdf_local, pdf_artifact)
size = os.path.getsize(pdf_local)
print(f"[OK] Compiled: VPN_Access_Check_Market_Research_Report.pdf ({size:,} bytes)")
