import os
import subprocess
import shutil

chrome = r"C:\Program Files\Google\Chrome\Application\chrome.exe"
if not os.path.exists(chrome):
    chrome = r"C:\Program Files (x86)\Google\Chrome\Application\chrome.exe"

proto_dir = r"c:\Users\arbax\Downloads\Prototype"
artifact_dir = r"C:\Users\arbax\.gemini\antigravity\brain\3032b61f-a6cf-4a18-af31-464b02d2c35f"

html_content = """<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>VPN Block / Access Check — Prototype V0.5 Update & Model Evolution Report</title>
  <style>
    @page {
      size: A4 portrait;
      margin: 14mm 14mm 14mm 14mm;
      @bottom-right {
        content: counter(page);
        font-size: 9px;
        color: #94a3b8;
        font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif;
      }
    }

    * {
      box-sizing: border-box;
      margin: 0;
      padding: 0;
    }

    body {
      font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, Helvetica, Arial, sans-serif;
      color: #0f172a;
      background: #ffffff;
      line-height: 1.48;
      font-size: 10.5px;
    }

    .cover-page {
      min-height: 86vh;
      display: flex;
      flex-direction: column;
      justify-content: space-between;
      padding: 24px 8px 30px 8px;
    }

    .cover-header {
      border-left: 6px solid #2563eb;
      padding-left: 20px;
      margin-top: 44px;
    }

    .cover-badge {
      display: inline-block;
      background: #eff6ff;
      color: #1d4ed8;
      border: 1px solid #bfdbfe;
      font-size: 10px;
      font-weight: 700;
      text-transform: uppercase;
      letter-spacing: 0.08em;
      padding: 4px 10px;
      border-radius: 4px;
      margin-bottom: 14px;
    }

    .cover-title {
      font-size: 28px;
      font-weight: 900;
      color: #0f172a;
      line-height: 1.2;
      letter-spacing: -0.02em;
      margin-bottom: 12px;
    }

    .cover-subtitle {
      font-size: 13px;
      color: #475569;
      line-height: 1.5;
      max-width: 620px;
    }

    .cover-meta-grid {
      display: grid;
      grid-template-columns: 1fr 1fr;
      gap: 12px;
      background: #f8fafc;
      border: 1px solid #e2e8f0;
      border-radius: 10px;
      padding: 18px 22px;
      margin-top: 36px;
    }

    .meta-item-label {
      font-size: 9px;
      font-weight: 700;
      text-transform: uppercase;
      letter-spacing: 0.05em;
      color: #64748b;
      margin-bottom: 2px;
    }

    .meta-item-value {
      font-size: 12px;
      font-weight: 700;
      color: #0f172a;
    }

    .cover-footer {
      display: flex;
      justify-content: space-between;
      border-top: 1px solid #e2e8f0;
      padding-top: 14px;
      font-size: 10px;
      color: #64748b;
    }

    .page-break {
      page-break-before: always;
      break-before: page;
      padding-top: 6px;
    }

    .section {
      margin-bottom: 18px;
    }

    h2 {
      font-size: 14.5px;
      font-weight: 800;
      color: #0f172a;
      border-bottom: 1.5px solid #2563eb;
      padding-bottom: 4px;
      margin-bottom: 10px;
      letter-spacing: -0.01em;
      display: flex;
      align-items: center;
      justify-content: space-between;
      page-break-after: avoid;
      break-after: avoid;
    }

    h2 .section-tag {
      font-size: 9px;
      font-weight: 700;
      color: #2563eb;
      background: #eff6ff;
      border: 1px solid #bfdbfe;
      padding: 2px 7px;
      border-radius: 4px;
      text-transform: uppercase;
      letter-spacing: 0.04em;
    }

    h3 {
      font-size: 11.5px;
      font-weight: 700;
      color: #1e293b;
      margin: 10px 0 4px 0;
      page-break-after: avoid;
      break-after: avoid;
    }

    p {
      color: #334155;
      margin-bottom: 7px;
      line-height: 1.5;
    }

    .callout {
      background: #f8fafc;
      border-left: 4px solid #2563eb;
      padding: 9px 13px;
      margin: 9px 0;
      border-radius: 0 6px 6px 0;
      font-size: 10px;
      page-break-inside: avoid;
      break-inside: avoid;
    }

    .callout.green {
      background: #f0fdf4;
      border-left-color: #10b981;
      color: #166534;
    }

    .callout.amber {
      background: #fffbeb;
      border-left-color: #f59e0b;
      color: #92400e;
    }

    /* Comparison Table Styles */
    table.comp-table {
      width: 100%;
      border-collapse: collapse;
      margin: 10px 0;
      font-size: 9.5px;
    }

    table.comp-table tr {
      page-break-inside: avoid;
      break-inside: avoid;
    }

    table.comp-table th {
      background: #0f172a;
      color: #ffffff;
      font-weight: 700;
      text-align: left;
      padding: 6px 8px;
      font-size: 9.5px;
      border: 1px solid #0f172a;
    }

    table.comp-table td {
      padding: 6px 8px;
      border: 1px solid #cbd5e1;
      vertical-align: top;
      line-height: 1.4;
    }

    table.comp-table tr:nth-child(even) td {
      background: #f8fafc;
    }

    .badge-old {
      display: inline-block;
      background: #fee2e2;
      color: #991b1b;
      font-weight: 700;
      font-size: 8.5px;
      padding: 1px 5px;
      border-radius: 3px;
      margin-bottom: 3px;
      text-transform: uppercase;
    }

    .badge-new {
      display: inline-block;
      background: #dcfce7;
      color: #166534;
      font-weight: 700;
      font-size: 8.5px;
      padding: 1px 5px;
      border-radius: 3px;
      margin-bottom: 3px;
      text-transform: uppercase;
    }

    .metric-grid {
      display: grid;
      grid-template-columns: repeat(4, 1fr);
      gap: 10px;
      margin: 12px 0;
      page-break-inside: avoid;
      break-inside: avoid;
    }

    .metric-card {
      background: #f8fafc;
      border: 1px solid #e2e8f0;
      border-radius: 8px;
      padding: 10px 12px;
      text-align: center;
    }

    .metric-num {
      font-size: 20px;
      font-weight: 900;
      color: #2563eb;
      line-height: 1.1;
      margin-bottom: 2px;
    }

    .metric-label {
      font-size: 8.5px;
      font-weight: 700;
      color: #64748b;
      text-transform: uppercase;
      letter-spacing: 0.04em;
    }

    .metric-sub {
      font-size: 9px;
      color: #334155;
      margin-top: 2px;
    }

    .card-box {
      background: #ffffff;
      border: 1px solid #e2e8f0;
      border-radius: 8px;
      padding: 11px 13px;
      margin: 7px 0;
      page-break-inside: avoid;
      break-inside: avoid;
    }

    .card-box-title {
      font-size: 11px;
      font-weight: 800;
      color: #0f172a;
      margin-bottom: 4px;
      display: flex;
      align-items: center;
      gap: 6px;
    }

    code {
      font-family: ui-monospace, SFMono-Regular, Menlo, Monaco, Consolas, monospace;
      font-size: 9px;
      background: #f1f5f9;
      color: #0f172a;
      padding: 1px 4px;
      border-radius: 3px;
      border: 1px solid #e2e8f0;
    }

    ul, ol {
      margin: 5px 0 8px 18px;
      color: #334155;
    }

    li {
      margin-bottom: 3px;
      line-height: 1.45;
    }
  </style>
</head>
<body>

  <!-- COVER PAGE -->
  <div class="cover-page">
    <div class="cover-header">
      <div class="cover-badge">Internal Technical Review &bull; Instructions 1A Refinement</div>
      <h1 class="cover-title">VPN Block / Access Check<br>Prototype V0.5 Engineering &amp; Refinement Progress Report</h1>
      <p class="cover-subtitle">
        Internal Technical Progress Report: Documenting architectural changes, truthfulness alignment, 3-pillar data decoupling, and viewport validation under Instructions 1 and 1A.
      </p>
    </div>

    <div class="cover-meta-grid">
      <div>
        <div class="meta-item-label">Active Milestone</div>
        <div class="meta-item-value">Instructions 1 &amp; 1A — V0.5 Final Refinements</div>
      </div>
      <div>
        <div class="meta-item-label">Primary Objective</div>
        <div class="meta-item-value">Measurement Truthfulness &amp; Clean UX Boundaries</div>
      </div>
      <div>
        <div class="meta-item-label">Verification Date</div>
        <div class="meta-item-value">September 28, 2026</div>
      </div>
      <div>
        <div class="meta-item-label">Automated Test Status</div>
        <div class="meta-item-value" style="color:#10b981;">All 6 Test Suites Passing</div>
      </div>
      <div>
        <div class="meta-item-label">Target Viewports Tested</div>
        <div class="meta-item-value">360px, 390px, 430px, 768px, 1024px, 1440px</div>
      </div>
      <div>
        <div class="meta-item-label">Backend Persistence Mode</div>
        <div class="meta-item-value">Local Prototype Storage (reports.json) + Dual Sync</div>
      </div>
    </div>

    <div class="cover-footer">
      <span>VPN.com Access Check &bull; Internal Engineering Progress Report</span>
      <span>Confidential &bull; Prepared for Technical Review (Not Final Client-Facing Copy)</span>
    </div>
  </div>

  <!-- PAGE 2: EXECUTIVE SUMMARY & CODEBASE MODIFICATIONS -->
  <div class="page-break">
    <div class="section">
      <h2>1. Executive Summary &amp; Core Directive <span class="section-tag">Milestone Objective</span></h2>
      <div class="callout blue" style="margin-bottom: 12px;">
        <strong>Document Status Note:</strong> This document serves as an internal engineering report recording prototype refinement steps against Instructions 1 and 1A. It is not final client-facing marketing or product documentation. All absolute claims have been removed, and current prototype behavior is strictly separated from future production architecture.
      </div>
      <p>
        The primary directive of <strong>Prototype V0.5</strong> is unambiguous: <em>"The prototype should demonstrate the intended VPN.com product experience without presenting simulated data as real measurements. A user must never reasonably interpret simulated data as a real measurement."</em>
      </p>
      <p>
        In the previous iteration (V0.4), the prototype functioned as an interactive concept proof. While visually compelling, it relied on synthetic heuristics—including a JavaScript string-hashing algorithm (<code>hashString()</code>) that assigned arbitrary letter grades, simulated latencies, and randomized verdicts to any arbitrary domain entered by a user.
      </p>
      <p>
        <strong>Prototype V0.5 executes an architectural paradigm shift:</strong> all unsupported live claims, arbitrary scoring functions, and synthetic measurements have been eliminated. Unknown domains now transparently return an honest fallback state (<code>Live testing not connected in this prototype</code>), the UI data model has been decoupled into three strictly independent pillars, mobile responsiveness has been engineered down to 360px, and the crowdsourced reporting pipeline has been overhauled with instant visual feedback and accurate storage feedback.
      </p>

      <div class="metric-grid">
        <div class="metric-card">
          <div class="metric-num">Verified</div>
          <div class="metric-label">Truthfulness Alignment</div>
          <div class="metric-sub">Zero simulated values presented as real</div>
        </div>
        <div class="metric-card">
          <div class="metric-num">3</div>
          <div class="metric-label">Independent Pillars</div>
          <div class="metric-sub">Website &bull; VPN &bull; Evidence Strength</div>
        </div>
        <div class="metric-card">
          <div class="metric-num">360px</div>
          <div class="metric-label">Mobile Minimum Width</div>
          <div class="metric-sub">Zero horizontal blowout or clipped CTAs</div>
        </div>
        <div class="metric-card">
          <div class="metric-num">6 / 6</div>
          <div class="metric-label">Automated Suites</div>
          <div class="metric-sub">Passing regression &amp; DOM tests</div>
        </div>
      </div>

      <div class="callout green">
        <strong>Formal Verification Statement:</strong> In Prototype V0.5, no simulated, computed, or placeholder value is presented to the user as a live network measurement. All demonstration workflows are explicitly labeled <code>Demo data &bull; Prototype preview</code>, and the technical schema illustrates the future measurement architecture with complete integrity.
      </div>
    </div>

    <div class="section">
      <h2>2. Quantitative Scope: "How Much Has Changed?" <span class="section-tag">Codebase Evolution</span></h2>
      <p>
        The transition from V0.4 to V0.5 touched every layer of the prototype stack, spanning user-facing markup, responsive CSS, event coordination, reporting persistence, and automated validation:
      </p>

      <div class="card-box">
        <div class="card-box-title">📁 Workspace File Modifications &amp; Engineering Scope</div>
        <ul>
          <li><strong><code>index.html</code> (24,288 bytes)</strong>: Restructured hero container, wrapped search inputs in <code>.search-input-inner-row</code> for mobile wrapping, decoupled the verdict card into 3 discrete pillar containers, preserved <code>#gradeTagBox</code> with <code>display: none;</code>, expanded report modal from 3 to 7 fields, and updated storage disclaimers.</li>
          <li><strong><code>styles.css</code> (46,087 bytes)</strong>: Implemented mobile breakpoint at <code>max-width: 640px</code> transforming the search bar into a full-width vertical stack (44px touch button); added styles for <code>.evidence-pill</code> with 4 confidence states; added unknown verdict card styling; overhauled mobile modal with <code>max-height: 90vh; overflow-y: auto;</code> to prevent keyboard clipping.</li>
          <li><strong><code>app.js</code> (81,183 bytes)</strong>: Completely removed <code>hashString()</code> and pseudo-random verdict assignment; implemented truthful <code>generateCustomScenario()</code>; updated all 8 preset scenarios with evidence confidence ratings; decoupled outage logic; expanded report submission handler to transmit region, details, and screenshot links.</li>
          <li><strong><code>reports.html</code> (27,106 bytes)</strong>: Completely rewritten from a dense, intimidating pseudo-admin dump into a clean, human-readable <strong>Community Reports Log</strong>; added animated <code>@keyframes spinIcon</code> refresh button, instant status timestamp badge, live real-time search, and dynamic target filter pills.</li>
          <li><strong><code>server.py</code> (5,613 bytes)</strong>: Updated <code>POST /api/reports</code> to ingest and persist the expanded 7-field schema into <code>reports.json</code>; updated response messages to truthfully reflect local prototype file storage.</li>
          <li><strong><code>test_complete_suite.py</code> (4,643 bytes)</strong>: Full regression verification covering all 8 HTTP endpoints, 72 DOM element IDs, 8 preset scenarios, 14 UX components, and 6 copy checks.</li>
        </ul>
      </div>
    </div>
  </div>

  <!-- PAGE 3: COMPARATIVE AUDIT PART 1 -->
  <div class="page-break">
    <div class="section">
      <h2>3. Comprehensive Comparative Audit: Previous vs. Current Model <span class="section-tag">Direct Comparison</span></h2>
      <p>
        The following matrix details the operational and visual differences across every major capability of the system:
      </p>

      <table class="comp-table">
        <thead>
          <tr>
            <th style="width: 18%;">Feature / Dimension</th>
            <th style="width: 31%;">Previous Model (V0.4 Synthetic Demo)</th>
            <th style="width: 33%;">Current Model (V0.5 Radical Truthfulness)</th>
            <th style="width: 18%;">Impact &amp; Status</th>
          </tr>
        </thead>
        <tbody>
          <tr>
            <td><strong>Core Result Architecture</strong></td>
            <td>
              <span class="badge-old">Entangled Model</span><br>
              Status and Grade were tightly coupled. A single status badge showed synthetic combined outcomes like <em>"Online &bull; Works on VPN"</em>.
            </td>
            <td>
              <span class="badge-new">Decoupled 3-Pillar UI</span><br>
              Divided into 3 independent pillars: <strong>Website Status</strong>, <strong>VPN Accessibility</strong>, and <strong>Evidence Strength</strong>.
            </td>
            <td><strong>Complete Separation</strong><br>Approved product model implemented.</td>
          </tr>
          <tr>
            <td><strong>Site Outage Isolation</strong></td>
            <td>
              <span class="badge-old">False Bypass Possible</span><br>
              If a target site was down, the tool could still present VPN bypass recommendations or conflicting status indicators.
            </td>
            <td>
              <span class="badge-new">Strict Outage Isolation</span><br>
              When direct reachability cannot be established (<code>down-example.test</code>), VPN accessibility strictly displays <strong>Unknown / Not Measurable</strong>.
            </td>
            <td><strong>Diagnostic Accuracy</strong><br>Outages never falsely reported as VPN blocks.</td>
          </tr>
          <tr>
            <td><strong>Arbitrary Custom Domains</strong></td>
            <td>
              <span class="badge-old">Synthetic Hash Simulation</span><br>
              Arbitrary domains were hashed via <code>hashString()</code> to assign random grades (e.g. "Grade A") and fake latency metrics.
            </td>
            <td>
              <span class="badge-new">Truthful Fallback State</span><br>
              <code>hashString()</code> deleted. Returns: <em>"Live testing not connected in this prototype"</em> with <em>"Insufficient evidence"</em> and honest explanation.
            </td>
            <td><strong>Eliminated Fabrication</strong><br>Aligned with Guideline 2.</td>
          </tr>
          <tr>
            <td><strong>Live Testing Claims</strong></td>
            <td>
              <span class="badge-old">Unsupported Live Wording</span><br>
              Displayed badges such as <em>"Live Check &bull; Checked just now"</em>, <em>"Real-Time Diagnostic"</em>, and <em>"Verified"</em>.
            </td>
            <td>
              <span class="badge-new">Explicit Demo Labeling</span><br>
              Replaced with clear, honest indicators: <strong>Demo data &bull; Prototype preview</strong> and <em>"Services in Validation Pipeline"</em>.
            </td>
            <td><strong>Truthful UX</strong><br>Users never misled about live status.</td>
          </tr>
          <tr>
            <td><strong>Provider Success Rates</strong></td>
            <td>
              <span class="badge-old">Fabricated Percentages</span><br>
              Displayed synthetic claims like <em>"NordVPN &mdash; 99% Success"</em> and <em>"ExpressVPN &mdash; 97% Success"</em>.
            </td>
            <td>
              <span class="badge-new">Neutral Capability Tags</span><br>
              All percentages removed. Replaced with clean tags: <code>Compatible Node</code> and <code>Demo Profile</code> without numbers.
            </td>
            <td><strong>Unverified Numbers Removed</strong><br>Compliant with Guideline 10.</td>
          </tr>
          <tr>
            <td><strong>Technical Probes &amp; Latency</strong></td>
            <td>
              <span class="badge-old">Fabricated Ping Values</span><br>
              Hardcoded direct connection latencies (e.g., <code>34 ms</code>) and simulated TLS handshake probe data.
            </td>
            <td>
              <span class="badge-new">Honest Null Fallbacks</span><br>
              Latency displays <strong>Not measured</strong>. Unavailable probe fields use honest fallbacks: <code>&mdash;</code>, <code>Not measured</code>, <code>Unavailable</code>.
            </td>
            <td><strong>Scientific Integrity</strong><br>No synthetic technical measurements.</td>
          </tr>
          <tr>
            <td><strong>A&ndash;F Letter Grades</strong></td>
            <td>
              <span class="badge-old">Active Synthetic Grade</span><br>
              Displayed unvalidated letter grades (A, B, C, F) directly on search results and service directory cards.
            </td>
            <td>
              <span class="badge-new">Preserved in Code, Hidden in UI</span><br>
              <code>#gradeTagBox</code> preserved in DOM for future telemetry API integration, but hidden via <code>display: none;</code>.
            </td>
            <td><strong>Future-Proofed</strong><br>Ready for real scoring without fake UI.</td>
          </tr>
        </tbody>
      </table>
    </div>
  </div>

  <!-- PAGE 4: COMPARATIVE AUDIT PART 2 -->
  <div class="page-break">
    <div class="section">
      <h2>3. Comparative Audit (Continued) <span class="section-tag">Direct Comparison</span></h2>

      <table class="comp-table">
        <thead>
          <tr>
            <th style="width: 18%;">Feature / Dimension</th>
            <th style="width: 31%;">Previous Model (V0.4 Synthetic Demo)</th>
            <th style="width: 33%;">Current Model (V0.5 Radical Truthfulness)</th>
            <th style="width: 18%;">Impact &amp; Status</th>
          </tr>
        </thead>
        <tbody>
          <tr>
            <td><strong>Evidence Metric Presentation</strong></td>
            <td>
              <span class="badge-old">Conflated Counters</span><br>
              Evidence was conflated with fabricated community report counters (e.g., "342 reports today").
            </td>
            <td>
              <span class="badge-new">Independent Evidence Pill</span><br>
              Renders dedicated <code>.evidence-pill</code> with color-coded dot: <em>Insufficient</em>, <em>Limited</em>, <em>Moderate</em>, or <em>Strong evidence</em>.
            </td>
            <td><strong>Independent Pillar</strong><br>Decoupled metric supported.</td>
          </tr>
          <tr>
            <td><strong>Report a VPN Block Modal</strong></td>
            <td>
              <span class="badge-old">Basic 3-Question Modal</span><br>
              Only collected Website, Symptom, and VPN Provider. Missing region, detailed description, and evidence.
            </td>
            <td>
              <span class="badge-new">Comprehensive 7-Field Form</span><br>
              Captures Domain, Symptom, Provider, Approximate Region, What Happened (Details), Disconnect Test, and Screenshot URL.
            </td>
            <td><strong>Structured Schema</strong><br>Full telemetry input structure ready.</td>
          </tr>
          <tr>
            <td><strong>Report Storage Truthfulness</strong></td>
            <td>
              <span class="badge-old">Misleading Production Copy</span><br>
              Claimed submissions were <em>"recorded in our global backend database"</em>.
            </td>
            <td>
              <span class="badge-new">Transparent Local Storage</span><br>
              Accurately states: <em>"Saved to local prototype storage (reports.json)"</em> or <em>"Saved to browser demonstration cache"</em>.
            </td>
            <td><strong>Transparent Architecture</strong><br>Matches actual execution environment.</td>
          </tr>
          <tr>
            <td><strong>Reports Inspector Dashboard</strong></td>
            <td>
              <span class="badge-old">Confusing Technical Table</span><br>
              Loud yellow banner, raw hash IDs (<code>rep_2daf8f</code>), client IP addresses, and a static refresh button with zero feedback.
            </td>
            <td>
              <span class="badge-new">Polished Community Log</span><br>
              Human-readable cards, active spinning refresh button, live seconds timestamp, real-time live search, and dynamic filter pills.
            </td>
            <td><strong>User-Friendly</strong><br>Clean demonstration viewer for clients.</td>
          </tr>
          <tr>
            <td><strong>Mobile Responsiveness (360px)</strong></td>
            <td>
              <span class="badge-old">Search Input Blowout</span><br>
              At 360px width, input fields squeezed and submit button overflowed viewport horizontally due to intrinsic input min-widths.
            </td>
            <td>
              <span class="badge-new">Full-Width Responsive Stack</span><br>
              <code>min-width: 0</code> on input row; <code>max-width: 640px</code> breakpoint creates clean vertical stack with 44px touch targets.
            </td>
            <td><strong>Verified 360px&ndash;1440px</strong><br>Zero horizontal clipping or overflow.</td>
          </tr>
          <tr>
            <td><strong>Hero Banner &amp; Header</strong></td>
            <td>
              <span class="badge-old">Top Prototype Badge</span><br>
              Contained prominent yellow pill badge above main title that added visual clutter to consumer viewport.
            </td>
            <td>
              <span class="badge-new">Streamlined Clean Layout</span><br>
              Removed top pill banner per user instruction. Main headline and search bar sit cleanly directly under navigation.
            </td>
            <td><strong>Visual Polish</strong><br>Streamlined hero presentation.</td>
          </tr>
        </tbody>
      </table>
    </div>
  </div>

  <!-- PAGE 5: ARCHITECTURAL DEEP-DIVE & TELEMETRY FLOW -->
  <div class="page-break">
    <div class="section">
      <h2>4. Architectural Deep-Dive: The 3-Pillar Data Model <span class="section-tag">System Design</span></h2>
      <p>
        The core conceptual breakthrough of Prototype V0.5 is the structural separation of concerns. In traditional simplistic tools, website reachability and VPN blocking are collapsed into a single boolean state. This creates severe false positives during origin server outages.
      </p>

      <div class="card-box">
        <div class="card-box-title">The Three Independent Decision Pillars</div>
        <ol>
          <li>
            <strong>Pillar 1: Website Status (Baseline Reachability)</strong><br>
            Evaluates whether the destination web property is operational from owned/consented ordinary-user baseline controls.
            States: <code>Online (Working)</code> | <code>Site Unreachable / Outage</code> | <code>Not Measurable</code>.
          </li>
          <li>
            <strong>Pillar 2: VPN Accessibility (Egress Traffic Permeability)</strong><br>
            Evaluates whether commercial VPN IP ranges encounter network-level or application-layer blocks (such as HTTP 403 Forbidden, Cloudflare Turnstile infinite loops, or streaming geo-filter error codes).
            States: <code>VPN Blocked</code> | <code>Accessible via VPN</code> | <code>Unknown / Not Measurable</code>.
          </li>
          <li>
            <strong>Pillar 3: Evidence Strength (Confidence Scoring)</strong><br>
            Quantifies the statistical volume and freshness of independent multi-exit probe observations and verified community reports.
            States: <code>Insufficient evidence</code> | <code>Limited evidence</code> | <code>Moderate evidence</code> | <code>Strong evidence</code>.
          </li>
        </ol>
      </div>

      <div class="callout amber">
        <strong>The Outage Rule:</strong> If Pillar 1 evaluates to <code>Site Unreachable / Outage</code> or <code>Not Measurable</code>, Pillar 2 cannot scientifically determine VPN accessibility. Under Prototype V0.5, Pillar 2 is strictly clamped to <strong><code>Unknown / Not Measurable</code></strong>, preventing inaccurate consumer diagnostics.
      </div>
    </div>

    <div class="section">
      <h2>5. Crowdsource Telemetry Pipeline &amp; Dual Sync <span class="section-tag">Backend Architecture</span></h2>
      <p>
        Prototype V0.5 implements an end-to-end crowdsourced reporting pipeline designed for high resilience across local development, client demonstration servers, and standalone offline execution:
      </p>

      <div class="card-box">
        <div class="card-box-title">End-to-End Submission &amp; Inspection Flow</div>
        <ul>
          <li><strong>Step 1 (User Submission)</strong>: User clicks "Report a Block", selects symptoms (e.g. Cloudflare Turnstile loop), chooses their VPN provider, region, and enters details.</li>
          <li><strong>Step 2 (Local Storage Sync)</strong>: The client immediately persists the submission into <code>localStorage('vpn_user_reports_v2')</code> ensuring zero data loss even in offline environments.</li>
          <li><strong>Step 3 (Prototype Server API)</strong>: A <code>POST /api/reports</code> request is dispatched to <code>server.py</code>. The server assigns a report ID, captures the client IP, appends the entry to <code>reports.json</code>, and returns HTTP 201 Created.</li>
          <li><strong>Step 4 (Demonstration Log Dashboard)</strong>: In <code>reports.html</code>, clicking <strong>"↻ Refresh Submissions"</strong> activates an animated spinner, fetches the latest records from <code>/api/reports</code>, merges any offline cache items, updates the summary KPIs, and refreshes the live timestamp.</li>
        </ul>
      </div>
    </div>

    <div class="section">
      <h2>6. Future Production Architecture &amp; Telemetry Requirements (Separate from Prototype) <span class="section-tag">Future Roadmap</span></h2>
      <p>
        While Prototype V0.5 clearly illustrates the intended user experience and data structure, the following components represent future architecture milestones once the real measurement backend is connected:
      </p>
      <ul>
        <li><strong>Active Multi-Exit Probe Workers</strong>: Distributed containerized probe daemons running across commercial VPN exit nodes and calibrated against owned/consented ordinary-user baseline controls.</li>
        <li><strong>Non-VPN Baseline Monitors</strong>: Independent synthetic probes testing destination origins to establish authoritative Pillar 1 states.</li>
        <li><strong>Scoring &amp; Grade Engine</strong>: Dynamic population of the preserved letter grade (<code>#gradeTagBox</code>) based on validated statistical confidence thresholds.</li>
        <li><strong>Global Production Telemetry Cluster</strong>: TimescaleDB / PostgreSQL database cluster with geo-redundant ingestion pipelines for global consumer scale.</li>
      </ul>
    </div>
  </div>

</body>
</html>
"""

# Compile to PDF
html_file = os.path.join(proto_dir, "VPN_Access_Check_V0.5_Update_Report.html")
pdf_local = os.path.join(proto_dir, "VPN_Access_Check_V0.5_Update_Report.pdf")
pdf_artifact = os.path.join(artifact_dir, "VPN_Access_Check_V0.5_Update_Report.pdf")

with open(html_file, "w", encoding="utf-8") as f:
    f.write(html_content)

print(f"Generated HTML at: {html_file}")

cmd = [
    chrome,
    "--headless=new",
    "--disable-gpu",
    "--no-pdf-header-footer",
    f"--print-to-pdf={pdf_local}",
    html_file
]
subprocess.run(cmd, check=True)
shutil.copy2(pdf_local, pdf_artifact)

size_local = os.path.getsize(pdf_local)
size_art = os.path.getsize(pdf_artifact)

print(f"Successfully compiled PDF: {pdf_local} ({size_local:,} bytes)")
print(f"Successfully copied to artifact: {pdf_artifact} ({size_art:,} bytes)")
