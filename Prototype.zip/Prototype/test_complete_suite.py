import urllib.request
import re
import json
import os

print("==================================================")
print("  SIMPLIFIED VPN BLOCK CHECKER - TEST SUITE")
print("==================================================")

# 1. HTTP Static Serving
base_url = "http://127.0.0.1:3000"
endpoints = ["/", "/index.html", "/styles.css", "/app.js", "/vpn-logo.png", "/bundled_preview.html", "/reports.html", "/api/reports"]

print("\n[TEST 1] Verifying HTTP Endpoints on Local Server...")
for ep in endpoints:
    url = base_url + ep
    try:
        res = urllib.request.urlopen(url)
        content = res.read()
        print(f"  [OK] {ep:24} -> HTTP {res.status} | Size: {len(content):,} bytes")
    except Exception as e:
        print(f"  [FAIL] {ep:24} -> FAILED: {e}")
        raise

# 2. HTML & JS ID Synchronization
print("\n[TEST 2] Verifying Element ID Synchronization...")
with open(r"c:\Users\arbax\Downloads\Prototype\app.js", "r", encoding="utf-8") as f:
    js_content = f.read()

with open(r"c:\Users\arbax\Downloads\Prototype\index.html", "r", encoding="utf-8") as f:
    html_content = f.read()

ids_in_js = set(re.findall(r"getElementById\(['\"](.*?)['\"]\)", js_content))
missing_ids = [i for i in ids_in_js if f'id="{i}"' not in html_content]

if missing_ids:
    print(f"  [FAIL] Missing IDs found: {missing_ids}")
    raise AssertionError(f"Missing IDs: {missing_ids}")
else:
    print(f"  [OK] All {len(ids_in_js)} JS element IDs match index.html perfectly.")

# 3. Presets & Scenarios
print("\n[TEST 3] Verifying Presets & Scenarios...")
expected_presets = [
    "netflix.com",
    "ticketmaster.com",
    "github.com",
    "chatgpt.com",
    "down-example.test",
    "obscure-site.xyz",
    "hulu.com",
    "coinbase.com"
]

for p in expected_presets:
    assert f"'{p}'" in js_content or f'"{p}"' in js_content, f"Missing preset: {p}"
    print(f"  [OK] Preset confirmed: {p:20}")

# 4. User-Friendly Simplicity Elements
print("\n[TEST 4] Verifying User-Friendly Simplicity Architecture...")
required_elements = [
    ("searchSection", "Single-Screen Search Hero"),
    ("domainInput", "Direct Domain/URL Input Bar"),
    ("loadingSection", "Quick 850ms Transition Spinner"),
    ("resultsSection", "Instant Verdict Section"),
    ("pillSiteStatus", "Clear Website Online/Offline Badge"),
    ("pillVpnStatus", "Clear VPN Blocked/Allowed Badge"),
    ("resultHeadline", "Plain-English Summary Headline"),
    ("workingVpnsList", "Recommended Working Alternative VPNs List"),
    ("reportCount", "Live Community Signal Count"),
    ("btnReportTrigger", "1-Click Crowdsourced Report Trigger"),
    ("btnCheckAnother", "Check Another Website Navigation"),
    ("reportModal", "Simple 3-Question Crowdsource Report Modal"),
    ("techAccordion", "Collapsed Technical Accordion (Out of Normal Users' Way)"),
    ("btnHeaderReport", "Direct Crowdsourced Report Header Button")
]

for el_id, label in required_elements:
    assert f'id="{el_id}"' in html_content, f"Missing simplicity element: {el_id} ({label})"
    print(f"  [OK] {label:42} -> #{el_id}")

# 5. Core Copy & Usability Checks
print("\n[TEST 5] Verifying Plain-Language UX Copy...")
copy_checks = [
    ("Is it down, or is your", "Hero Headline"),
    ("Did it work when you turned off the VPN?", "Critical Verification Question"),
    ("What you can do right now", "Actionable Guidance Header"),
    ("Turn off your VPN", "Option 1: Quick Fix"),
    ("VPN GRADE", "Clear Letter Grade Label"),
    ("Illustrative Telemetry Schema", "Collapsed Technical Accordion Label")
]

for text, desc in copy_checks:
    assert text.lower() in html_content.lower() or text.lower() in js_content.lower(), f"Missing UX copy: {desc}"
    print(f"  [OK] Verified: {desc}")

# 6. Standalone Bundled Artifact Verification
print("\n[TEST 6] Verifying Standalone Bundle...")
bundle_path = r"c:\Users\arbax\Downloads\Prototype\bundled_preview.html"
artifact_path = r"C:\Users\arbax\.gemini\antigravity\brain\3032b61f-a6cf-4a18-af31-464b02d2c35f\vpn-access-check.html"

assert os.path.exists(bundle_path), f"Bundle not found at {bundle_path}"
assert os.path.exists(artifact_path), f"Artifact not found at {artifact_path}"
bundle_size = os.path.getsize(bundle_path)
artifact_size = os.path.getsize(artifact_path)
print(f"  [OK] Local preview bundle exists ({bundle_size:,} bytes)")
print(f"  [OK] Artifact bundle exists ({artifact_size:,} bytes)")
assert bundle_size > 50000, "Bundle is suspiciously small"

print("\n==================================================")
print("  ALL 6 TEST SUITES PASSED WITH 100% SUCCESS!")
print("==================================================")
