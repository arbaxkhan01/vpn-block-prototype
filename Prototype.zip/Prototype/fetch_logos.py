import urllib.request
import os

domains = [
    'netflix.com',
    'ticketmaster.com',
    'chatgpt.com',
    'github.com',
    'hulu.com',
    'coinbase.com',
    'disneyplus.com',
    'spotify.com',
    'amazon.com'
]

os.makedirs('logos', exist_ok=True)
headers = {'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64)'}

print("Fetching authentic 128px official favicons from Google Favicon CDN...")
for d in domains:
    name = d.split('.')[0]
    url = f"https://www.google.com/s2/favicons?domain={d}&sz=128"
    try:
        req = urllib.request.Request(url, headers=headers)
        with urllib.request.urlopen(req, timeout=5) as res:
            data = res.read()
            out_file = os.path.join('logos', f"{name}.png")
            with open(out_file, 'wb') as f:
                f.write(data)
            print(f"  [OK] {d:18} -> {len(data):,} bytes -> {out_file}")
    except Exception as e:
        print(f"  [FAIL] {d:18} -> {e}")

# Also fetch DuckDuckGo high-res icons to compare
print("\nFetching DuckDuckGo high-res icons...")
for d in domains:
    name = d.split('.')[0]
    url = f"https://icons.duckduckgo.com/ip3/{d}.ico"
    try:
        req = urllib.request.Request(url, headers=headers)
        with urllib.request.urlopen(req, timeout=5) as res:
            data = res.read()
            out_file = os.path.join('logos', f"{name}_ddg.ico")
            with open(out_file, 'wb') as f:
                f.write(data)
            print(f"  [OK] {d:18} -> {len(data):,} bytes -> {out_file}")
    except Exception as e:
        print(f"  [FAIL] {d:18} -> {e}")
