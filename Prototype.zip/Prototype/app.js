/**
 * VPN ACCESS CHECK - ULTRA-CLEAN & BALANCED PORTAL LOGIC
 * High-performance, human-friendly, real brand logos, zero blankness.
 */

(function () {
  'use strict';

  // --- AUTHENTIC OFFICIAL BRAND LOGOS (100% GENUINE HIGH-RES DATA URIS) ---
  const REAL_BRAND_LOGOS = {
    "netflix.com": "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAEAAAABACAYAAACqaXHeAAAFg0lEQVR4nN2a228VVRTGf2vvObRAgUKxxXIp1AAmRk2MPvmiMcZHQmI0RHzxHzH8Gz6ZSNAXjbxqIi8+4ovGBAgitNwK9MKdnpmzlw8zp61AsWtm78PBL5mk5+Tsy3z91rfXWjNCTZxdN3J/o2PDWn8fVBY7i8WOfSws/NdvT67botb9HGrfFusYAFdnEMANCWu+eQAnOpANyCd110uF2gTMhmAfJP7zuuulQm0CgsCc2pQqGt79e3B4b901U6A2AR6YUaMKRMTjjtZdMwVqEwCwgGIOBJX/DwEAM0YvcMLBqdbIO03XjYVGBHjgujUMAJ/RN2bYmIA7wKJxXEA+PQVZk7VjoXEIOJSrxjAQ1dH9A1s/arp2DDQmIEO4ViMMOuL7wgwbE+AF7qty15gTOOXQGbZvarp+UzQnAMgEpo0qENH1Q4Ph46brN0VjAqAKgxqpcVglJyiMamqCKAR4lBy4GYxhgL43zcjOx78vYmxqzXuIgIwyDKa0Yxso4ljPZ49//cIR4EWq2gCMFKDKE2FQUKu0r4UoBEDpA0EDV6ypMbx+uTX85srvclWKHtlANAI8SibCVJ0+gXP/So1zVYoeiSCeAqowuKmBR8axwXHkyxV7KejdSRBRAaUROhEuBZsTOJXxLwa2fdD9XADtFy0EoCTBAxc79jAQkaUwyCszzXuggqgEZCJklI2S2+Z2GYdPU3aZCyAHOpLeCOISQBUKwAVjGIgwNDa4/TCU//nulRrRQyCTUgkX65wG6FEoFdChNwlRVAJg2QceqHLd3if48AIbxwKlD5RXWhVEJ6B7HGYinLeqQMS3BgaOQHUUkj4rjK8ArWoDhKlOsHeNq6QoVy3N8MVTQHl5lFzUnBmK6ltbRZZuPrUPRCcAWAqBlgjnOtbyCA44TwAKJbkKkhDQ9QGvcFkDbWw3cMCX28rRSgXpfCCNAlSrHoGAwl8dGwFDIow7oUDIKZOiVEinAGHpOhvskXzQZeSqZT6gatTQ2pGEAOieBEpLhGtBuWeM40lfhlFOWh9IR0DXB6q/zxkLpHUIE86Rq9JO6APJCPCqSyQ4Vc4ZawOA/d5RJK4Mkyqga4SZCPOqqPCbZY4J58kQ8uo4TEFBMgKgqguqEwGAoN9YxjvgFe8opDoSY2+QxARkyLIXiJAvLn6H2nrnB7yrTgNJEgZpCZDlEtmrMsn9GRX3k2WOMXFs6IZBghhIHgKtFV4AoNIxhQHAPueX6oI6XYZnISkBUBZFXRUA3Hg4f1KVe5Y5DnpHp/KB2CroAQHLJwLA2/BAhO8tc2wWoawQhTzyWZCcgJWFUReiHLfOs1dckvI4PQEs1wZdfLU4+0sQvWqZZ9I7uq0yY231TCQnAJYfm3VxDIIGTljmGEQYTaCCnhCQ8eQrYU5tSRHAPufoVN2iWOgNAZUPrMTu9vzvAf6wzLPLOYjcKe6dAp5SzDkRkwo8VI0S+3sIq6EnBABPKABAH+oJ1PZ21YT4qE+NekbA014L3c3slQCnLPOMOqHlXDQf6B0BqzzotIYBwM6IRvhcFQBw75H8gMoDy1x7xC09Qm+KnhGwGl7l1l0VTlrGbBZhY6Ty+LkTAIDaK8Rx56L0CfuCgPOL8z+ryA3LmF3ORXmPqC8IeB8KRb+1jBkAhiOYYV8QAEAh5grx5ao2aIK+IWBPfuu0qp6xjBlzjqa30DcEAIjYVOCBbQ19sK8IaNM5jto0PSZlw7Qu+oqAyUcLl1Tcr5YxI+LwDY7D3hGwxmzPEb4Oqm3L1COuPgG1R/7YGr6tMI3TaeCKV64H1WuIzBBktiP5nM/DXJuHd/6Eu8eMHe3T0HqJLUPFoNuUBdkkLoxI8NtFZFSFHQrjCjvbhDfagS2vtec217mPfwAOJRjmybblSAAAAABJRU5ErkJggg==",
    "ticketmaster.com": "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAACAAAAAgCAMAAABEpIrGAAAAaVBMVEUCbN////8Fbt8AYt0Aat8AZN38/f/4+/4Aad46jeaHufAJcOABZ94AW9tqqOwRdOHT5fmy0vVSmul3r+4AWNs9iOVjpOvN4vkgfuOrzfTf7Pvn8fycxvOVvvEbeuLy9/1Gk+d7su5WnerGMgTYAAAAz0lEQVQ4jc2RyQ7DMAhEDZjs+540TZv8/0cWR+rN+Noi+cQzzAzG/GMhhtuGKdS3ZNMq1K+zBlpWl+TcQQw9534CCx4yAcaSEx+ByTh1M0BcXdPiI5BWiADul3pl5NvdlHrU1gPYuprcjH3qL+v3yMNTgKUkVlyimd141MLG5HiBxKR8F4DfkkJGao5IpwCdHjTyKjEtibrCWNG4qRLdiE0Ao5qUmiWG9twP762cyAyiKIJG3WCwdbd6qkbRFqMc4vBd6jujIKKAT8eEbP6qPpK3B5LgqIGSAAAAAElFTkSuQmCC",
    "chatgpt.com": "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAIAAAACACAMAAAD04JH5AAAAaVBMVEX///8AAADw8PASEhLa2tpDQ0Pf399JSUnz8/NYWFj7+/vt7e2AgICpqan4+PjDw8PLy8uYmJh1dXW2trYkJCSgoKDR0dFlZWUZGRm9vb0sLCw7OzsMDAzm5uaRkZFRUVGJiYk0NDRtbW2Ij3fQAAAICklEQVR4nO1b65aqOgxWRECgXAUERcT3f8itQ1uSXkGdOWudZf6NheajuaeZzeZLX/rSl770EoVB8N8xz8gtLpqmiK9Vmvw186htdltAu5H04d+xT2/HrUxx9kfs3ftFwf55DIe/UIgoVnOfiPy6HFzfxH+7Lfrf5d8K/C6nkyCPY73ZOL1XxkVR3PK2jz5qIOUJsBoLUrZp1pYkHiGmMvcBqO5euR/jn4J9b978baGTHQxi6Yb2M/xrbnw+kRfvJtX4CISAH/QtUiyHqco5cIpV76wjdspHtcPpCxP/B6Vv8i8Zf6VOhXln4b/d5m85iX4/7dIp+afIPezGIb4SksfNCM1m27wDIJ/2OKn4u0gBD7k3L0WkABje8dV0i6tiKYbatyMOXg09AK94mX81bXCWFgICXWGnArjpG/5A/CL/hJpAKS6kyAPFGqcXVlwOL9pCNm0wCMYcNZD9YEgIMvbQ+bVoRW0wx+xzyH4ve0dI3E3dXwJAkwCEvkWmd7V5OsKe9CwPyhR5VAU78KN7BtwvS9KA24tHkBCuZ7MjCWKo+4OkWS4hEiSHQr7Ua9iHBLhYLuUE6v6xFF1sf3+kzEcpZLFsRmmqGiqRnDl0Mv+2y0U+XDePJc6GQgr7tJw/UvPtlll5Mvu2g2T5LVCOAa+Wwj426sUElL3osAXZ8jPhnQLp/DoZSPwlAIUYW3o5Z+9gpk6Xl0VFb5x3uSgBXASLDiqJ/ZOOGYdQT7/4SxKDYBblnvhKADsc98qzyJrLgWmvOxWU4wJflMwJ1s1h2ZgJgIfCwja/okO4TvZAs5rjAk/AT/P4dDJWAP1N4hfFqH5un/oSTRud7CHRYe+dfvTcBqBCp3+nz9VIi5vHZwfTMV3sSToz9HE6LCOAMEXsfXC+7QhX4n5TLASQsfyBbmYCUKN03McpS5RDOZxIA47VQFwDWfzXA0iEXoWUcvVIOSc4ViX0mNiYL9cACBKCFO1JnRSaaqluHG3Bm6k0Pyk1gFPZiFs/qRBdPc5bH+Rb+G+oBsweUw1AS7H4hSEWlC05Z1X4LCkrgGNFRvBnV4ltCVS72ABQJwbKGBuA4pETBMgXSXESGas5fw3v0lNmAEzoHoqFdynqA3eVi2uQaBiG3sIE4NzOap/uoVhucqrGF02G6E4KAysIPYCzcJoEQtgRMWHgTaazISDSoD0A/FoAlWTREUoKGlEVUpbjGpJzCuAAftIAKJSf4UHffLkLOWvGDFIfD7KlAHaaaj9EXYmtkDYzIz876rfXANBsEQj+WQhQzFy1tsh04GMAHl8Lld6hu3W6arKePLcPDpi+wkS+GgD2zkwIUrOBEk2HYcykAFisXQbAr2DjrANKR011rwHgyN0QFlBjbwWAfRLAdOQynzg7Ap0voB4VuEsedkeyAsBjuQYBe66HIno0OjUkkpKAYnTM1gB42NTA3gRZQI5FKhJLiObkOYJqde2TFQA2AStJgchpoX7QuQJZSTLo4k/VsAIAFznYzp1koK2QGGZQPwQ37N7WAPAuIoCABlxdTOzpiaPOqivllosB7EQAzKy0QZlFtAr9mh4+DUBbH/TjVgUxIEgOlmD0DgBud6NwSEEB7eFuDMfviGCzGTQINhlqzZsSEgOAcLAC4BdUEoKkhDm+ISUzAOin9FR9+UJpvqKTu6BXGGVQUgqzVQOAdjJMsfeNac7tzpW4hrIuTVpuAkBVzFKggABwrs0Vp1yYGAEE9GVjdfAg+Jly/olqMaE0swCgOZfBCmUA2+4qHoIjfvJiADRGW1u2A97w2IoVp6e8q2xaiyNitye2+6NI6vs1ohxC3AT6+SySJGZXnLAkxdYyrhV3wVLlv8FyOD4FZYkFrAN+t00WsIsq1DIfBcfTIjlNt2ZmAC47KuvMSzq9V4Qu6sTANpyHjNGnWxoBeMxV2m9uKIAmEAMxM0ncHp1nCkwA6pE+ftFWZjOASQQ/iVuAhkfGH9dYwjQNVoAGAC134uYmyQ9RJfQnvUuuUCdPpBzBn7sCenUtgGg223jBbAutkDpme7V2QuGAm88aACPAPCy5Rg9paONKF9bjVkEn0UGxJFQAAMhfdn/byNKSLyWOuXiYiSYjmqlZOE9ClRzVkP0V7yX3wmrmGcS0fJbY0nkWFrSwwQT3+YMGiT3wGdzTuZi/lF3oiXISb9nY1JLcl47yk4IRArBqoojKQKqgkvK8u3SV6EpClC3OVQ0cwFo3blfTI1DEzTqTDDnFYWE2NJ6pHcq1k20sBV8wKxkVUNXOUDmo5VSe3fuKxNRQvKKU2SPj8JGcHe0xLiAWhPZmz0F0YeFJNL3WtaTM5DG12pl6u0j4opdxptVu1djCTDwKnnThy0XVwEG6k6TNhtdmVzYwNRa7vhPhITapPc5VcEH41RBIh6SMsEe3ZkeVnrHzeZk/k+EPjTGYTQnKGIWmRpXlppd3D2CupakudE2cE3Itzrhp5CsvpJkT9N+ap0xss5IPHVcPK3In/OY0ZagejZipUH8gv7B8fYqPUWQ8hGOr+v6I91IWjWzYqB1MEO6ymyG8WdGtnx7TQDDNrR6yaPYBQQ+bKC/6QAW5VbGfY15XEDTq3TVXUqZpW5IcllLdu+O8iJKo91ISF1eSef0juNfioeykYffPTZYryTbOfP/1/3kI5RkGQKtToJcgxDrl/O3/duDkKrtFxUe1z0I9GbEkxttf/tvPDyVpdTscDk0R33Lyy6qvJcdxgr/+8C996Utf+t/QP2HAaigVBPa0AAAAAElFTkSuQmCC",
    "github.com": "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAACAAAAAgCAMAAABEpIrGAAAAb1BMVEX///8kKS74+PgsMTY+Q0f8/Pzw8PGRk5ZNUVXr6+xDSEzCxMUpLjLV1tYuMzc/Q0i3ubuUl5lbX2NTV1uLjpFKTlKxs7Xh4uOFh4rn5+h3en1vcnZ9gIPc3d6/wcJzd3o3PECmqKpjZ2rOz9CfoaRP5W5KAAABU0lEQVQ4jW1T7aKCIAzdEEUTSUuzLMtuvf8zXtiQVDx/lJ3DvgEIEPU9l1rL/F4LiFEMCQYkj2JDC6VxhaRJl3x2xgin7MePMuYRD7cQftrjrcL7ELk9nNt8yXXtyRm5mquzXADKA6LpzgZRlgBPZ1WO7yn/yrmqyGdGn95Zjav2hbNghZHMV3uNG3DZCigEmhRq+pmyrUAcifj4CO+49xciWqAe6p3pCJrNH1ATp5gH6KghQLrDnoB8GxaYPYFkhpONipjrl+wI61hQ8tB5EvYb4eTL5Ebhd8u/2f4EYfhvvWJpw9ZJ0LQfb5uxbMKi3pp5xVp30miexZHbRriHvUnojrKt7isXqWRBFQQNF2w3aYCPUl8/EREWzxtuE+pVI/wbkSGp0a51Nyg1F+L5/nel56xXgt+zcMgeC0FK27gdTzVoPXtI9DBuO2tRhJj94m3/A1GiDZXoM3d5AAAAAElFTkSuQmCC",
    "hulu.com": "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAIAAAACACAMAAAD04JH5AAAAbFBMVEUc54MAAAAc64UWuGgSk1QWtWcDGA4RiE0Zz3UHOyEQgUkd74cLXjUWvGoYxG8b3HwCDQcDHRECFAwHNx8UpF0RjlAa13oEHxETnVkVqWAOckEGLxsVrmMIQCUPfEcJUC0FJhUNajwLWDIJSClJToArAAABz0lEQVR4nO2W6XaCMBBGIbJJKEFBZHOpff93LCTBAokCpZWenu/+m2SYXGMIYxgAAAAAAAAAAAAAAAAAAAAKhArIi55T6lhmVGOevHmVyIY/Fx3thQa1AGc7X4CzX1vAgQAE/pEAJZLO5GCEfoV9gWGiUmlcIM5cn3PIWXu7keQshmTMCh6e06EAscVELhNTUcpPZwh0CUJRiF7kQCsgw2a6L+CL4CwSSSgTp/ytOgHTqSgXCER4HBVwReBLAW+/UMC88j1oBXZzBcLFAmbR3YE1BJxmkRcLRE7N3eDt5QIXe1NTBWsJXENxy7ByJYH7VRxDQBWYfBGdf3cHyKiAS0Xid27CZwJmKj5u+ZhALE9yYv6QQCELnZIGa9ep2xc4yJk454nlDwkQz9SSKgL667RMFwoYRFuXn8lBR7TVJRbjy48JFLq6iSpAdYnRpG7tuYB3UusGzFAECNNswfuUDXguUL/Rt2HZD0/TE9aql2Hijc3qCctWQJ7gTfvuZ2W3quPLg0VsOVK1ie61l2hNW7/+Jb7bkDE5kPHQv79BhNmWK7HytG11iSeeO3QSq24inbS88bCj1jTn/WF15EEiAAAAAAAAAAAAAAAAAAD+Fp9KSR72HWYlygAAAABJRU5ErkJggg==",
    "coinbase.com": "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAIAAAACACAYAAADDPmHLAAAM3klEQVR4nO2dPWwbRxaAvxFchQeEKcLWy5oBTBfnK7W6NjlYbpxS0nUHHGAZF+S6E5XugjtYBgKki6QyaUwDvvZIl6cUpoGw5rqli9sAp7RzxduVKIZ/Mzs7u0vxAwjBP7uz4nv73puZN+8p1hCtdQC0gbtAE/gQCJIPEz+niYB44vMOGAFvgVgpNcjniYtDFf0AWUmEHSIC30aEW89puBgYIArRBwZKqSinsbxQOQXQWtcRYe8CD5n/NvtikHzOlVL9gp/FmMoogNY6BPYQwef1hmclBrrAS6VUt+iHWYVSK4DWuo285YeUV+jziBA3cVx1N+EdrXWote7p9aGnxYJtWIReP8FPM9Ja7xX9PZcOvf6Cn2akS6IIhcYAWqZwp8g07jbSBZ4WGSNsFTGo1rqutT5CFlnCIp6hJOwCI631kZbprXe8WwAtwdApxc/fy0YEHPheS/BmAZK3/hnQYyP8WQRAL/mOvOHFAiS+3qvgozEMIng3hsEI4l8geg/x5fVnknpt4vMB3GtC82O424CgAW1vTy6PD+z4iA1yV4Ak2j0h54Wc/hBe/yQ/B9GvBZyVek2UIGzBdgvCT9zefwYxsoh0kucguSpAYs4O87h3fCmCPv83dH90L/Bl1Guw+wAePpCfOdJRSh3ndfNcFCCJaF+QQ4TfH0L3As57/oU+j1QZ9sLcLEMXCRBj1zd2rgCJv3+B7Ng546wnQu8PXd7VPe0mHH4KezvObx2RQ1zgVAHyCPbOenD8gwR1VSJoQOexc0WIcKwEzhTAtfC7F/D0tHqCnyYHRYhwqAROFMCl8KMxHHxTflNvyu4DeHYgCuGACEdKkFkBXAr/+Hvo/JD1LuWm8xiOPndyqwgHSpBJAZJo/w0ZhR+N4dHXsmBzGwga0Dt2Yg0GiBJYzw6yLgVnXtN//gruf3F7hA+i8Pe/kN89I21kxmWNtQIku3m7WQZ/+h0cnpZnPu+T+FJ+9+PvM98qzLJ/YOUCtNZPkOVdK+JL2Dm6XW/9ItpNePFlZpewr5Q6N73IWAGSoO8Nlmv70ViEX/XpnWscxAUxcN80KLRRgBGWfn8j/MU4UIIIUYKVg0KjGCDxNYHZMwkb4S/HwXcUAEcmF6xsAZJMnp7Z8wgb4ZvhwBLsrJpZtJICZJnvb4RvR9CAN/+QnUYLIlZ0Bau6gCdYmv5HX2+Eb0M0hkd/t748YMU8jKUWIIn6rSZsT7+Dk3/ZXLkh5fAz2UOwpLlsVrCKBbBaZHj+aiN8F5y8kjwIS06X/YeFFkBrvb/KTaZJlzpv4wpfHtRrEg9YBoULA8JlCmA152/+aeP3XRO2oPeV1aV9pdTcbIS5LiB5+wPT0aqYvVMF+kPrzaNQLziZPNcC2Lz90Vje/g35kMEVzLUCMy1AojGB6SgZpi0bViC+lGwpC+ZagTtzLjBaTgRJ3hxEplf5oR3A9ifysx3ImzT9FkVjOTn0dgRvIvlZxt+nP4T+T1bp50dIxZIb/MoF2M77yxb4ha0kV3/HejWNaHzte8ukDO2muAIL7k+XupulAGdIMaaVOetZmybnhC3JuQtbbu/bH16fTSgDZ3+2yjQ+Vkp1Jv9ilgIYB39lePvzEvw0g1E5lreDBoy+Nb4sVkp9NPkXN4JArfUuhsI/6xX7ZdRr8OyPMkfOW/gg5nf0rbPMXmuiscQChtSng8HpWYBxjt9xgWnc6Y7Z4af+x+48FkVwlOdvheV3f8O9TyvAQ5M79YfFvf1pIFSkABymd1uRzggM2Z0sR3OlAIlpMMrzOysoINrbybRX7pTUCnkuIHHFyx+NL0lL7QI3LcC+8eD/MR48M+2mRMBlol6TGKQIS2D5El65+kkFuGdyh5cXUnbFJ6nJLSP1WjHuIL60cgNXrn4LbtTXX5kXF8aDZiL9gstg9ucRNOC0AOtk4QaCROZXFsC4mINv83/0ebEB36qELcni8YmlGwjhWgFCkyv7Q7/mP626URWOHvtV1rRekiFtuFYAI///2tznZOLFl37Hy0q95t8VWMhkGyxdgM/iDfs71TD904QtPyuTKRYyCQC2tDRlMJr/+zzU+cSzP3WJz+ViCxdQ11oHW1gI35f/bzeLW2BxQdiSqqM+iMZWSbj3tjA0/+/eGw9iTZUCv3kc/sHfWBaWubmFRd6fL7Y9+tC88Pk7WLycwR2kueLK+FKAdrOawd80YUt2Dn1w1/z7+vAOpjFAZDyIFT4j6LwpOndgAeZBoK/TPsHHfsa55VgogKcZwL3Azzi3HeMgMP5fPg8yzTr4/woQGJeJ82UBNgrgh0K6hm0oDxsFuOVsFOCWY6wAPte2N+TPFlJRamXqv8nnQabxnW94S4lKawHebuoI+yA2tgAW681WlOk07hoT3wHemVzxkaes3HVqGeOgJPxKbH9ivIfy8x2kyvTK+ErQGIxk36HMaeCrMBj5a4NzUjNWgMjYBfhcoSvLWfws+PwdLPZPzBXA5yZN1/Phkzzomh/asKbdNL5ksIU0HlqZoOFvJmB5+rU0+KydEDSs3GW8ldSSNYsDzDXNmiLrD2TF57NbxGaxUmqQrgNEJld6aJ1+RVWtgO/KKRYZVAO4Xgp+bXKl72TNKloB38+8bf5SvoVrBTCKA3zmu0OmMqmF4LtcbtCwcgE9uFaAvunVu78zHjATnYrUIB6MoONp4SfFMoH22gIkgWBkcrXjtuhLSXsNlrkEfdoC1zd7ofElg7SRxORm0EuTO7QDv24ArvsPlZFUQX1bqaBhFZRfufxJBeia3KFek5O7vhmMylOVNKUo4YO1+b/qMDqpAAMM1wMeeo4DUs565elIklqlotrgHpmfOoonO4hcKUDSYszIDfg+Az/JYCRKUGRgOBgVK/ywZbU3c8PSTyeEnJnezXcwOInDNuzGpG3vi1RASxd8QwFmFYv+L4anhcpQLNpRB+6l9Ieyv190voJlsehIKXVjIX9WSthz07ta+CHnDEaiiAff5JNN1B/Czt/kU7TwwfrEcX/6L2ZZgDbSJtaIMliBSdLKYtt2fhKQIPO8J9vSZRB6iuXbDzMaSc5sGqW17mFYOq57Ud6eQe2mKELzY8lnCBo3lSK+TD6/iCUZRPB6WFxwtwzLZhEzG0fNU4AQi07hZTGP68z+jnUJupkNJBe1jTO2Apu2cflj2aPgV8FfyqJzAcZlmYMGdMpbDaPyZKhA2pn3D8taxxpbAYD7f9nk9bsmQ+A39+2H5WcDrYqzv/ir/42idSatlG5JZ9E/LlSAJGjom44YNEpdGKlynBxYm/6uUup80X9Y5Wzggc3Ih5/5L5u+jhw9zrTc/nTZf1iqAMnCgZUBenawXuXefBO2MgXVx9OLPrNYGASmJF2m3mDRUDq+LH7TpIqkzagsj8ZFSJvYpdv7Kx0PT25k5QqK6qVTZdLeSBnORR6sInwwqBCSBITGG0VQfH+9KuHgu3o+a8VvHiu5gJQsrgCus2c27mA2DoS/cM4/C6MKIYlZ2cEwdSxlYwnm4+C7SWVjhHGJmCSyXDq9mEf6i1a5EYRrwpaTNrgrRf3TWJWJU0qdYRkPQBLh/nOzTgDSEqf3VeZCGMdKqRObC41igGls9womOXklKVa3rSpYvSarpQ66onSVUo9sL86qAHUkb8C48eQkty04dJi/GLHifH8emSqFJgM/wvBY2TTpTtdt2D84+txZ2/sISfKwFj5ktAApSR/aHpbTw0misaSWrdt2ctiSTB5HM6AIEX6U9UZOFADcKgHI6R/fx6zzIG0o7XBPJMKR8MGhAoB7JYDqKkLQkNRtxwdnIhwKHxwrAOSjBFAdRQhbkriZw4mpAfDIpfAhBwWAq9nBKbDr+t79oSjDy4tyHA4FmdLt7cDug9y2v7sYbPCYkIsCpGitO0BuJ/q7F/IpQhnqNdj9Lez9PqmVkF9F0+dKqcO8bp6rAgBorQ8RJTA6b2hKfygt1PtDmUG4Voh6TQSd1uP1kOgSA0+TVdfcyF0BIL+4YBGDEUTv4d0YRu+l/Hx6+ic9CTRJvZZ8PrguhtluSnX0duB9AyvCcbA3Dy8KkKK1PgGe+ByzgjwHOnn4+1l4VQC4OnZ2ikdrUBEiJNDr+xzUe9Oo5Be8j2Wi6ZpyjKzp930P7N0CTJLEBs/IYbpYEfrIWx8V9QCFto1TSkXJVuYBGTeUKkYfCfK8BHqVQWu9r7Ue6fWlpyUG2rAIrXWYfFnrQk+XVPCFxgDL0BIjdIBtqjdriJEpXVcpZVSM2yelVoBJtNa7SLD4kJxXFTMQI+v250VE9DZURgEmSczpPnCPjOloDoiQAptdpAizlwUcV1RSASZJ3EQbSU5NFSIvCxEjAn+NbM/2qx7FV14BZqGl1F0dUYgmcDf5c/oJ5lwaTfyMgJ+BEdJcc1B1Yc/i/4OY4lrFhDeRAAAAAElFTkSuQmCC",
    "disneyplus.com": "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAIAAAACACAMAAAD04JH5AAAARVBMVEUIHisfWGQiYW0VQE8OMD4YSFYbUF0KIS4LJjMNKjgQN0gmanQnc3v7/f4qfYjn7PUvi5bN1uKwvMg3n6kABh2KnKdpfIe06MCTAAANwElEQVR4nMWZiXqjvA6GBRi80JSawb7/Sz2SVxlMks7kPL9ISUIIev1psUkByCRtzY4eafc3ptgf7VTa4q6+QBcfMpn3Mr+Ow4LgQ/LTZPwA4lCzHZ8iuSIlj1neAlqcH8X9Ud7kv/riV35l8SH5G+Y647EQ/LMGErj62YtsOMpryTk+bBJO/vjQ69MT/z0tXuqT0wrY+C4gLVU6owl56+h3UeFDveRAO3p+6M5+mRIsqSRcvLTOefzfSIL3xK/+O6O8ouTXn0pCyZ03zqKTDkWN1Ofct7v6Lp0ie3T/7puNpel3dfC5G5+0/4T/U9e7PDhent4y1wf6UC/FZJo/00FuSYsyOcl/SgHWzQsKAFRn5QkahkLwLxVwjWa84i8WDzklf89QtG0zvY7tfQiZ4vAcoqlhVliyiNCM/PcrqAxxzsk6tcjmRa2xf1ivtQClXtNlc1RlXR6W4/mU8u0PQPABNUvSc1M5F9oHjK97mzgC/xSap89b96KsnqEcgM9I/hbAr0/5DMD/19EbAP+NgfqvAcptm0p3cn9hCr/NrNz3vQcgi+N425hRFPvk1m+4BITXZ3sTA+pNa5Gg3toylKtzOIKB1FoBvQFQOtovKCB6CWcq1SpQbqQvlwn+jnl1+26t3fDP7rv/WiRSRAhVIF7ICBmTCVG4r+LQQXQuB79vj47Z3Y1GayEEV0I+UQLS0JMGVYv8xfrtGHJ0P+6WnG3ozflojrSISHh4NFIkhqrDEwWSR+5OtXKUyxzH5MiPdX7WKQmy6WnMuljUQZjIoJ7LAKoOmD8xWXKSkHu/k8xehJTLaNGLps8PNbigxLZ/T8KYRoZuNgBL2KK6agKRP0TtUfrgHSLUyYIvLIUhiPSwX8acENKY+gCqOalGJrHAsdrH5nCQsjn1DIEYiLqGWNjvK4I6IXQAunaoHd3rA3pem2OEoAHWPQRiKAQMgdf1ewBw+O3h1dHzfWUI7iQMVCvbz9wVQeYWA4r1jFv/0j32+XgG26KROwEQcmFfGEHTI4MKEPzrtCnV4zk0Dv+p+zNDCIPQsJAIdjSTEXeZANV52inVkKJ//9jF8co9H39BoO9iGP4gQRbhNE8oCAfjg6RTTJCwkwfKf8DLMF0YQhgEJU9DcBYB0tRROHKs8u5wmz9ep8kNghBSUBj2qUuABjrPoFWGNPZY0vu2HgVJdXNEnT7Q5UAIg6aCdJFA6Pb7sgIwU5UIx4/+Y7PVLEnYZfj1GkqdczEQxCiclgtcgS4Exn8+miNFJ5a02bsudCqnUtBAHzYRiGsU7gCigV+PpycEbZoSrm91DoLQlAcbq0aGAAhImxbd68NzwILBQE5b1EBSLYw5DTgBJOfhUbfCo7oeX2lSEiYa1sKwtaVQkhGyv/72IUMCXxIx50ECCI5E2gc7M3wCAzsSlsK28iDEMIAo3uPimtbWDUdPil8z0VVqP+ISQBo5Op+GldaX6zCpE8VZlb8IkhBAQfgJlcAyLChAnxqHq9pte+AfLvN3j0t8YCGJ1PFcnYP1GwXoe7SeNKcg6OhFzmEhuYW1XHjacGFLGXqCwCkWD0rFsuW9gOCZakgScA0SgLbW+2FZlgGX+GGBH9feAyghKgQp5fHj3R/aZBVEuv4zjqga5aFdWgkSwLRtuOIJ6wM0Ee97KCD7dDAEcYzpfsgZaRITc/0Eg06VK0kQAaoC4Z2aPN5o1LHi0pcYKBb7AOU4uCgN7rZVFVlqkhaMM0eUQKYsECwGIOgWxlDPFcJkT4ZiPTsbVHAg4wc4NW3e0fhHWqS06dFkRe1tTAEdu9FoogSCKWCiU1P2qTK1DyrYkTCFmh/bjP7tcMD8sMfJbSnY0ttrVESqA4P6OREXqYkAwv2T4d5pn0rtULiwxS95iccwACv637WkdPIMoMnTU1QECwFewlonjClnkAImuuebNnYIETH6GEIc3CEM7A8aP92TOnzq+Gccl4/jARwI1WEpoRCC6J9TYNPaZVTFKIr8hu9jBLfF0K2flTxlnlqNDqmLM6RJADEIUQGT9xEH7yjsXHhwaU0agAASw1KX2LXKifMmRpJAut0NxhQNBAFkizrQTu0bllk5BvMWonC49DPICCxe8WFAvYMCRM/8U2tjw0+vsGvbzUMNDQxE4FEKbJR+gBq3gqBd+kJFEtdMMNQMw5SYS1EwBZgWBHAIUdhgpRli0CO2B4w+HpXpJzKddNL2Mcpw2fiL2UEfqMRU/IdWZueYhvEDmCgrJ+4dp2kEcPMwG6FUpAiZaLFZzQMewJs+Tz8K7btb0ZFEz1gi2yiMFHP8wWgf9aTmzSs8WeZo4ucuTAdVgqBAIEibopnA2WzOmzBIHCEGAefHfZsELOwnsl0q5w6jsER20M7mT/A8g6qIwzjrZR6dxtO2IQGYosBkkghaj45++cPBRQAUfg/SKr9Z9KBsSIU6JcS3Xgma0BcKcSHDNzb8sPB4fJNs1I/UutH6vEnCQBBFUOOehx5ebJHBk4QC321mwmoQW/2BbjCSihMJEA1LVTq6A6CfLd2Aao+pcCxeYBiGcRypuf98fa3rOkQJYEKLCJPy5JkujfF1yxqWBlT49BODxN6wrQu2pJVmaeyRIdXCVI4XDem1a4E3QduCaSgB+/4e/G/Lti349WhpyYPmdQ7BFP2bybp1wpyBGQXAKqCl4UwLEE+Z5h/4YiTn8SrE6jE5QoGgL4quEZRkzlHqYNpOFCwMDAKAu/yq6nVRIJqYrUZPyDKQAjLkBt4eWhsyH5Ng8zR6WDHJ0++i2JPQEaXeMCEILvvSGBeMzC7otacuMil/9r+tmmLAACa1Ox0iEgBUeGl2ygF8gd3RboPHkGDZjTTIlX6Ls6Syx2ZtsclFgLCu1ZgtI77DvKBkxMFOYWy4pNqGeQ4DDlMvBxCLdVpUgBAY51YV5UGjWrBiorQLvwnj5WYilCiBx6NU5vuyzJPSC76i5DhilcSFoJD4DTvFJhgnHg4widXuCzpeCEDHY5RmyEEz+eYOAlDOLgNlu109DRMBwnyF4yaQFfujoCYUkm2kOtyaPmBz2wv9Gqa5+J8nPeDyeNIzA4hkuDBBATATSQG3rQI03sagto8YoyMEf6dZKy6rnQrrCOvppwHUMPkMrbiZeVABjEjc8CEG7EEeAXYGIGDGtrBT3RDAjB0udSnsDQcBCIGJhj1qCIVG2x6ad7jTebji38RirfMeKlDcx80ITz0eFYC0TsDu7qgxUS6KEQEWPe3BN4lO9bUN1EPQKSxbOIovw+QQC5+mydxv8ejDaT75AHolhgSAz2KkuYQ08P7Lh0nH0p8HygX0i99WPrZMh8MY7E6tRC04F6kwbOwEoOfofdtXYNMd2ADAJj/I7qMRhMG7n8RAk0J4YGMUoSxHN5I7oacBZ0sdCiUasmB/xGLd/aQmSWlpRz9QWZWpDvV1bk5zT9JknovvjDEZGj9DwHtVZaaQJUYVh8awNE2v6X81eBuBJBQiFELkPp/mHLz1ygfiowIww1vl3YWJPTQcmgrmlKU5X28tYpmBkmEssKeNUXUBJuxEZc7EK85ZnCn2sJcUk6apC+stTTNFJFOe0lEEWHC7ENBQm/c5SSd+xj2IwFx41Eo23GcbOFhmvnVgrmypXk5RaUFw/I9BPBMpWVRgWegvI0SILsrUgGSO6RKXgVYz7/hHBYJFhHlJT8H7a0VSZPK7SmFWBNjh1mvVLgNkm6MS7HXheS8qCYQUoBSImlSNSiYVvU4ADUjGKYF5kSAVZDLYJr1h7po8nph4NwBnnJQkhecFyIyz1jZWZxOHY3+4g2GhbQl/t1LkNGVy5Dy5Me3383gzXIuQAIZlKS+eKzEXrucMZrocuh4JAMlxVSLhPMFo8+NFenTdMgB0HWxJf8NSt5ckDCXivG5kyZJ2CylQLMnAEVJoXoSlpscyP6dohAsPDtDYMjQ4ryIzL+2VO92Ml3NtODCMdwhMlpMo9yXD0oR3j3IoV1X9Cox4y0h3jUPcXqG8yo6Ze5pLhOa5pMzSIsAYCeLunmIpu2uqPhGjM+aTIcDJMkzAuSVZhktcnoTk8oYsXgXO3tN+4FsXJWvSROY949kN4zrSo2s5NzjKizx9AyOfFw1WtDHuuu7HkxpPMnW5dLGz29ppigWAyDD2KLqKlOcexLloz4ca9wjwtZ5t7GMMp0S916OGhLvOfpf2ZPgiW+nRMGRRboQYWK521agpeplsioXvRYBCcdUiCXIfGp6lT7KjtRpJ+PrG7YtjrJeojEWPW46XpdLzTjv4Rvv6bijOAeEI9zlyyo5bz7z3jwkgQXCK9ZkatyDVQQW5VHHJobEBqCBfbUS6GLlm7xpI7iHF5dC6rQY/aN8/F4gWo+ZHr2bXHgYrEe64vowKrkDuf64Up7SIMoTAoLNOioz3VXtynJ0nAvjJ7uOjE5FTkTCa9dw9xucZWgaeZKN9BvhhIBeGm6AkTYIkvd5xdls+Ks8E8Aft50+L0I1HisqFY72WSxlk08nqyLkBecetgbiPR0Q4Q6xfvXiwSrn6ZQDRIsKfczgCRjco3fzo9a8b9xkZsvuCcArHd96uuXmV46JDx+/KBMMtK1DsAtGiXO3UQpuk+MpO2ZjTI1fUBeCWoapxdX9SIiPUsRZ/F+sBsKhcOL77YnQrhI029bAOxg1ATYo+wlWLmyK9H3oB2O80iAR3SZG0uGDcUdzZ/wCzLcsJZdeNAwAAAABJRU5ErkJggg==",
    "spotify.com": "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAADAAAAAwCAYAAABXAvmHAAAJOElEQVRogcWabYycVRmGr/u8s9tuS0spBQrtzhY6uxW2xYAhkliIVIJRFC0aNCEIO1vAQIKYmJj4w2iMMTFi5MNEsTsFUYI/Skj4CEjEAIqiRIUAZXZ22860QG0FWujHtjvvuf0x22U/Z2b7xf1v3vM859z3ec95nuecd8QxQPtAvk2QxawQrHD0MoIWScwBbLOf6P8paKuhCLwhsb2cKxw42rF1pI7Z/nWtKK4ALsf+NGYl9hlAGyZMM1oKOoD4L+JVpGeAZySK5Vxh+IQIaN/cO1upV2N/A3M59mJ8hBMhItIOxNNI99t6YVtX38GZddEk2jfdEJQJF2Dfjvki0SfPnHE9JtpN4BGkO4P18tauPjfl1oxRtpSfh70O822i24+OaQMEbVXQHYj7yrnC3kbmDQV0DPZmncYfE30NpvXYsGwAcZCgBxXC98u5vu31Teugo9jTbXEX0Wto6oUeQwgTwtMEbqvkCsXpzaZBR7Gn22Y99sXHh2GTSPScgm4s5wr9UzVPGe6yA/kOi7s+cvIAqS8lclfHYO/SqZonCcgO5ucR/SOi1xx/ds3BMX7WafxhdrB37sS2SQKUeh3RXz/ha74eDERfS/QNE5vG7YFsKf8Joh8mOnuiuM0IQVtItLaSK7x8+NGogGwpPwv7N6S+rmFHwsAhpH2YA4h9iCFJh4BoCNgtmDbsOUht2HOBViAc1dtN1Cd0S7mrcAggM0bJJTZXTUP4INJbiH5gE1I/uKygXTZ7iN5L0DBJSGUbI0PiqlsUNFdJmOc0LkJain020IXpxGTBp0xbO02FyFoHHgCeHeEN2WK+Bblvitk3QU8S9BvgZeDtSufRV5BLSz2ZgBaAl2EuAFZjLsZe1kyyVBL6EN8sdxaqNQED+VWkforoM8dZBr2ioC+VOwtbj5Z0PSwZXJdJHM/CfAr7y5jLiD5tWoegbQR9ttJZ2JQBkLncnkAeUFBJGdVN5QCn91+vJChpbW0NGQUNR7uaHozVSLozd1/DFf/m8vVVoAJU2vt7Hg5BH7d0HfZXiV48ycFeClwGbFK2lG/DfojUk9d/0CbE2krXhiJAdiDfCizCtIM7QO3AGaQ+laC5CsyiFpqjzSHSuI8kvAvswrylwDZguwk7Y0vmg+0dv5pW3LLBfOLIJ2x/j+irJpXsiTaCrlW2lF9B9BNEnzNlT0HPIx4C5gAXY84DzsScBK4FgXpz/OGwhw8z7yIqwCuIF0EvSdpczvUNTeWeHexdRhofJfXKCbyKJPp8BnsF5vRpCURfgljN4eA5U3zok4BPqgknC6xG3IzYYfmlbCn/KPC0hsO28nnrR70k3rZUhgkCapPYmZG0wsS2BiQmF30C0DBiCPsg0hCiKsAmgz0LaRamDdwypXiTYC8BliBfidTvTPxDRyn/u3JnYTMA1diN6Z7s67mSVmQcvQyT1BVQI5wi7UIMAK8jFTFbSbSLatwD7JdUrZk6MZqjTJjv1KchtWPngI+NxP8zsWdPEJPBPg/5B5auyfbnNwIHbF9D9LIpGCVO3ZFR0CLHBmsjaDPi5wQ9C6rQktlb6fh1bCh6DNp33iq9P9Q2cvBfiXUJ+NNEurHnjBEi7G7k7pHfU8NA4LQMov7yEUbcWena8MuZEJ6Ibaf/0sB+YAuwZfGbNz/WOlRdKPmTNl/BfG5cHmpmvwXNzjRhZ+D9sQ/aS/mAmCd7ISEsIo0LiJ6HNKvm4SFC+IBEe0jjOyThXadx77auDdXDfexY8msD7wBPZAd6/kjUKhJuwHyN6DOaoA+AsqX8Q1Tj1xoo/aeCvm94T3Ah5iLbK4CzgJMxs7Fb+LA8j2hkg8P7iB3AIPCypJeQXgti15blfeOW4dL+3kyQLxo5j3ymIfug3ypb7LmH6FsbS9VeoAqeP6Pia1wfANqHGEQ8i/QY8PdKZ2HcG87293yK6Ecxp9TtK+iOjIK22k4bRiL7pCMiPa4PAM/FnA+cj+hBvJjt77kf6bFKZ+G9EcthGu+CqoLKGZsi6AA0SbCWESJoP2I3sBvpPcRe7CEgIjKgOUQvABYCC7HnAZlxtOyTMJ9BrCbwbEcpf6/hPaJvxyysz0P7bIoZxBuI/45kyHrEPyDo70L/sXgd2IzYQerdiAPOhGErTWnBHFIIDhli2koS5tdCp7qwLwQ+SaQbvGBUjJlF6issXwpKx4XV6bEDUcogbUN+FVhehzwE/YIQflLO9TV7HjhELWzuplZp/vPM19Y92NIa55PQjbkScxX2uaPL18xuLn4C4hVbb9bOA6X8baTxzml9RUrQ9ZWuDb8HWLqlJwnDmqdEC53GUwk6VdJ8omcbB0lVpH1O47tIO4GdBPZUlhdGw2husFeHopdgX43pxV7ZdHCoXXrdUukq/EoAHQP5lU79JNFLpnUK+hdB60ei0CrMcmAx5mRwG1KmRsACRUSKPYy0h9rrfl3S3yz+iilWOguj1Wd2IJ9V5LuO8eamypqgCkFXVDoLxZqAUm+LHe8lnXxtMUF55HBuPhLUrtN3IV6Q9JDE01tztciTLeW7SP3MSHFXH0m4l+BbKrkN6SiRjlJ+jVNvxF5wRORmCmmIwAuS7jE8L/iCU9/dMFwH/Y+gtZXOwl9gzK2EzV8JPELKDceX+eiAs0lZY3ERgbIjS5vJNRIbFfTi6O+xjdmB/AWkfnia8vWjR9CAgtaWOwuvjj4a217JFf498nFhRp95TgikIYJ+NpY8THE3anEfQQ8e+ee/4wABgfstHpiqaRKyA/mlRPeR+orjTq4Rakn0cQVuKuc2vDWxecrEUckVtivoNhI9d9wJ1kON/J9I9K2pyMM0AgDKuUJRQTcq0VM0nd+PIYQJepxEN1eWFwanM6ubusu5Qr+D1pFowwnd2GKIoHsl3VSPfM20CXQM5Odirnf0d4g++9iwnAZBgwT9FPG7Sq6wv5F507Fm2evrFFviKuzbiL667mnpSBD0jsRGpLsPVMNrO89d39SynXGwzPbnZwEXA9dhX4G95CiOmBFpO9KTEg8I/WNrZ9+hmXVxhOgo5VsMOcFlttdgVgGLRw4jmUnbvjZSFWkfter0lZE/e/yZxIOVcz68sTghAsYiW+ydRfASoEvQ5egOxGkKagPs1AcQuySVDUWkUgx6a/s56486MPwfqPQjL6clRWkAAAAASUVORK5CYII=",
    "amazon.com": "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAADAAAAAwCAYAAABXAvmHAAACWUlEQVRoge2aP24aQRSHvzeKpXTcwCnXckNukLV7Q0UVu4E7uHEkoHAK3wEnUoQbKkhqTG4Qp0ChC0fYjirjYnay62XBsPwZVtqvGfE0Gn6/9+bNIHaFBeg6ZYQamnPgFCgtmrsjAmCMMETTk3ue0iZJMqAbvENzC3zctcI16TLjRh6YxoMvDOgGF2i+sf9sr0qA5lK+8MMG/hsIxQ/c6FoTzYU1IQD6imOO+M3hZj5JwIyyPDBVABzxmfyIByjxllsA0XXKwC/HgrLyXiHUXKvIjFBT4TmfTzTnCnNJ5ZVTRb6aN0lJuVawKYUB1xQGXFMYcE3uDbxxLWAhng8nPngfYPLTxPqtuWnzBqrhpD8jmIx2I24Z1RZUmi9jnm/GFE2i6+i5RTphaNBOdb1T4gmEqAqen6onvQfuzsxYacL1Y7ToPui3IpGT0asJTK8AGMfXj9HnQTv6gl3i+VBtmvHuzJiwO6Ix9yfKkiaejMwC1oTdl5WmMbPNHok3rN3vg7ZZ31bfJjDB4grESWssy2QUnRLLTFlhEIlNxu16/Xa0Tkcv7cXVDECUiUVGtkFSqN1OtidTWN1AnGUVWRdbwYy9lc2AxVYlvndXwYreQh9tZiANa+TEj2L2TIetX47bN7Bncv9jrjDgmsKAawoDrlGYp4F5JVDA2LWKDRgrhKFrFZkRhgpNz7WOzGh6KnwC3nWtJQNduefJnELCDflq5oB/fILwGJUOU4Qrt5rWQHMpX/kLsXtAOnxHqHDYlQjiT+khcZGFJsocZk90mVGOi4eUt1UseXnd5hk+j8s+j9cPIQAAAABJRU5ErkJggg==",
    "nordvpn": "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAIAAAACACAMAAAD04JH5AAAAFVBMVEVHcEw+X/8+X/8+YP8+X/8+X/8+X/+7J2yvAAAABnRSTlMA3EojrnpsVdxsAAADC0lEQVR4nO1a7ZKEIAxbvvb9H/kORVaUQlPq3txM8+tmQEiTWL2V18tgMBgMUoQQfMHvn1/e26cYnXtXOBdj8t9hEXw87dzCxadJhETvXhDTcxwGtbc6PEPBs3YvHPStQLbfKKQ/3X5XQW37EPHtM7SykATlFxE0fJCWryWCxP0GiwzS4va/WLJhSf51Bmv2fyAOwqr9FU7EQKv+DIkGQa3+DIEGivVnRHR/hftviYH6/uDdGPT3h3qibgAPAEFUDuABdgweCMAOZgyeMSCDacJDBmSwTPDP7f9+c94THzMgw833BxPoQL5TCdAEepDwNAVgAiJs2UwCfDmQ8iQF4ENgExS8bce9AFtsbywS0qQAmAOltWI5HLZDcKkl2goO1FKwHA48wEo5LQRdN/AAquS8DpZDuhVADjRWQuGhPUCUbBsKZB7ZiyAhLzpCElAhQCJwkxGRgArBvAp3cLwnubJnuEF1gnkG0zGns0QdmddBpXBKINa09S7fBrI0nHV6mGsXDp+6JtaRaZiJVjQlsOvuKALb9aFSERDgXebfVIrqyLSUPoHZXXiUHUkT6wh3KYhA3TSQvSzUWZMcSgicfEv9u2AbKdMmdkoInG0ne1moI+McCgi4dibVyz4jwxwKCLSXOPKB5o6oAKtxCFxi78m3Gl+pjXIIE7jtl8i3mvqb5KgZwARulgeSwGdkkEO0FTP+qe6BXg8lIPz8REpKEaBiI/7BnzIBfB8QGvCiNaUIEIQXvv8RJtBtDKHLQl9UikD3CbL2AbT/UCL/N+tZtvjtsWsrObsjmDyBBZ2iaFM7dJe/QHeCRa95d2wpgTvusg5+IrlOln1va3GralTU1QOVUwhXE0aLXlqXggEZ7aJjVdu5SmcgWgnGVTVz1Y6BJKCq81St/ZtVZ40lsakiOAk7k/UTQ6UE7qj39/zGrhKoHkUKXAFe1S/dg0hHXZxHS2JKhaFYyyorKidwh+fnymsncEfkl5WUE1gA5Er5KFxB4r/cPHRG9csnXw0Gg8FgMBgMBoPBYDD8F/wADRh252T8RTcAAAAASUVORK5CYII=",
    "expressvpn": "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAIAAAACACAMAAAD04JH5AAAAaVBMVEXaOUD////XICn1yszZMjneSE/kbXLYLTXaNz7aNTzYKTH//PzrnqHcQ0r0x8n429zgXmPfWF7dUVf54OH98fL20NLwsbTngofbP0X+9/jplJfzvsD86+zjaG3to6fkdnroio3XFCDvqq7NpfT4AAADH0lEQVR4nO2a63LiMAyFc5HxJQm5kBtJIGne/yE3bAuELlBkiensjL/fTI/qSLKObc9zOBwOh8PhcDgcjv8VpUE+BrR6r7g0MskPm0cccqGWn7wpCgVQNHUa+c+IhvA4Fh5ofn0NWZw+Fb+wq8dEcq8CJK/KnyjDRgOrviy2+9f1TyH0OecimGRAyZ/YjYYtApmVaP2FI1cuQob4/GtmzRKBFr2d/rIGHBEo6J7X/hP2HUMm6mJnq79k4kGSA5BHe33f7xPqR9CtVQWciSZqQzIdRd/3K4+WBdrDt6BbNrQsMBNR368D0gK0lj3oSkmqRDnh9qB7ZIRvoEVF1vcnYx8ANKQa/KS2D0C11rvAiq39tgyj9S6worIPQCXCkiJcBQD2ZaDBEtNWHCtAAK5bGCEH7FFwTd8ZVQXaBBx8NNcGhuoDOqlDDtYNHNUJOVrvN0pMEWgR/vwXkfSY3ZCl9X6jQaQAT+u9ZUgQXwA27Bngx4gUVFCz6+9yxFAKOfsCRDHmuCSYufX9qkDYAp2wl0A5YpqQIVmgu8SYgRQE1QH8Qx0g9JU8cow/a7aoAwooyA7glqgXKFsIHW8NRjVOX4stq/6+a3G+HBrWDEgLg9NXLeMCRLtYY+2YHPn00zlH/vsLAdcClGGcA94IQM6iPmy7jdA2PkRO1XmcPJ8Jp7gptK/jJlvEteVlgbzM09lnAIP+wI7ihuO+5GIo0l/xU0syHL52pJ16w6XHzyiYv/pR1AXyNR/KekO0OpLZ95uXjHjimQBf9o8AG2M09I0gHAGsUZ7lWJxOTDcD1jNBNCM3v/sQjElUc5QNEM5l9x39ZsADijFIMR7oPkqTvGn32wHUxJuBBZo5DQU5ABlTAkgFuQ6goQRQ0QPQGeGGzu9b8iegHdGgjgIeAI29QR02DC8GtGe/BD29Cr2TRbXNgiHjeTIhE7sIypFwM3QbgagsXGLZMD6XEEf0IqSM+kse6MMRNZgMc8Y0kn2hQJ2eLL12ZhalXeaxj/B/H221Rfbw0daFXEjzrqdbGp69Wzvz3udrDofD4XA4HA6Hw/E+/gBwqTbKEFTKkgAAAABJRU5ErkJggg==",
    "surfshark": "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAIAAAACACAMAAAD04JH5AAAAKlBMVEVHcEwev78dv78dvr4ev78dv78dv78ev7/6+voMvr7W7+9Oy8ue39931NTLljiBAAAAB3RSTlMA4joavZJhbpmTGAAABBtJREFUeJzFW1mC6yAMK1kfJL3/dV+WdqYhBktgpvqeqRRvGAOPRxH6bhrHwc0anHPDMI5TX0aTQIdQR0IGMw39yJK/YSKhGwrZDzNMX6XfMVbR97X0G4YK/qnU9xcU26AfLejLFViY/4Xuy/xFYdCbuP8N3gSW3z+XRIFV/L0wsBVxsuWfHSvANAB2kAKMHbCBWxJsM6BAgL0ByDSw5+cEdA0EULWwgQdmR/A3CMEN7T3gd5gI4D2wMS/Lc0daAVGJuGVo++plDeHfiZD8O3w97Dn65/omP5C0AS6AWIc2+gv7hjUlAC+FsAf8fKO3EAAnoV/u9BYCUA/4p0CfEQDXYjQJV5HfQAAYAgn+egFgCEjutxGAhUDq+zMC0OUQCQGf5q8XAHggEf8nkpUQFQDwi/n/QnotAAUgISDxhxDWbTFc0qshuDXRQ0B0wPo824FMPwAKAKqAUP/nHDMloFNj8J4BIdOFfADbnAEhEBsgZPzOC1BD4BYBYcb4QQFqCMQeAO0PC1B/xsfxh/LPDunJ1IbcL5EBYH5MgBqDcQjADgAFsCEQFpgfE6BXgWsSrmgKgAL0MhRVATwEZ2hjoJehaCEkQgCygF6GIgFgETwBCNBXoqsAtAofACyg96ONLQDMBdoK0GOwsQWAhrgiBgABehVobAHgR5oKAGKwrQWQjrxpDAANcZUFtAkFdEbT0gXIvrypBaD5aMsYQGKwaRZAs6GWAqDRzLUpZlpCfTlGfiRuigl+dWMCxWDcFDMe0AYU2HAqlAvQpmTQcCraF1FNsVYGkBiMdgVUU6ydmEB1MN6aE/RqCBSsxZmJmID6OuhjB3DbEm06oO9J7rMZnB6YFGtrsTCdZHJALYP5ZsB7aTqN0wNj0tRJ2Tl8XFZhOEoVAXU+JCeB3w8jV4mdXIj0swIxCW5h/wlqX6oPyKQQyE7lTavwQy7EuWMJKgWRQb30fxkBK8OPTCilGPRpAfB49gByYinHYEoAxw+dlkmFOGkBZjaHntSIdTAhgPI/eEwhFmLZAtxeBL1CJg8oJQFPyvzYePaRKMR3CwTO+8QVOrkbuVbCsJJfj39/qhv5aYHCwc7SE/zJbsQfN3OWJX8gmOIn7u2kOmL/Oozk2ck7nAW/r+Hbl+e464vWF1jpG6zWt/dG9gat7RVmIvvesLw+WPKgwvD+optKrtGbJYErfNFilASOjj1bARXveQyycKh6y1OdhbUPqioFDEXvRz5Ql4V1xq8WMNZ+/SGglL0870wEOJOv31FUCOvf0P2iwAJ2DxmLBFTnXSyAygI71/8KYAqRPf2DWAsMio4IcDVsRf/AFgPryLtArQRWNS+JvAlKOy0bBa6p7X+QSsUGWZ+ClIvNXX9Bd31e7oa/+/g3+ul8YL9xT13bb/8PjogfW6Lgdc4AAAAASUVORK5CYII=",
    "protonvpn": "data:image/png;base64,/9j/4AAQSkZJRgABAQAAAQABAAD/2wCEAAkGBwgHBgkIBwgKCgkLDRYPDQwMDRsUFRAWIB0iIiAdHx8kKDQsJCYxJx8fLT0tMTU3Ojo6Iys/RD84QzQ5OjcBCgoKDQwNGg8PGjclHyU3Nzc3Nzc3Nzc3Nzc3Nzc3Nzc3Nzc3Nzc3Nzc3Nzc3Nzc3Nzc3Nzc3Nzc3Nzc3Nzc3N//AABEIAIAAgAMBEQACEQEDEQH/xAAbAAEAAgMBAQAAAAAAAAAAAAAAAwUBBAYHAv/EADcQAAICAQICBgcIAQUAAAAAAAABAgMEBRESIQYTMUFRYRQiMnFygZEHIzNDUmKxwdEVQoKh4f/EABoBAQADAQEBAAAAAAAAAAAAAAABAgMEBQb/xAAmEQEAAgICAQQCAwEBAAAAAAAAAQIDEQQSMQUTIUFRYTKRsXFC/9oADAMBAAIRAxEAPwD3EAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAY3XiBrvUMJS4Xl0KXh1iNPZyTG+s/wBCau6qz8OyE/hkmUmsx5gfZAAAAAAAAAAAAAAA4X7QdYvruhpmPY4QlDjucXs3v2L3Ht+k8WsxOa0b/C9Y+3EwqS7l9D3ZmVk9cGuxte4znUobtGbnUr7rMyILwjbJL+TC2HFbzWP6QsaNd1avbbNsa/dszntw+PP/AJQ3qek+qx7Z1T+Kv/Bhb0/BP5NN6npXlfm41Mvhbj/kwt6bj+rSq26+lMH7eJJP9s0Yz6fMeLDbr6SYUvahdB+cU/7Mp4WSPGhsw1nAn+dt8UWjKeNlj6GxDNxbPYvre/7jOcd48wJ09ygyAAAAPPftGxfR86nPnv1VserbS34ZLs+q/hnv+kZO1Jxx5j5WiXKV5OM/zEveevNL/hO2zXOmXs2wf/JGUxaPpLahAzmUJo1lJsiU0aykyhLGsrMiaFZSZQmjAzmUJY1lZkTQr8ikyhcaNkThZ1Em3Br1fJnHyKRrtBEro4lgAAAr9c0yrV9MvwruSsj6sv0yXNP6m3Hz2wZYyV+h4hl4tuJk2418OG2qTjJe4+4xZa5KxaviURb6Q7Gu14nbMZSh7Dcfc9iJiJ8pTV5uVD2cixfMpOGk+YQ2K9Zz6+y5S+KCM54uKfo02q+keXD266Z/Joyng458TJptVdKmvxMJP4bNv5Rjb078WRpc6RrmLqV3UxjOu3bdRntz9xxcji3wx28wrK7jDkce1ZfaRXas2WGj0Od/W/7Yfyzn5F9V6lPmdrs4moAAAAPPvtI0XnDV6IeFd6X/AFL+voe76PytbwW/7DLJ8fLgHDkfQxZSLvlxLdmkZGOEnst7kHCx2Pcg4R2ROSGVEjsrORe9E8Gy/U4ZC3VVD3lLxezSR5/PzRXF0+5V7bd2uaPDRNn3VVK2cYQXrN8itrRWNyp82+IdFjUxoqjXHu7X4nn2tNp26qxqNJSqQAAAAQ5mPVl41mPfBTqsi4yj4plqXmlotXzCJiJ+JeMaxptul6hdh3PeVcuUv1Luf0Pr+PnjNji8POtM0t1lo8B0dyMjHAT2W9w4B3T7hwDsiciXHx55F1dNUeKc3skUvkisTMq99y9D0zAr07Dhj182lvKX6n3s8DNlnLebS23qG4ZKTZcaXi9XDrZr1pdm/cjjzZO06h04qajtKwMGwAAAAAADk+n2j+mYSzqY73Y3t+cO/wCnb9T0vTeR7eTpPif9cfLx7r3jzDzhxPf7PMjIxwE9k+4xwDun3GeAdkTkdZ0X0vqKvTLY/eWLatPuj/6eZy8/aekOrFHx2l0GxxbXmzb0/G6+3eS9SPN+b8DHLfUfC2Gve36XiWxxu9kAAAAAAADEoxnFxkt01s0+8DyjpJpL0rU7KYp9RP16n3cPh8j6Ljcj3ccT9/b5zlY5wZOv19KrgOns5/cOAdj3FjoemvOyk5r7ivnN+PkYZ83Svx5b4K+5b9O0SSW0Vy7jzJl6E2SVwlZNRh2t8is21G1fm06hf41MaKVCPd2vxZxWt2nb08dIpXSUquAAAAAAAAAKTpXpP+paZJ1x3yKd51+fivmdPFzTjv8AqXD6hxvewz18x4ea8Hkez2fKRkfVVE7rI11x4pyeyQm+vmVq2m09Ydrp+HDCxo0w25c5PxZwZMk3tuXuY6xjp1hsozTNlrpuNwQ6yS5tcvccuW+507uLi1HeVgZOwAAAAAAAAAAMPsA8+6V6V6FqDuqjtTkNyWy5KXev7PT42btXU+YfH+r8aePm7V/jb/UmgYHVw9Ksj60uUE+5eJOXJv4hf0/DMV9y334XSSMdvQmzZwsfrrU2vUjzfn5GWS2obcfFOW+58Quktuw5nrsgAAAAAAAAAAABBl0RyKZVySe/NbrvLVt1nbLNijLSaypJQlCTjJNNdp1RO/Dxr7rOp8swhKc1GK3bImdKVi151Vd49KpqUI/N+JyzO529zDijHXrCYhqAAAAAAAAAAAAAAjsort5zhGT80TEzHhnfFS/8o2V011fhxUfchMzPkpipT+MJCGgAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA//9k=",
    "down-example.test": "data:image/svg+xml;base64,PHN2ZyB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciIHZpZXdCb3g9IjAgMCAyNCAyNCI+PHJlY3Qgd2lkdGg9IjI0IiBoZWlnaHQ9IjI0IiByeD0iNSIgZmlsbD0iI0VGNDQ0NCIvPjxwYXRoIGQ9Ik0xMiA3djZtMCAzLjV2LjUiIHN0cm9rZT0iI0ZGRkZGRiIgc3Ryb2tlLXdpZHRoPSIyLjIiIHN0cm9rZS1saW5lY2FwPSJyb3VuZCIvPjwvc3ZnPg==",
    "generic": "data:image/svg+xml;base64,PHN2ZyB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciIHZpZXdCb3g9IjAgMCAyNCAyNCI+PHJlY3Qgd2lkdGg9IjI0IiBoZWlnaHQ9IjI0IiByeD0iNiIgZmlsbD0iIzNCODJGNiIgZmlsbC1vcGFjaXR5PSIwLjEyIi8+PHBhdGggZD0iTTEyIDE1djJtLTMtNlY3YTMgMyAwIDAxNiAwdjRtLTggMGgxMGEyIDIgMCAwMTIgMnY2YTIgMiAwIDAxLTIgMkg3YTIgMiAwIDAxLTItMnYtNmEyIDIgMCAwMTItMnoiIHN0cm9rZT0iIzI1NjNFQiIgc3Ryb2tlLXdpZHRoPSIxLjgiIHN0cm9rZS1saW5lY2FwPSJyb3VuZCIgc3Ryb2tlLWxpbmVqb2luPSJyb3VuZCIvPjwvc3ZnPg=="
};

  function escapeHtml(str) {
    if (!str) return '';
    return String(str)
      .replace(/&/g, '&amp;')
      .replace(/</g, '&lt;')
      .replace(/>/g, '&gt;')
      .replace(/"/g, '&quot;')
      .replace(/'/g, '&#039;');
  }

  function getBrandLogoHtml(domain) {
    const clean = domain ? domain.toLowerCase().trim() : '';
    if (clean === 'down-example.test' || clean.includes('down-example') || clean.includes('outage')) {
      return `<svg class="brand-favicon-img brand-svg-logo" viewBox="0 0 24 24" width="22" height="22" fill="none" style="display:inline-block;vertical-align:middle;border-radius:4px;"><rect width="24" height="24" rx="5" fill="#EF4444"/><path d="M12 7v6m0 3.5v.5" stroke="#FFFFFF" stroke-width="2.2" stroke-linecap="round"/></svg>`;
    }
    if (REAL_BRAND_LOGOS[clean] && !REAL_BRAND_LOGOS[clean].startsWith('data:image/svg')) {
      return `<img src="${REAL_BRAND_LOGOS[clean]}" alt="${escapeHtml(clean)} logo" class="brand-favicon-img" loading="eager">`;
    }
    // Partial matches
    if (clean.includes('netflix')) return `<img src="${REAL_BRAND_LOGOS['netflix.com']}" alt="Netflix" class="brand-favicon-img">`;
    if (clean.includes('ticketmaster')) return `<img src="${REAL_BRAND_LOGOS['ticketmaster.com']}" alt="Ticketmaster" class="brand-favicon-img">`;
    if (clean.includes('chatgpt') || clean.includes('openai')) return `<img src="${REAL_BRAND_LOGOS['chatgpt.com']}" alt="ChatGPT" class="brand-favicon-img">`;
    if (clean.includes('github')) return `<img src="${REAL_BRAND_LOGOS['github.com']}" alt="GitHub" class="brand-favicon-img">`;
    if (clean.includes('hulu')) return `<img src="${REAL_BRAND_LOGOS['hulu.com']}" alt="Hulu" class="brand-favicon-img">`;
    if (clean.includes('coinbase')) return `<img src="${REAL_BRAND_LOGOS['coinbase.com']}" alt="Coinbase" class="brand-favicon-img">`;
    if (clean.includes('disney')) return `<img src="${REAL_BRAND_LOGOS['disneyplus.com']}" alt="Disney+" class="brand-favicon-img">`;
    if (clean.includes('spotify')) return `<img src="${REAL_BRAND_LOGOS['spotify.com']}" alt="Spotify" class="brand-favicon-img">`;
    if (clean.includes('amazon')) return `<img src="${REAL_BRAND_LOGOS['amazon.com']}" alt="Amazon" class="brand-favicon-img">`;

    // Clean local fallback without third-party query leakage
    return `<img src="${REAL_BRAND_LOGOS.generic}" alt="${escapeHtml(clean)} logo" class="brand-favicon-img">`;
  }

  // --- PRESET DEMONSTRATION PROFILES ---
  const PRESET_SCENARIOS = {
    'netflix.com': {
      domain: 'netflix.com',
      serviceName: 'Netflix',
      category: 'streaming',
      siteStatus: 'Online (Working)',
      siteStatusClass: 'online',
      vpnStatus: 'VPN Blocked',
      vpnStatusClass: 'restricted',
      grade: 'D',
      score: 42,
      evidenceStrength: 'Strong evidence',
      evidenceClass: 'strong',
      classification: 'Streaming Restriction (Demo)',
      headline: 'Example Scenario: Illustrating a streaming restriction diagnosis',
      subtext: 'Demonstration profile illustrating the interface state when commercial VPN exit nodes encounter geo-filtering or proxy restriction codes. This is demonstration data, not an actual measurement.',
      controlLatency: 'Not measured',
      reportCount: 0,
      hypothesis: 'Illustrative observation: Commercial datacenter IP addresses receive proxy restriction responses in this sample scenario.',
      workingVpns: [
        { name: 'NordVPN', tip: 'Dedicated US or UK streaming locations (Demo Profile).' },
        { name: 'ExpressVPN', tip: 'London and New York server routes (Demo Profile).' },
        { name: 'Surfshark', tip: 'Rotating IP setting (Demo Profile).' }
      ]
    },

    'ticketmaster.com': {
      domain: 'ticketmaster.com',
      serviceName: 'Ticketmaster',
      category: 'ticketing',
      siteStatus: 'Online (Working)',
      siteStatusClass: 'online',
      vpnStatus: 'VPN Blocked (403 / Bot)',
      vpnStatusClass: 'restricted',
      grade: 'F',
      score: 12,
      evidenceStrength: 'Strong evidence',
      evidenceClass: 'strong',
      classification: 'Automated Bot Filter (Demo)',
      headline: 'Example Scenario: Illustrating an automated bot/WAF block (HTTP 403)',
      subtext: 'Demonstration profile illustrating the interface state when automated firewall rules return HTTP 403 Access Denied on commercial datacenter IP ranges. This is demonstration data, not an actual measurement.',
      controlLatency: 'Not measured',
      reportCount: 0,
      hypothesis: 'Illustrative observation: Automated security filters drop commercial datacenter IP ranges in this sample scenario.',
      workingVpns: [
        { name: 'ProtonVPN', tip: 'Alternate egress node configuration (Demo Profile).' },
        { name: 'NordVPN', tip: 'Dedicated IP server option (Demo Profile).' }
      ]
    },

    'chatgpt.com': {
      domain: 'chatgpt.com',
      serviceName: 'ChatGPT',
      category: 'ai',
      siteStatus: 'Online (Working)',
      siteStatusClass: 'online',
      vpnStatus: 'VPN Friction (CAPTCHAs)',
      vpnStatusClass: 'friction',
      grade: 'C',
      score: 68,
      evidenceStrength: 'Moderate evidence',
      evidenceClass: 'moderate',
      classification: 'Verification Challenge (Demo)',
      headline: 'Example Scenario: Illustrating web application challenge friction',
      subtext: 'Demonstration profile illustrating the interface state when multi-tenant datacenter IPs receive elevated challenge rates, such as Cloudflare Turnstile verification loops. This is demonstration data, not an actual measurement.',
      controlLatency: 'Not measured',
      reportCount: 0,
      hypothesis: 'Illustrative observation: Verification challenges presented on multi-tenant datacenter IP ranges in this sample scenario.',
      workingVpns: [
        { name: 'NordVPN', tip: 'US East exit routes (Demo Profile).' },
        { name: 'ExpressVPN', tip: 'London exit routes (Demo Profile).' },
        { name: 'Surfshark', tip: 'WireGuard protocol routes (Demo Profile).' }
      ]
    },

    'github.com': {
      domain: 'github.com',
      serviceName: 'GitHub',
      category: 'ai',
      siteStatus: 'Online (Working)',
      siteStatusClass: 'online',
      vpnStatus: 'Works on VPN',
      vpnStatusClass: 'pass',
      grade: 'A',
      score: 98,
      evidenceStrength: 'Strong evidence',
      evidenceClass: 'strong',
      classification: 'VPN Accessible (Demo)',
      headline: 'Example Scenario: Illustrating a VPN-accessible developer platform',
      subtext: 'Demonstration profile illustrating the interface state when web navigation, API endpoints, and Git connections route cleanly across commercial VPN exit nodes. This is demonstration data, not an actual measurement.',
      controlLatency: 'Not measured',
      reportCount: 0,
      hypothesis: 'Illustrative observation: Platform accepts connections across diverse commercial ASNs in this sample scenario.',
      workingVpns: [
        { name: 'NordVPN', tip: 'Global exit nodes connect normally (Demo Profile).' },
        { name: 'ExpressVPN', tip: 'Full support for Git SSH over VPN (Demo Profile).' },
        { name: 'Surfshark', tip: 'Fast ping on nearest local city server (Demo Profile).' }
      ]
    },

    'hulu.com': {
      domain: 'hulu.com',
      serviceName: 'Hulu',
      category: 'streaming',
      siteStatus: 'Online (Working)',
      siteStatusClass: 'online',
      vpnStatus: 'VPN Blocked (P-DEV320)',
      vpnStatusClass: 'restricted',
      grade: 'D',
      score: 38,
      evidenceStrength: 'Strong evidence',
      evidenceClass: 'strong',
      classification: 'Media Player Error (Demo)',
      headline: 'Example Scenario: Illustrating a media player error code response',
      subtext: 'Demonstration profile illustrating the interface state when media players encounter commercial VPN proxy routes and return platform error codes. This is demonstration data, not an actual measurement.',
      controlLatency: 'Not measured',
      reportCount: 0,
      hypothesis: 'Illustrative observation: Media streaming gateway restricts commercial datacenter IP ranges in this sample scenario.',
      workingVpns: [
        { name: 'NordVPN', tip: 'Specialized dedicated IP configuration (Demo Profile).' },
        { name: 'ExpressVPN', tip: 'US MediaStreamer DNS routing (Demo Profile).' }
      ]
    },

    'coinbase.com': {
      domain: 'coinbase.com',
      serviceName: 'Coinbase',
      category: 'crypto',
      siteStatus: 'Online (Working)',
      siteStatusClass: 'online',
      vpnStatus: 'VPN Friction (2FA Re-auth)',
      vpnStatusClass: 'friction',
      grade: 'B',
      score: 82,
      evidenceStrength: 'Moderate evidence',
      evidenceClass: 'moderate',
      classification: 'Step-Up Authentication (Demo)',
      headline: 'Example Scenario: Illustrating authentication challenge friction',
      subtext: 'Demonstration profile illustrating the interface state when security gateways prompt for repeated step-up authentication when accessing from unfamiliar or shared IP ranges. This is demonstration data, not an actual measurement.',
      controlLatency: 'Not measured',
      reportCount: 0,
      hypothesis: 'Illustrative observation: Adaptive authentication gates trigger verification challenges on shared IP ranges in this sample scenario.',
      workingVpns: [
        { name: 'NordVPN', tip: 'Dedicated IP avoids shared datacenter IP flags (Demo Profile).' },
        { name: 'ProtonVPN', tip: 'Swiss or US privacy servers with clean IP reputation (Demo Profile).' }
      ]
    },

    'disneyplus.com': {
      domain: 'disneyplus.com',
      serviceName: 'Disney+',
      category: 'streaming',
      siteStatus: 'Online (Working)',
      siteStatusClass: 'online',
      vpnStatus: 'VPN Blocked (Error 73)',
      vpnStatusClass: 'restricted',
      grade: 'D',
      score: 40,
      evidenceStrength: 'Moderate evidence',
      evidenceClass: 'moderate',
      classification: 'Content Gate (Demo)',
      headline: 'Example Scenario: Illustrating a content restriction error code',
      subtext: 'Demonstration profile illustrating the interface state when streaming services return client-side restriction codes on commercial VPN IPs. This is demonstration data, not an actual measurement.',
      controlLatency: 'Not measured',
      reportCount: 0,
      hypothesis: 'Illustrative observation: Edge delivery network restricts commercial datacenter IP ranges in this sample scenario.',
      workingVpns: [
        { name: 'NordVPN', tip: 'US streaming node configuration (Demo Profile).' },
        { name: 'Surfshark', tip: 'WireGuard mode on UK server (Demo Profile).' }
      ]
    },

    'spotify.com': {
      domain: 'spotify.com',
      serviceName: 'Spotify',
      category: 'streaming',
      siteStatus: 'Online (Working)',
      siteStatusClass: 'online',
      vpnStatus: 'Works on VPN',
      vpnStatusClass: 'pass',
      grade: 'A',
      score: 95,
      evidenceStrength: 'Moderate evidence',
      evidenceClass: 'moderate',
      classification: 'VPN Accessible (Demo)',
      headline: 'Example Scenario: Illustrating a VPN-accessible media service',
      subtext: 'Demonstration profile illustrating the interface state when authenticated user streaming sessions connect cleanly across commercial VPN exit nodes. This is demonstration data, not an actual measurement.',
      controlLatency: 'Not measured',
      reportCount: 0,
      hypothesis: 'Illustrative observation: Permissive connection policy for authenticated user sessions in this sample scenario.',
      workingVpns: [
        { name: 'NordVPN', tip: 'Compatible across global exit nodes (Demo Profile).' },
        { name: 'ExpressVPN', tip: 'Fast audio buffering on nearest city node (Demo Profile).' }
      ]
    },

    'amazon.com': {
      domain: 'amazon.com',
      serviceName: 'Amazon',
      category: 'ticketing',
      siteStatus: 'Online (Working)',
      siteStatusClass: 'online',
      vpnStatus: 'VPN Friction (Checkout)',
      vpnStatusClass: 'friction',
      grade: 'B',
      score: 79,
      evidenceStrength: 'Moderate evidence',
      evidenceClass: 'moderate',
      classification: 'Verification Prompt (Demo)',
      headline: 'Example Scenario: Illustrating checkout step-up verification friction',
      subtext: 'Demonstration profile illustrating the interface state when retail gateways prompt for one-time verification codes during checkout on unfamiliar IP ranges. This is demonstration data, not an actual measurement.',
      controlLatency: 'Not measured',
      reportCount: 0,
      hypothesis: 'Illustrative observation: Adaptive security verification prompts on multi-tenant IP ranges in this sample scenario.',
      workingVpns: [
        { name: 'NordVPN', tip: 'Dedicated IP server option (Demo Profile).' },
        { name: 'ExpressVPN', tip: 'US server route option (Demo Profile).' }
      ]
    },

    'down-example.test': {
      domain: 'down-example.test',
      serviceName: 'Test Outage Example',
      category: 'all',
      siteStatus: 'Site Unreachable / Outage',
      siteStatusClass: 'offline',
      vpnStatus: 'Unknown / Not Measurable',
      vpnStatusClass: 'unknown',
      grade: 'F',
      score: 0,
      evidenceStrength: 'Limited evidence',
      evidenceClass: 'limited',
      classification: 'General Server Outage (Demo)',
      headline: 'Example Scenario: Illustrating an origin server reachability outage',
      subtext: 'Direct baseline connection and VPN nodes both fail to connect (HTTP 503 / DNS error). Because the target site is unreachable, VPN accessibility cannot be established.',
      controlLatency: 'Not measured',
      reportCount: 0,
      hypothesis: 'Illustrative observation: Origin host down; webserver 503 or DNS failure across all networks.',
      workingVpns: [
        { name: 'No VPN will work right now', tip: 'The problem is on the website host. Wait for their web engineering team to restore service.' }
      ]
    },

    'obscure-site.xyz': {
      domain: 'obscure-site.xyz',
      serviceName: 'Sample Obscure Site',
      category: 'all',
      siteStatus: 'Online (Working)',
      siteStatusClass: 'online',
      vpnStatus: 'Inconclusive / Friction',
      vpnStatusClass: 'friction',
      grade: 'Pending',
      score: 50,
      evidenceStrength: 'Limited evidence',
      evidenceClass: 'limited',
      classification: 'Limited Telemetry (Demo)',
      headline: 'Example Scenario: Illustrating limited observation telemetry',
      subtext: 'Demonstration profile illustrating the interface state when observation data across mixed test node runs is inconclusive. This is demonstration data, not an actual measurement.',
      controlLatency: 'Not measured',
      reportCount: 0,
      hypothesis: 'Illustrative observation: Sporadic rate-limiting rather than a uniform restriction.',
      workingVpns: [
        { name: 'NordVPN', tip: 'Switch server locations or try alternate nodes (Demo Profile).' },
        { name: 'ExpressVPN', tip: 'Alternate city servers generally provide cleaner latency (Demo Profile).' }
      ]
    }
  };

  // 9 Popular Monitored Services for the Homepage Grid
  const MONITORED_SERVICES = [
    PRESET_SCENARIOS['netflix.com'],
    PRESET_SCENARIOS['ticketmaster.com'],
    PRESET_SCENARIOS['chatgpt.com'],
    PRESET_SCENARIOS['github.com'],
    PRESET_SCENARIOS['hulu.com'],
    PRESET_SCENARIOS['coinbase.com'],
    PRESET_SCENARIOS['disneyplus.com'],
    PRESET_SCENARIOS['spotify.com'],
    PRESET_SCENARIOS['amazon.com']
  ];

  // Truthful prototype handler for arbitrary custom queries (Point 2: No fabricated hash diagnosis)
  function generateCustomScenario(domain) {
    return {
      domain: domain,
      serviceName: domain,
      category: 'custom',
      siteStatus: 'Not Measurable',
      siteStatusClass: 'unknown',
      vpnStatus: 'Unknown / Not Measurable',
      vpnStatusClass: 'unknown',
      grade: null,
      score: null,
      evidenceStrength: 'Insufficient evidence',
      evidenceClass: 'insufficient',
      classification: 'Testing Unavailable',
      headline: `Live testing is not connected for ${domain} in this prototype.`,
      subtext: `This prototype demonstrates the diagnostic workflow and result architecture. Real multi-exit probe measurements for custom domains will appear here once live telemetry nodes are connected.`,
      controlLatency: 'Not measured',
      reportCount: 0,
      hypothesis: `Active measurement exit probes required to establish empirical status for ${domain}.`,
      workingVpns: [
        {
          name: 'Live Telemetry Required',
          tip: 'Empirical exit-node testing for arbitrary domains will display here once the telemetry pipeline is active.'
        }
      ]
    };
  }

  // Local Storage for User Reports
  const STORAGE_KEY = 'vpn_user_reports_v2';

  function getLocalReports() {
    try {
      const data = localStorage.getItem(STORAGE_KEY);
      return data ? JSON.parse(data) : [];
    } catch (e) {
      return [];
    }
  }

  function saveLocalReport(report) {
    try {
      const reports = getLocalReports();
      reports.unshift(report);
      localStorage.setItem(STORAGE_KEY, JSON.stringify(reports));
    } catch (e) {}
  }

  function getLocalCount(domain) {
    const reports = getLocalReports();
    return reports.filter(r => r.domain.toLowerCase() === domain.toLowerCase()).length;
  }

  // Domain Normalization
  function normalizeDomain(input) {
    if (!input) return '';
    let cleaned = input.trim().toLowerCase();
    cleaned = cleaned.replace(/^https?:\/\//i, '');
    cleaned = cleaned.split('/')[0].split('?')[0].split('#')[0].split(':')[0];
    cleaned = cleaned.replace(/^www\./i, '');
    return cleaned;
  }

  function isValidDomain(domain) {
    if (!domain || domain.length < 3 || domain.length > 253) return false;
    const domainPattern = /^[a-zA-Z0-9]([a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?(\.[a-zA-Z0-9]([a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?)+$/;
    return domainPattern.test(domain) || domain.includes('.test') || domain.includes('.local');
  }

  // State & DOM Elements
  const state = {
    currentDomain: 'netflix.com',
    currentData: null,
    currentCategory: 'all'
  };

  const elements = {
    // Search
    searchSection: document.getElementById('searchSection'),
    checkForm: document.getElementById('checkForm'),
    domainInput: document.getElementById('domainInput'),
    clearBtn: document.getElementById('clearBtn'),
    validationMsg: document.getElementById('validationMsg'),
    quickPillsRow: document.getElementById('quickPillsRow'),

    // Homepage Blocks
    homeBlocksSection: document.getElementById('homeBlocksSection'),
    monitoredServicesBlock: document.getElementById('monitoredServicesBlock'),
    servicesGrid: document.getElementById('servicesGrid'),
    categoryFiltersRow: document.getElementById('categoryFiltersRow'),

    // Loading
    loadingSection: document.getElementById('loadingSection'),
    loadingDomain: document.getElementById('loadingDomain'),

    // Results
    resultsSection: document.getElementById('resultsSection'),
    btnBackToHome: document.getElementById('btnBackToHome'),
    verdictCard: document.getElementById('verdictCard'),
    serviceFavicon: document.getElementById('serviceFavicon'),
    serviceName: document.getElementById('serviceName'),
    serviceDomain: document.getElementById('serviceDomain'),
    lastCheckedTime: document.getElementById('lastCheckedTime'),

    pillSiteStatus: document.getElementById('pillSiteStatus'),
    siteStatusText: document.getElementById('siteStatusText'),
    pillVpnStatus: document.getElementById('pillVpnStatus'),
    vpnStatusText: document.getElementById('vpnStatusText'),

    evidenceStrengthBox: document.getElementById('evidenceStrengthBox'),
    evidenceStrengthText: document.getElementById('evidenceStrengthText'),
    communityPulseMsg: document.getElementById('communityPulseMsg'),

    gradeTagBox: document.getElementById('gradeTagBox'),
    gradeLetter: document.getElementById('gradeLetter'),
    gradeScoreText: document.getElementById('gradeScoreText'),

    serviceCategoryBadge: document.getElementById('serviceCategoryBadge'),
    verdictSummaryWrap: document.getElementById('verdictSummaryWrap'),
    btnDirectVisit: document.getElementById('btnDirectVisit'),

    // Solution 1 & 2 Elements
    option1Badge: document.getElementById('option1Badge'),
    option1Title: document.getElementById('option1Title'),
    option1Desc: document.getElementById('option1Desc'),
    step1Text: document.getElementById('step1Text'),
    step2Text: document.getElementById('step2Text'),
    solutionProofTag: document.getElementById('solutionProofTag'),
    proofStatusText: document.getElementById('proofStatusText'),
    option2Badge: document.getElementById('option2Badge'),
    option2Title: document.getElementById('option2Title'),
    option2Desc: document.getElementById('option2Desc'),

    resultHeadline: document.getElementById('resultHeadline'),
    resultSubtext: document.getElementById('resultSubtext'),
    targetNameInline: document.getElementById('targetNameInline'),
    workingVpnsList: document.getElementById('workingVpnsList'),

    reportCount: document.getElementById('reportCount'),
    btnReportTrigger: document.getElementById('btnReportTrigger'),
    btnCheckAnother: document.getElementById('btnCheckAnother'),
    btnShareResult: document.getElementById('btnShareResult'),

    // Technical Details Accordion
    techAccordion: document.getElementById('techAccordion'),
    hypothesisText: document.getElementById('hypothesisText'),

    // Report Modal
    reportModal: document.getElementById('reportModal'),
    reportForm: document.getElementById('reportForm'),
    modalDomainInput: document.getElementById('modalDomainInput'),
    reportSymptom: document.getElementById('reportSymptom'),
    reportProvider: document.getElementById('reportProvider'),
    reportRegion: document.getElementById('reportRegion'),
    reportDetails: document.getElementById('reportDetails'),
    reportEvidence: document.getElementById('reportEvidence'),
    modalCloseBtn: document.getElementById('modalCloseBtn'),
    modalSuccessCloseBtn: document.getElementById('modalSuccessCloseBtn'),
    modalFormState: document.getElementById('modalFormState'),
    modalSuccessState: document.getElementById('modalSuccessState'),
    modalSuccessDesc: document.getElementById('modalSuccessDesc'),

    // Header Links
    brandLogoLink: document.getElementById('brandLogoLink'),
    btnHeaderCheck: document.getElementById('btnHeaderCheck'),
    btnHeaderGrid: document.getElementById('btnHeaderGrid'),
    btnHeaderReport: document.getElementById('btnHeaderReport'),

    // Toast
    toastMsg: document.getElementById('toastMsg'),
    toastText: document.getElementById('toastText')
  };

  // Toast Helper
  function showToast(message) {
    if (!elements.toastMsg) return;
    elements.toastText.textContent = message;
    elements.toastMsg.classList.add('show');
    setTimeout(() => {
      elements.toastMsg.classList.remove('show');
    }, 2500);
  }

  // Render Real Brand Logos into Hero Pills
  function initHeroPillLogos() {
    const pillLogos = {
      'pillLogoNetflix': 'netflix.com',
      'pillLogoTicketmaster': 'ticketmaster.com',
      'pillLogoChatgpt': 'chatgpt.com',
      'pillLogoGithub': 'github.com',
      'pillLogoHulu': 'hulu.com',
      'pillLogoCoinbase': 'coinbase.com',
      'pillLogoOutage': 'down-example.test'
    };

    for (const [id, domain] of Object.entries(pillLogos)) {
      const el = document.getElementById(id);
      if (el) {
        el.innerHTML = getBrandLogoHtml(domain);
      }
    }
  }

  // Render Monitored Services Grid
  function renderServicesGrid(filterCategory) {
    if (!elements.servicesGrid) return;

    const filtered = filterCategory === 'all'
      ? MONITORED_SERVICES
      : MONITORED_SERVICES.filter(s => s.category === filterCategory || (filterCategory === 'all'));

    let html = '';
    filtered.forEach(s => {
      // Status pill classes
      const siteClass = s.siteStatusClass === 'online' ? 'online' : 'down';
      const vpnDotClass = s.vpnStatusClass === 'pass' ? 'friendly' : (s.vpnStatusClass === 'friction' ? 'friction' : 'blocked');

      html += `
        <article class="service-card status-${vpnDotClass}" data-domain="${s.domain}" role="button" tabindex="0" aria-label="Check ${s.serviceName} VPN status">
          <div class="card-top-row">
            <div class="card-identity-box">
              <div class="card-logo-container">
                ${getBrandLogoHtml(s.domain)}
              </div>
              <div>
                <div class="card-name-text">${s.serviceName}</div>
                <div class="card-domain-text">${s.domain}</div>
              </div>
            </div>
            <span class="card-category-tag">${s.category}</span>
          </div>

          <div class="card-status-box">
            <div class="card-status-line">
              <span class="status-key">Website</span>
              <span class="status-badge-inline">
                <span class="status-dot-mini ${siteClass}"></span>
                <span>${s.siteStatus.split(' ')[0]}</span>
              </span>
            </div>
            <div class="card-status-line">
              <span class="status-key">VPN Access</span>
              <span class="status-badge-inline">
                <span class="status-dot-mini ${vpnDotClass}"></span>
                <span>${s.vpnStatus}</span>
              </span>
            </div>
          </div>

          <div class="card-bottom-row">
            <div class="card-grade-badge">
              <span class="card-evidence-pill ${s.evidenceClass || 'moderate'}">${s.evidenceStrength || 'Moderate evidence'}</span>
            </div>
            <span class="card-reports-count">Demo Profile</span>
            <span class="btn-card-action">Check &rarr;</span>
          </div>
        </article>
      `;
    });

    elements.servicesGrid.innerHTML = html;

    // Attach click events to cards
    elements.servicesGrid.querySelectorAll('.service-card').forEach(card => {
      card.addEventListener('click', () => {
        const domain = card.getAttribute('data-domain');
        if (domain) runCheck(domain);
      });
      card.addEventListener('keydown', (e) => {
        if (e.key === 'Enter' || e.key === ' ') {
          e.preventDefault();
          const domain = card.getAttribute('data-domain');
          if (domain) runCheck(domain);
        }
      });
    });
  }

  // Navigation between Home and Results
  function showHomeView() {
    if (elements.loadingSection) elements.loadingSection.style.display = 'none';
    if (elements.resultsSection) elements.resultsSection.style.display = 'none';
    if (elements.homeBlocksSection) elements.homeBlocksSection.style.display = 'flex';
    if (elements.searchSection) elements.searchSection.style.display = 'block';

    window.scrollTo({ top: 0, behavior: 'smooth' });
    if (elements.domainInput) elements.domainInput.focus();
  }

  // Run Check
  function runCheck(rawInput) {
    const domain = normalizeDomain(rawInput);
    if (!domain) {
      if (elements.validationMsg) {
        elements.validationMsg.textContent = 'Please enter a valid website address.';
        elements.validationMsg.style.display = 'block';
      }
      return;
    }

    if (!isValidDomain(domain)) {
      if (elements.validationMsg) {
        elements.validationMsg.textContent = `"${domain}" is not a recognized domain format (e.g. netflix.com).`;
        elements.validationMsg.style.display = 'block';
      }
      return;
    }

    if (elements.validationMsg) elements.validationMsg.style.display = 'none';

    // Show loading state
    state.currentDomain = domain;
    if (elements.domainInput) elements.domainInput.value = domain;
    if (elements.loadingDomain) elements.loadingDomain.textContent = domain;

    if (elements.homeBlocksSection) elements.homeBlocksSection.style.display = 'none';
    if (elements.resultsSection) elements.resultsSection.style.display = 'none';
    if (elements.loadingSection) elements.loadingSection.style.display = 'block';

    window.location.hash = domain;

    // Brief, smooth 850ms transition
    setTimeout(() => {
      let data = PRESET_SCENARIOS[domain];
      if (!data) {
        data = generateCustomScenario(domain);
      }
      state.currentData = data;
      displayResult(data);
    }, 850);
  }

  // Safe Working VPN & Advisory Row Renderer
  function renderWorkingVpnRow(vpn) {
    const vpnLower = (vpn.name || '').toLowerCase();
    let iconHtml = '';
    let tagHtml = '';

    if (vpnLower.includes('nord') && REAL_BRAND_LOGOS.nordvpn) {
      iconHtml = `<img src="${REAL_BRAND_LOGOS.nordvpn}" alt="NordVPN" class="vpn-logo-img">`;
      tagHtml = `<span class="vpn-provider-tag">Compatible Node</span>`;
    } else if (vpnLower.includes('express') && REAL_BRAND_LOGOS.expressvpn) {
      iconHtml = `<img src="${REAL_BRAND_LOGOS.expressvpn}" alt="ExpressVPN" class="vpn-logo-img">`;
      tagHtml = `<span class="vpn-provider-tag">Compatible Node</span>`;
    } else if (vpnLower.includes('surfshark') && REAL_BRAND_LOGOS.surfshark) {
      iconHtml = `<img src="${REAL_BRAND_LOGOS.surfshark}" alt="Surfshark" class="vpn-logo-img">`;
      tagHtml = `<span class="vpn-provider-tag">Compatible Node</span>`;
    } else if (vpnLower.includes('proton') && REAL_BRAND_LOGOS.protonvpn) {
      iconHtml = `<img src="${REAL_BRAND_LOGOS.protonvpn}" alt="ProtonVPN" class="vpn-logo-img">`;
      tagHtml = `<span class="vpn-provider-tag">Compatible Node</span>`;
    } else if (vpnLower.includes('avoid') || vpnLower.includes('trade') || vpnLower.includes('security') || vpnLower.includes('2fa') || vpnLower.includes('freeze')) {
      // Security advisory notice (e.g. Coinbase)
      iconHtml = `
        <div class="vpn-icon-container advisory" aria-hidden="true">
          <svg viewBox="0 0 24 24" width="18" height="18" fill="none"><path d="M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10z" fill="#FEF3C7" stroke="#D97706" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/><path d="M12 8v4m0 4h.01" stroke="#B45309" stroke-width="2" stroke-linecap="round"/></svg>
        </div>`;
      tagHtml = `<span class="vpn-tag-advisory">Security Notice</span>`;
    } else if (vpnLower.includes('no vpn') || vpnLower.includes('offline') || vpnLower.includes('down') || vpnLower.includes('outage')) {
      // Server outage notice (e.g. down-example.test)
      iconHtml = `
        <div class="vpn-icon-container offline" aria-hidden="true">
          <svg viewBox="0 0 24 24" width="18" height="18" fill="none"><circle cx="12" cy="12" r="9" fill="#FEE2E2" stroke="#EF4444" stroke-width="2"/><path d="M12 8v5m0 3v.5" stroke="#DC2626" stroke-width="2" stroke-linecap="round"/></svg>
        </div>`;
      tagHtml = `<span class="vpn-tag-offline">Site Down</span>`;
    } else {
      // Generic VPN / Telemetry Required
      iconHtml = `<img src="${REAL_BRAND_LOGOS.generic}" alt="${vpn.name}" class="vpn-logo-img">`;
      tagHtml = `<span class="vpn-provider-tag">Demo Profile</span>`;
    }

    return `
      <div class="working-vpn-row">
        ${iconHtml}
        <div class="vpn-info-col">
          <div class="vpn-name-header">
            <strong>${vpn.name}</strong>
            ${tagHtml}
          </div>
          <span class="vpn-tip-text">${vpn.tip}</span>
        </div>
      </div>
    `;
  }

  // Display Result
  function displayResult(result) {
    if (elements.loadingSection) elements.loadingSection.style.display = 'none';
    if (elements.homeBlocksSection) elements.homeBlocksSection.style.display = 'none';
    if (elements.resultsSection) elements.resultsSection.style.display = 'flex';

    // Target Identity with REAL SVG BRAND LOGO
    if (elements.serviceFavicon) {
      elements.serviceFavicon.innerHTML = getBrandLogoHtml(result.domain);
    }
    if (elements.serviceName) elements.serviceName.textContent = result.serviceName || result.domain;
    if (elements.serviceDomain) elements.serviceDomain.textContent = result.domain;
    if (elements.serviceCategoryBadge) {
      const cat = (result.category || 'service').toUpperCase();
      elements.serviceCategoryBadge.textContent = cat;
    }
    if (elements.lastCheckedTime) {
      if (result.category === 'custom' || result.siteStatusClass === 'unknown') {
        elements.lastCheckedTime.textContent = 'Prototype preview • Live testing not connected';
      } else {
        elements.lastCheckedTime.textContent = 'Demo data • Prototype preview';
      }
    }

    // Website Status Badge
    if (elements.pillSiteStatus && elements.siteStatusText) {
      elements.pillSiteStatus.className = 'status-pill-large ' + (result.siteStatusClass || 'unknown');
      elements.siteStatusText.textContent = result.siteStatus;
    }

    // VPN Accessibility Badge (Independent field: if reachability not established, Unknown / Not Measurable)
    if (elements.pillVpnStatus && elements.vpnStatusText) {
      const isUnreachable = result.siteStatusClass === 'offline' || result.siteStatusClass === 'unknown';
      const vpnClass = isUnreachable ? 'unknown' : (result.vpnStatusClass || 'restricted');
      const vpnText = isUnreachable ? 'Unknown / Not Measurable' : result.vpnStatus;
      elements.pillVpnStatus.className = 'status-pill-large ' + vpnClass;
      elements.vpnStatusText.textContent = vpnText;
    }

    // Evidence Strength Badge (Independent field)
    if (elements.evidenceStrengthBox && elements.evidenceStrengthText) {
      elements.evidenceStrengthBox.className = 'evidence-pill ' + (result.evidenceClass || 'insufficient');
      elements.evidenceStrengthText.textContent = result.evidenceStrength || 'Insufficient evidence';
    }
    if (elements.gradeTagBox) {
      elements.gradeTagBox.style.display = 'none'; // Capability preserved for future development
    }

    // Plain English Headline & Subtext wrapped in styled verdict callout
    if (elements.resultHeadline) elements.resultHeadline.textContent = result.headline;
    if (elements.resultSubtext) elements.resultSubtext.textContent = result.subtext;
    if (elements.verdictSummaryWrap) {
      const isUnreachable = result.siteStatusClass === 'offline' || result.siteStatusClass === 'unknown';
      const vClass = isUnreachable ? result.siteStatusClass : (result.vpnStatusClass || 'restricted');
      elements.verdictSummaryWrap.className = 'verdict-summary-wrap ' + vClass;
    }

    // Solution 1 (Dynamic context-aware instructions)
    if (elements.btnDirectVisit) {
      elements.btnDirectVisit.href = 'https://' + result.domain;
      elements.btnDirectVisit.title = 'Open ' + result.domain + ' in new tab';
    }

    if (result.siteStatusClass === 'unknown' || result.category === 'custom') {
      if (elements.option1Badge) {
        elements.option1Badge.textContent = 'PROTOTYPE PREVIEW';
        elements.option1Badge.className = 'solution-badge-fast';
      }
      if (elements.option1Title) elements.option1Title.textContent = 'Live Testing Not Connected';
      if (elements.option1Desc) elements.option1Desc.textContent = 'This prototype demonstrates the diagnostic workflow. Because live multi-region testing is not connected, this custom domain has not yet been probed.';
      if (elements.step1Text) elements.step1Text.textContent = 'Try one of the curated demonstration profiles (e.g. Netflix, Ticketmaster, ChatGPT, GitHub).';
      if (elements.step2Text) elements.step2Text.textContent = 'Submit a block report below if you are currently experiencing an issue with this website.';
      if (elements.solutionProofTag) elements.solutionProofTag.className = 'solution-proof-tag';
      if (elements.proofStatusText) elements.proofStatusText.textContent = 'Direct connection: Not measured';

      if (elements.option2Badge) {
        elements.option2Badge.textContent = 'TELEMETRY STATUS';
        elements.option2Badge.className = 'solution-badge-shield';
      }
      if (elements.option2Title) elements.option2Title.textContent = 'VPN Telemetry Pending';
      if (elements.option2Desc) elements.option2Desc.textContent = `Provider compatibility telemetry will appear once multi-region probes are connected:`;
    } else if (result.siteStatusClass === 'offline') {
      if (elements.option1Badge) {
        elements.option1Badge.textContent = 'WEBSITE OUTAGE';
        elements.option1Badge.className = 'solution-badge-fast offline';
      }
      if (elements.option1Title) elements.option1Title.textContent = 'Host Server Experiencing Outage';
      if (elements.option1Desc) elements.option1Desc.textContent = 'The website itself is not responding. Turning off your VPN or changing servers will not restore access until the website owner fixes the server outage.';
      if (elements.step1Text) elements.step1Text.textContent = 'Wait 15-30 minutes for their technical team to restore uptime.';
      if (elements.step2Text) elements.step2Text.textContent = 'Do not disconnect VPN — this is NOT a VPN problem.';
      if (elements.solutionProofTag) elements.solutionProofTag.className = 'solution-proof-tag offline';
      if (elements.proofStatusText) elements.proofStatusText.textContent = 'Direct connection: Server Unreachable';
      if (elements.btnDirectVisit) elements.btnDirectVisit.textContent = 'Test Site URL ↗';

      if (elements.option2Badge) {
        elements.option2Badge.textContent = 'STATUS ADVISORY';
        elements.option2Badge.className = 'solution-badge-shield offline';
      }
      if (elements.option2Title) elements.option2Title.textContent = 'No VPN Bypass Available';
      if (elements.option2Desc) elements.option2Desc.textContent = 'Because the origin host is offline for all internet users, no VPN provider can load this website right now:';
    } else if (result.vpnStatusClass === 'pass') {
      if (elements.option1Badge) {
        elements.option1Badge.textContent = 'VPN COMPATIBLE';
        elements.option1Badge.className = 'solution-badge-fast';
      }
      if (elements.option1Title) elements.option1Title.textContent = 'No Disconnection Needed';
      if (elements.option1Desc) elements.option1Desc.textContent = 'This website does not restrict VPN connections in this demo profile. You can keep your VPN turned on with full encryption and normal performance.';
      if (elements.step1Text) elements.step1Text.textContent = 'Your current VPN connection is working properly.';
      if (elements.step2Text) elements.step2Text.textContent = 'No special settings or disconnections required.';
      if (elements.solutionProofTag) elements.solutionProofTag.className = 'solution-proof-tag green';
      if (elements.proofStatusText) elements.proofStatusText.textContent = 'Direct connection: Not measured (Demo Profile)';
      if (elements.btnDirectVisit) elements.btnDirectVisit.textContent = 'Open Site Directly ↗';

      if (elements.option2Badge) {
        elements.option2Badge.textContent = 'VPN SUGGESTIONS';
        elements.option2Badge.className = 'solution-badge-shield';
      }
      if (elements.option2Title) elements.option2Title.textContent = 'Compatible VPN Providers (Demo)';
      if (elements.option2Desc) elements.option2Desc.textContent = `Demonstration provider profiles for ${result.serviceName || result.domain}:`;
    } else if (result.domain === 'coinbase.com') {
      if (elements.option1Badge) {
        elements.option1Badge.textContent = 'OPTION 1: PREVENT 2FA LOCKOUT';
        elements.option1Badge.className = 'solution-badge-fast';
      }
      if (elements.option1Title) elements.option1Title.textContent = 'Disconnect before account login';
      if (elements.option1Desc) elements.option1Desc.textContent = 'Public pages load, but account logins may prompt for additional step-up verification when accessed from shared datacenter IP ranges.';
      if (elements.step1Text) elements.step1Text.textContent = 'Disconnect VPN before accessing your account dashboard.';
      if (elements.step2Text) elements.step2Text.textContent = 'Complete login or biometric 2FA from your personal home connection.';
      if (elements.solutionProofTag) elements.solutionProofTag.className = 'solution-proof-tag green';
      if (elements.proofStatusText) elements.proofStatusText.textContent = 'Direct connection: Not measured (Demo Profile)';
      if (elements.btnDirectVisit) elements.btnDirectVisit.textContent = 'Open Coinbase Directly ↗';

      if (elements.option2Badge) {
        elements.option2Badge.textContent = 'OPTION 2: STAY PROTECTED';
        elements.option2Badge.className = 'solution-badge-shield';
      }
      if (elements.option2Title) elements.option2Title.textContent = 'Use dedicated or clean-IP VPNs';
      if (elements.option2Desc) elements.option2Desc.textContent = 'Demonstration provider configurations for Coinbase:';
    } else {
      // Default Blocked or Friction
      if (elements.option1Badge) {
        elements.option1Badge.textContent = 'OPTION 1: FASTEST (INSTANT)';
        elements.option1Badge.className = 'solution-badge-fast';
      }
      if (elements.option1Title) elements.option1Title.textContent = 'Turn off your VPN & refresh';
      if (elements.option1Desc) elements.option1Desc.textContent = 'In this demonstration profile, direct connections load normally. Disconnecting or pausing your VPN will test reachability on your regular connection.';
      if (elements.step1Text) elements.step1Text.textContent = 'Disconnect or pause your active VPN connection.';
      if (elements.step2Text) elements.step2Text.textContent = 'Reload the page directly on your residential network.';
      if (elements.solutionProofTag) elements.solutionProofTag.className = 'solution-proof-tag green';
      if (elements.proofStatusText) elements.proofStatusText.textContent = 'Direct connection: Not measured (Demo Profile)';
      if (elements.btnDirectVisit) elements.btnDirectVisit.textContent = 'Open Site Directly ↗';

      if (elements.option2Badge) {
        elements.option2Badge.textContent = 'OPTION 2: VPN ALTERNATIVES';
        elements.option2Badge.className = 'solution-badge-shield';
      }
      if (elements.option2Title) elements.option2Title.textContent = 'VPN Compatibility Suggestions (Demo)';
      if (elements.option2Desc) elements.option2Desc.textContent = `Demonstration provider compatibility suggestions for ${result.serviceName || result.domain}:`;
    }

    // Solution 2 Rows (Rendered safely with renderWorkingVpnRow)
    if (elements.targetNameInline) elements.targetNameInline.textContent = result.serviceName || result.domain;
    if (elements.workingVpnsList && result.workingVpns) {
      let vpnHtml = '';
      result.workingVpns.forEach(vpn => {
        vpnHtml += renderWorkingVpnRow(vpn);
      });
      elements.workingVpnsList.innerHTML = vpnHtml;
    }

    // Community Reports
    const extraReports = getLocalCount(result.domain);
    if (elements.reportCount) {
      if (result.category === 'custom') {
        elements.reportCount.textContent = extraReports > 0 ? `${extraReports} local report(s)` : '0 submissions';
      } else {
        elements.reportCount.textContent = extraReports > 0 ? `Demo data (+${extraReports} local)` : 'Demo data';
      }
    }
    if (elements.communityPulseMsg) {
      if (result.category === 'custom') {
        elements.communityPulseMsg.innerHTML = `<strong id="reportCount">${extraReports > 0 ? extraReports + ' local report(s)' : 'No submissions yet'}</strong> &bull; Submit user feedback for this domain below.`;
      } else {
        elements.communityPulseMsg.innerHTML = `<strong id="reportCount">Demo profile</strong> &bull; Community feedback pipeline for this service`;
      }
    }

    // Technical details accordion
    if (elements.hypothesisText) elements.hypothesisText.textContent = 'Hypothesis: ' + result.hypothesis;

    // Scroll smoothly to result card without horizontal displacement
    const yOffset = elements.resultsSection.getBoundingClientRect().top + window.pageYOffset - 15;
    window.scrollTo({ top: Math.max(0, yOffset), left: 0, behavior: 'smooth' });
  }

  // --- REPORT MODAL ---
  function openReportModal(prefillDomain) {
    const domain = prefillDomain || state.currentDomain || '';
    if (elements.modalDomainInput) elements.modalDomainInput.value = domain;
    if (elements.modalFormState) elements.modalFormState.style.display = 'flex';
    if (elements.modalSuccessState) elements.modalSuccessState.style.display = 'none';
    if (elements.reportModal) elements.reportModal.style.display = 'flex';
  }

  function closeReportModal() {
    if (elements.reportModal) elements.reportModal.style.display = 'none';
  }

  // --- INITIALIZATION & EVENT LISTENERS ---
  function init() {
    // Enforce pure light theme
    localStorage.removeItem('vpn_theme_pref');
    document.body.classList.remove('dark-theme');

    initHeroPillLogos();
    renderServicesGrid('all');

    if (elements.brandLogoLink) {
      elements.brandLogoLink.addEventListener('click', (e) => {
        e.preventDefault();
        showHomeView();
      });
    }

    if (elements.btnHeaderCheck) {
      elements.btnHeaderCheck.addEventListener('click', () => {
        if (elements.homeBlocksSection && elements.homeBlocksSection.style.display === 'none') {
          showHomeView();
        } else {
          elements.domainInput.focus();
          elements.searchSection.scrollIntoView({ behavior: 'smooth' });
        }
      });
    }

    if (elements.btnHeaderGrid) {
      elements.btnHeaderGrid.addEventListener('click', () => {
        if (elements.homeBlocksSection && elements.homeBlocksSection.style.display === 'none') {
          showHomeView();
        }
        if (elements.monitoredServicesBlock) {
          elements.monitoredServicesBlock.scrollIntoView({ behavior: 'smooth' });
        }
      });
    }

    if (elements.btnHeaderReport) {
      elements.btnHeaderReport.addEventListener('click', () => openReportModal(state.currentDomain));
    }

    // Category Filter Buttons
    if (elements.categoryFiltersRow) {
      elements.categoryFiltersRow.querySelectorAll('.filter-btn').forEach(btn => {
        btn.addEventListener('click', () => {
          elements.categoryFiltersRow.querySelectorAll('.filter-btn').forEach(b => b.classList.remove('active'));
          btn.classList.add('active');
          const cat = btn.getAttribute('data-category') || 'all';
          state.currentCategory = cat;
          renderServicesGrid(cat);
        });
      });
    }

    // Back to Home button
    if (elements.btnBackToHome) {
      elements.btnBackToHome.addEventListener('click', showHomeView);
    }

    // Search Form Submit
    if (elements.checkForm) {
      elements.checkForm.addEventListener('submit', (e) => {
        e.preventDefault();
        runCheck(elements.domainInput.value);
      });
    }

    // Clear input button
    if (elements.domainInput && elements.clearBtn) {
      elements.domainInput.addEventListener('input', () => {
        elements.clearBtn.style.display = elements.domainInput.value ? 'flex' : 'none';
        if (elements.validationMsg) elements.validationMsg.style.display = 'none';
      });

      elements.clearBtn.addEventListener('click', () => {
        elements.domainInput.value = '';
        elements.clearBtn.style.display = 'none';
        elements.domainInput.focus();
      });
    }

    // Quick Pills Row in Hero
    if (elements.quickPillsRow) {
      elements.quickPillsRow.querySelectorAll('.quick-pill').forEach(btn => {
        btn.addEventListener('click', () => {
          const domain = btn.getAttribute('data-domain');
          if (domain) runCheck(domain);
        });
      });
    }

    // Result Action Buttons
    if (elements.btnReportTrigger) {
      elements.btnReportTrigger.addEventListener('click', () => openReportModal(state.currentDomain));
    }

    if (elements.btnCheckAnother) {
      elements.btnCheckAnother.addEventListener('click', showHomeView);
    }

    if (elements.btnShareResult) {
      elements.btnShareResult.addEventListener('click', () => {
        const shareUrl = window.location.href;
        if (navigator.clipboard && navigator.clipboard.writeText) {
          navigator.clipboard.writeText(shareUrl).then(() => {
            showToast('Result link copied to clipboard!');
          });
        } else {
          showToast(`URL: ${shareUrl}`);
        }
      });
    }

    // Report Modal Events
    if (elements.modalCloseBtn) {
      elements.modalCloseBtn.addEventListener('click', closeReportModal);
    }

    if (elements.modalSuccessCloseBtn) {
      elements.modalSuccessCloseBtn.addEventListener('click', closeReportModal);
    }

    if (elements.reportModal) {
      elements.reportModal.addEventListener('click', (e) => {
        if (e.target === elements.reportModal) closeReportModal();
      });
    }

    // Keyboard accessibility: ESC closes modal
    document.addEventListener('keydown', (e) => {
      if (e.key === 'Escape' && elements.reportModal && elements.reportModal.style.display !== 'none') {
        closeReportModal();
      }
    });

    if (elements.reportForm) {
      elements.reportForm.addEventListener('submit', async (e) => {
        e.preventDefault();
        const submitBtn = elements.reportForm.querySelector('button[type="submit"]');
        const origBtnText = submitBtn ? submitBtn.textContent : 'Submit Report';
        if (submitBtn) {
          submitBtn.disabled = true;
          submitBtn.textContent = 'Saving report...';
        }

        const domain = normalizeDomain(elements.modalDomainInput.value || state.currentDomain);
        const symptom = elements.reportSymptom ? elements.reportSymptom.value : 'General block';
        const providerRadio = elements.reportForm.querySelector('input[name="vpnProvider"]:checked');
        const provider = providerRadio ? providerRadio.value : (elements.reportProvider ? elements.reportProvider.value : 'Other');
        const region = elements.reportRegion ? elements.reportRegion.value : 'US - East';
        const details = elements.reportDetails ? elements.reportDetails.value.trim() : '';
        const disconnectRadio = elements.reportForm.querySelector('input[name="disconnectWorked"]:checked');
        const disconnectedWorked = disconnectRadio ? disconnectRadio.value : 'Yes';
        const evidence = elements.reportEvidence ? elements.reportEvidence.value.trim() : '';

        const report = {
          domain: domain,
          symptom: symptom,
          provider: provider,
          region: region,
          details: details,
          disconnectedWorked: disconnectedWorked,
          evidence: evidence,
          timestamp: new Date().toISOString()
        };

        // 1. Save to local storage for offline / standalone resilience
        saveLocalReport(report);

        // 2. Persist to Prototype Server API (reports.json) if connected
        let serverSaved = false;
        try {
          const res = await fetch('/api/reports', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify(report)
          });
          if (res.ok) {
            serverSaved = true;
            if (elements.modalSuccessDesc) {
              elements.modalSuccessDesc.textContent = 'Your report has been recorded in prototype server storage.';
            }
            showToast('Report saved to prototype server storage');
            console.log('[VPN Check] Report stored in local prototype server (reports.json).');
          }
        } catch (err) {
          console.log('[VPN Check] Running in standalone offline mode:', err.message);
        }

        if (!serverSaved) {
          if (elements.modalSuccessDesc) {
            elements.modalSuccessDesc.textContent = 'Your report has been saved locally in browser demonstration storage (offline prototype mode).';
          }
          showToast('Report saved to local browser storage');
        }

        // Restore button state
        if (submitBtn) {
          submitBtn.disabled = false;
          submitBtn.textContent = origBtnText;
        }

        // Update count on screen if currently viewing this domain
        if (state.currentData && state.currentData.domain.toLowerCase() === domain.toLowerCase()) {
          const extra = getLocalCount(domain);
          if (elements.reportCount) {
            elements.reportCount.textContent = extra > 0 ? `${extra} local report(s)` : '0 submissions';
          }
        }

        renderServicesGrid(state.currentCategory);

        // Show success state
        if (elements.modalFormState) elements.modalFormState.style.display = 'none';
        if (elements.modalSuccessState) elements.modalSuccessState.style.display = 'flex';
      });
    }

    // Initial Query / Hash Check (e.g. ?domain=netflix.com or #netflix.com)
    const urlParams = new URLSearchParams(window.location.search);
    const queryDomain = urlParams.get('domain') || urlParams.get('q');
    if (queryDomain) {
      runCheck(queryDomain);
    } else if (window.location.hash) {
      const hashDomain = window.location.hash.replace('#', '').trim();
      if (hashDomain) {
        runCheck(hashDomain);
      }
    }
  }

  // Run on DOM ready
  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', init);
  } else {
    init();
  }
})();
