import os
import base64
import re

base_dir = r"c:\Users\arbax\Downloads\Prototype"
current_conv_id = "3032b61f-a6cf-4a18-af31-464b02d2c35f"
artifact_dir = os.path.join(r"C:\Users\arbax\.gemini\antigravity\brain", current_conv_id)

html_path = os.path.join(base_dir, "index.html")
css_path = os.path.join(base_dir, "styles.css")
js_path = os.path.join(base_dir, "app.js")
fav_path = os.path.join(base_dir, "favicon.svg")
logo_path = os.path.join(base_dir, "vpn-logo.png")

with open(html_path, "r", encoding="utf-8") as f:
    html = f.read()

with open(css_path, "r", encoding="utf-8") as f:
    css = f.read()

with open(js_path, "r", encoding="utf-8") as f:
    js = f.read()

with open(fav_path, "r", encoding="utf-8") as f:
    fav = f.read()

with open(logo_path, "rb") as f:
    logo_bytes = f.read()

b64_logo = base64.b64encode(logo_bytes).decode("utf-8")

html = re.sub(r'<link rel="icon"[^>]*>', f'<link rel="icon" type="image/png" href="data:image/png;base64,{b64_logo}">', html)
html = re.sub(r'<link rel="apple-touch-icon"[^>]*>', f'<link rel="apple-touch-icon" href="data:image/png;base64,{b64_logo}">', html)
html = html.replace('<img src="vpn-logo.png"', f'<img src="data:image/png;base64,{b64_logo}"')
html = re.sub(r'<link rel="stylesheet" href="styles\.css[^"]*">', f'<style>\n{css}\n</style>', html)
html = html.replace('<script src="app.js"></script>', f'<script>\n{js}\n</script>')

# Ensure artifact directory exists
os.makedirs(artifact_dir, exist_ok=True)
target_file = os.path.join(artifact_dir, "vpn-access-check.html")
with open(target_file, "w", encoding="utf-8") as f:
    f.write(html)

local_bundle = os.path.join(base_dir, "bundled_preview.html")
with open(local_bundle, "w", encoding="utf-8") as f:
    f.write(html)

print(f"Bundled self-contained artifact at: {target_file} (Size: {len(html)} bytes)")
print(f"Bundled local preview copy at: {local_bundle} (Size: {len(html)} bytes)")
