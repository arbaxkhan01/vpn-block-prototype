import os
import subprocess
import shutil

chrome = r"C:\Program Files\Google\Chrome\Application\chrome.exe"
if not os.path.exists(chrome):
    chrome = r"C:\Program Files (x86)\Google\Chrome\Application\chrome.exe"

proto_dir = r"c:\Users\arbax\Downloads\Prototype"
artifact_dir = r"C:\Users\arbax\.gemini\antigravity\brain\3032b61f-a6cf-4a18-af31-464b02d2c35f"
os.makedirs(artifact_dir, exist_ok=True)

html_content = """<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>VPN Access Check — Backend &amp; Measurement Engine Technical Specification</title>
  <style>
    @page {
      size: A4 portrait;
      margin: 12mm 14mm 12mm 14mm;
      @bottom-right {
        content: counter(page);
        font-size: 8.5px;
        color: #94a3b8;
        font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif;
      }
    }
    * { box-sizing: border-box; margin: 0; padding: 0; }
    body {
      font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, Helvetica, Arial, sans-serif;
      color: #0f172a;
      background: #ffffff;
      line-height: 1.45;
      font-size: 9.5px;
    }
    .cover-page {
      min-height: 88vh;
      display: flex;
      flex-direction: column;
      justify-content: space-between;
      padding: 24px 8px;
    }
    .cover-header {
      border-left: 6px solid #2563eb;
      padding-left: 20px;
      margin-top: 36px;
    }
    .cover-badge {
      display: inline-block;
      background: #eff6ff;
      color: #1d4ed8;
      font-weight: 700;
      font-size: 10px;
      padding: 4px 10px;
      border-radius: 4px;
      text-transform: uppercase;
      letter-spacing: 0.5px;
      margin-bottom: 12px;
      border: 1px solid #bfdbfe;
    }
    h1.cover-title {
      font-size: 25px;
      font-weight: 800;
      color: #0f172a;
      line-height: 1.25;
      margin-bottom: 8px;
    }
    .cover-subtitle {
      font-size: 12.5px;
      color: #475569;
      font-weight: 400;
      max-width: 620px;
      line-height: 1.5;
    }
    .cover-meta-grid {
      display: grid;
      grid-template-columns: repeat(2, 1fr);
      gap: 12px;
      background: #f8fafc;
      border: 1px solid #e2e8f0;
      border-radius: 8px;
      padding: 16px;
      margin: 24px 0;
    }
    .meta-item { display: flex; flex-direction: column; gap: 2px; }
    .meta-label { font-size: 8px; text-transform: uppercase; letter-spacing: 0.5px; color: #64748b; font-weight: 600; }
    .meta-value { font-size: 10.5px; font-weight: 600; color: #0f172a; }
    .cover-summary-box {
      background: #ffffff;
      border: 1px solid #cbd5e1;
      border-radius: 8px;
      padding: 14px 18px;
      box-shadow: 0 1px 3px rgba(0,0,0,0.05);
    }
    .cover-summary-box h3 { font-size: 11px; color: #1e293b; margin-bottom: 6px; font-weight: 700; }
    .cover-summary-box p { font-size: 9.5px; color: #334155; line-height: 1.5; }
    .cover-footer {
      border-top: 1px solid #e2e8f0;
      padding-top: 12px;
      display: flex;
      justify-content: space-between;
      color: #94a3b8;
      font-size: 8.5px;
    }
    .page-break { page-break-before: always; }
    .content-page { padding: 10px 4px; }
    .page-header {
      display: flex;
      justify-content: space-between;
      align-items: center;
      border-bottom: 1px solid #e2e8f0;
      padding-bottom: 8px;
      margin-bottom: 14px;
    }
    .page-header-title { font-size: 9px; font-weight: 700; color: #64748b; text-transform: uppercase; letter-spacing: 0.5px; }
    .page-header-date { font-size: 8.5px; color: #94a3b8; }
    .section { margin-bottom: 16px; }
    h2 {
      font-size: 12.5px;
      font-weight: 700;
      color: #0f172a;
      margin-bottom: 8px;
      padding-bottom: 4px;
      border-bottom: 1.5px solid #2563eb;
      display: flex;
      justify-content: space-between;
      align-items: center;
    }
    h3 { font-size: 10.5px; font-weight: 700; color: #1e293b; margin: 10px 0 4px 0; }
    p { margin-bottom: 8px; color: #334155; line-height: 1.5; }
    ul, ol { margin-left: 16px; margin-bottom: 8px; color: #334155; }
    li { margin-bottom: 4px; line-height: 1.45; }
    code {
      font-family: ui-monospace, SFMono-Regular, Menlo, monospace;
      font-size: 8.5px;
      background: #f1f5f9;
      padding: 1.5px 4px;
      border-radius: 3px;
      color: #0f172a;
      border: 1px solid #e2e8f0;
    }
    .table-custom {
      width: 100%;
      border-collapse: collapse;
      margin: 10px 0 14px 0;
      font-size: 8.5px;
    }
    .table-custom th {
      background: #f8fafc;
      color: #475569;
      font-weight: 700;
      text-align: left;
      padding: 6px 8px;
      border: 1px solid #cbd5e1;
      font-size: 8px;
      text-transform: uppercase;
      letter-spacing: 0.3px;
    }
    .table-custom td {
      padding: 5px 8px;
      border: 1px solid #cbd5e1;
      color: #334155;
      vertical-align: top;
    }
    .table-custom tr:nth-child(even) { background: #f8fafc; }
    .badge-pass { display: inline-block; background: #dcfce7; color: #15803d; font-weight: 700; padding: 2px 6px; border-radius: 3px; font-size: 7.5px; border: 1px solid #bbf7d0; }
    .badge-info { display: inline-block; background: #eff6ff; color: #1d4ed8; font-weight: 700; padding: 2px 6px; border-radius: 3px; font-size: 7.5px; border: 1px solid #bfdbfe; }
    .badge-warning { display: inline-block; background: #fffbeb; color: #b45309; font-weight: 700; padding: 2px 6px; border-radius: 3px; font-size: 7.5px; border: 1px solid #fde68a; }
    .callout { background: #f8fafc; border-left: 4px solid #2563eb; padding: 8px 12px; border-radius: 0 6px 6px 0; margin: 10px 0; font-size: 9px; }
    .section-tag { font-size: 7.5px; font-weight: 600; background: #f1f5f9; color: #475569; padding: 2px 6px; border-radius: 3px; text-transform: uppercase; letter-spacing: 0.3px; }
  </style>
</head>
<body>

  <!-- COVER PAGE -->
  <div class="cover-page">
    <div class="cover-header">
      <div class="cover-badge">Backend &amp; Measurement Specification</div>
      <h1 class="cover-title">VPN Access Check Platform<br>Backend Engine Specification</h1>
      <p class="cover-subtitle">
        Technical specification for the active measurement engine, dual-probe baseline comparison pipeline, challenge fingerprinting classifier, REST API contracts, and telemetry database design.
      </p>
    </div>

    <div class="cover-meta-grid">
      <div class="meta-item">
        <span class="meta-label">Specification Scope</span>
        <span class="meta-value">Measurement Engine, Probe Execution &amp; Backend APIs</span>
      </div>
      <div class="meta-item">
        <span class="meta-label">Probe Execution Model</span>
        <span class="meta-value">Differential Dual-Probe Pipeline (VPN Egress vs Baseline Control)</span>
      </div>
      <div class="meta-item">
        <span class="meta-label">Baseline Node Architecture</span>
        <span class="meta-value">Owned / Consented Ordinary-User Baseline Nodes</span>
      </div>
      <div class="meta-item">
        <span class="meta-label">Security &amp; Data Governance</span>
        <span class="meta-value">Zero IP Storage &bull; SSRF Defenses &bull; Rate-Limited APIs</span>
      </div>
    </div>

    <div class="cover-summary-box">
      <h3>Executive Summary</h3>
      <p>
        This technical specification defines the architecture, protocol logic, and data structures required to operate the VPN Access Check measurement backend. The system executes automated differential diagnostic probes comparing commercial VPN egress behavior against calibrated, owned/consented ordinary-user baseline controls.
      </p>
      <p style="margin-top: 6px;">
        The specification details the five-stage measurement pipeline, edge challenge fingerprinting (WAF HTTP 403, Cloudflare Turnstile, Akamai Bot Manager), REST API schemas (including current prototype mock endpoints and production contracts), and time-series observation storage structures.
      </p>
    </div>

    <div class="cover-footer">
      <span>VPN.com Prototype Development &bull; Backend Technical Specification</span>
      <span>Document Ref: VPN-BE-SPEC-V05-2026</span>
    </div>
  </div>

  <!-- PAGE BREAK: CONTENT -->
  <div class="page-break"></div>
  <div class="content-page">
    <div class="page-header">
      <span class="page-header-title">Backend Specification &bull; Pipeline &amp; Differential Classification</span>
      <span class="page-header-date">September 29, 2026</span>
    </div>

    <div class="section">
      <h2>1. The Five-Stage Active Measurement Pipeline <span class="section-tag">Pipeline</span></h2>
      <p>
        The production measurement engine executes every domain diagnostic check through an asynchronous five-stage pipeline designed for low latency and high accuracy:
      </p>
      <ol>
        <li><strong>Input Sanitation &amp; SSRF Shielding</strong>: Canonicalizes input strings to public FQDNs. Enforces strict IP resolution filtering to block private/internal subnets (RFC 1918, RFC 3927, loopback addresses, AWS metadata endpoints <code>169.254.169.254</code>).</li>
        <li><strong>Baseline Control Probing</strong>: Dispatches a simultaneous HTTP/HTTPS request from an <strong>owned/consented ordinary-user baseline node</strong> to determine origin status (validating DNS resolution, TLS certificate, HTTP status code, and baseline latency).</li>
        <li><strong>VPN Multi-Egress Probing</strong>: Routes parallel diagnostic probes across configured commercial VPN egress interfaces (WireGuard/OpenVPN) in target geographic zones (US-East, US-West, EU-Central, UK-London, AP-Tokyo).</li>
        <li><strong>Differential Classification &amp; Fingerprinting</strong>: Compares the baseline response against VPN probe telemetry to determine whether divergences represent hard network drops, WAF access denial, challenge loops, or origin server failure.</li>
        <li><strong>Evidence Synthesis &amp; Persistence</strong>: Computes confidence scores based on observation density, updates the time-series cache, and serves formatted diagnostic payloads to the client.</li>
      </ol>
    </div>

    <div class="section">
      <h2>2. Differential Evaluation Logic Matrix <span class="section-tag">Decision Logic</span></h2>
      <p>
        The core engine evaluates probe outcomes using a strict differential truth table to prevent false attribution:
      </p>
      <table class="table-custom">
        <thead>
          <tr>
            <th style="width: 20%;">Baseline Control Result</th>
            <th style="width: 25%;">VPN Egress Probe Result</th>
            <th style="width: 20%;">Website Status</th>
            <th style="width: 20%;">VPN Accessibility</th>
            <th style="width: 15%;">Evidence Confidence</th>
          </tr>
        </thead>
        <tbody>
          <tr>
            <td>HTTP 200 / Clean Handshake</td>
            <td>HTTP 200 / Clean Handshake</td>
            <td><code>Online (Working)</code></td>
            <td><code>Works on VPN</code></td>
            <td><span class="badge-pass">Strong</span></td>
          </tr>
          <tr>
            <td>HTTP 200 / Clean Handshake</td>
            <td>HTTP 403 / Access Denied</td>
            <td><code>Online (Working)</code></td>
            <td><code>VPN Blocked (WAF)</code></td>
            <td><span class="badge-pass">Strong</span></td>
          </tr>
          <tr>
            <td>HTTP 200 / Clean Handshake</td>
            <td>TCP Reset / Connection Drop</td>
            <td><code>Online (Working)</code></td>
            <td><code>VPN Blocked (Drop)</code></td>
            <td><span class="badge-pass">Strong</span></td>
          </tr>
          <tr>
            <td>HTTP 200 / Clean Handshake</td>
            <td>Cloudflare Turnstile / CAPTCHA</td>
            <td><code>Online (Working)</code></td>
            <td><code>VPN Friction (Challenge)</code></td>
            <td><span class="badge-info">Moderate</span></td>
          </tr>
          <tr>
            <td>DNS Failure / HTTP 503 Outage</td>
            <td>DNS Failure / HTTP 503 Outage</td>
            <td><code>Site Unreachable</code></td>
            <td><strong>Unknown / Not Measurable</strong></td>
            <td><span class="badge-warning">Insufficient</span></td>
          </tr>
        </tbody>
      </table>
    </div>

    <div class="section">
      <h2>3. API Contract Specifications <span class="section-tag">API Schema</span></h2>
      <h3>Production Check Endpoint (Target Contract)</h3>
      <p><code>POST /api/v1/check</code></p>
      <p>Request Payload:</p>
      <code>{ "domain": "example.com", "region": "US-East", "providers": ["NordVPN", "ExpressVPN"] }</code>
      <p style="margin-top: 6px;">Response Payload (Standard Telemetry Schema):</p>
      <code>{
  "domain": "example.com",
  "testedUrl": "https://example.com/",
  "observationTime": "2026-09-29T12:00:00Z",
  "websiteStatus": "Online (Working)",
  "vpnAccessibility": "VPN Blocked",
  "evidenceStrength": "Strong evidence",
  "controlResult": "HTTP 200 OK (Clean baseline)",
  "vpnResult": "HTTP 403 Forbidden (Cloudflare WAF)",
  "region": "US-East (Ashburn)",
  "providerExit": "Commercial Egress ASN 14061",
  "challengeDetected": "None (Hard Drop)",
  "observationCount": 24,
  "freshness": "12m ago"
}</code>
    </div>

    <div class="section">
      <h2>4. Crowdsourced Reports Storage &amp; Anti-Abuse <span class="section-tag">Community Reports</span></h2>
      <p>
        The prototype supports community submission intake (<code>POST /api/reports</code>). In production, this service incorporates:
      </p>
      <ul>
        <li><strong>In-Memory Rate Limiting</strong>: Maximum 3 submissions per client per hour per target domain.</li>
        <li><strong>Cryptographic Honeypots</strong>: Hidden DOM form fields to deflect automated headless spam bots.</li>
        <li><strong>Strict Privacy Model</strong>: Client IP addresses are never recorded in reports database tables. Only target domain, selected provider, and differential outcome (<em>"Did disconnecting fix it?"</em>) are retained.</li>
      </ul>
    </div>
  </div>

</body>
</html>
"""

html_file = os.path.join(proto_dir, "VPN_Access_Check_Backend_Specification_Report.html")
pdf_local = os.path.join(proto_dir, "VPN_Access_Check_Backend_Specification_Report.pdf")
pdf_artifact = os.path.join(artifact_dir, "VPN_Access_Check_Backend_Specification_Report.pdf")

with open(html_file, "w", encoding="utf-8") as f:
    f.write(html_content)

cmd = [
    chrome,
    "--headless=new",
    "--disable-gpu",
    "--no-pdf-header-footer",
    f"--print-to-pdf={pdf_local}",
    html_file
]
subprocess.run(cmd, check=True)
shutil.copy2(pdf_local, pdf_artifact)

size = os.path.getsize(pdf_local)
print(f"[OK] Compiled: VPN_Access_Check_Backend_Specification_Report.pdf ({size:,} bytes)")
