import os
import subprocess
import shutil

chrome = r"C:\Program Files\Google\Chrome\Application\chrome.exe"
if not os.path.exists(chrome):
    chrome = r"C:\Program Files (x86)\Google\Chrome\Application\chrome.exe"

proto_dir = r"c:\Users\arbax\Downloads\Prototype"
artifact_dir = r"C:\Users\arbax\.gemini\antigravity\brain\3032b61f-a6cf-4a18-af31-464b02d2c35f"
os.makedirs(artifact_dir, exist_ok=True)

shared_css = """
  @page {
    size: A4 portrait;
    margin: 12mm 14mm 12mm 14mm;
    @bottom-right {
      content: counter(page);
      font-size: 8.5px;
      color: #94a3b8;
      font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif;
    }
  }

  * {
    box-sizing: border-box;
    margin: 0;
    padding: 0;
  }

  body {
    font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, Helvetica, Arial, sans-serif;
    color: #0f172a;
    background: #ffffff;
    line-height: 1.45;
    font-size: 9.5px;
  }

  .cover-page {
    min-height: 88vh;
    display: flex;
    flex-direction: column;
    justify-content: space-between;
    padding: 24px 8px 24px 8px;
  }

  .cover-header {
    border-left: 6px solid #2563eb;
    padding-left: 20px;
    margin-top: 32px;
  }

  .cover-badge {
    display: inline-block;
    background: #eff6ff;
    color: #1d4ed8;
    font-weight: 700;
    font-size: 10px;
    padding: 4px 10px;
    border-radius: 4px;
    text-transform: uppercase;
    letter-spacing: 0.5px;
    margin-bottom: 12px;
    border: 1px solid #bfdbfe;
  }

  h1.cover-title {
    font-size: 26px;
    font-weight: 800;
    color: #0f172a;
    line-height: 1.2;
    margin-bottom: 8px;
  }

  .cover-subtitle {
    font-size: 13px;
    color: #475569;
    font-weight: 400;
    max-width: 600px;
    line-height: 1.5;
  }

  .cover-meta-grid {
    display: grid;
    grid-template-columns: repeat(2, 1fr);
    gap: 12px;
    background: #f8fafc;
    border: 1px solid #e2e8f0;
    border-radius: 8px;
    padding: 16px;
    margin: 24px 0;
  }

  .meta-item {
    display: flex;
    flex-direction: column;
    gap: 2px;
  }

  .meta-label {
    font-size: 8px;
    text-transform: uppercase;
    letter-spacing: 0.5px;
    color: #64748b;
    font-weight: 600;
  }

  .meta-value {
    font-size: 10.5px;
    font-weight: 600;
    color: #0f172a;
  }

  .cover-summary-box {
    background: #ffffff;
    border: 1px solid #cbd5e1;
    border-radius: 8px;
    padding: 14px 18px;
    box-shadow: 0 1px 3px rgba(0,0,0,0.05);
  }

  .cover-summary-box h3 {
    font-size: 11px;
    color: #1e293b;
    margin-bottom: 6px;
    font-weight: 700;
  }

  .cover-summary-box p {
    font-size: 9.5px;
    color: #334155;
    line-height: 1.5;
  }

  .cover-footer {
    border-top: 1px solid #e2e8f0;
    padding-top: 12px;
    display: flex;
    justify-content: space-between;
    color: #94a3b8;
    font-size: 8.5px;
  }

  .page-break {
    page-break-before: always;
  }

  .content-page {
    padding: 10px 4px;
  }

  .page-header {
    display: flex;
    justify-content: space-between;
    align-items: center;
    border-bottom: 1px solid #e2e8f0;
    padding-bottom: 8px;
    margin-bottom: 14px;
  }

  .page-header-title {
    font-size: 9px;
    font-weight: 700;
    color: #64748b;
    text-transform: uppercase;
    letter-spacing: 0.5px;
  }

  .page-header-date {
    font-size: 8.5px;
    color: #94a3b8;
  }

  .section {
    margin-bottom: 16px;
  }

  h2 {
    font-size: 12.5px;
    font-weight: 700;
    color: #0f172a;
    margin-bottom: 8px;
    padding-bottom: 4px;
    border-bottom: 1.5px solid #2563eb;
    display: flex;
    justify-content: space-between;
    align-items: center;
  }

  h3 {
    font-size: 10.5px;
    font-weight: 700;
    color: #1e293b;
    margin: 10px 0 4px 0;
  }

  p {
    margin-bottom: 8px;
    color: #334155;
    line-height: 1.5;
  }

  ul, ol {
    margin-left: 16px;
    margin-bottom: 8px;
    color: #334155;
  }

  li {
    margin-bottom: 4px;
    line-height: 1.45;
  }

  code {
    font-family: ui-monospace, SFMono-Regular, Menlo, monospace;
    font-size: 8.5px;
    background: #f1f5f9;
    padding: 1.5px 4px;
    border-radius: 3px;
    color: #0f172a;
    border: 1px solid #e2e8f0;
  }

  .table-custom {
    width: 100%;
    border-collapse: collapse;
    margin: 10px 0 14px 0;
    font-size: 8.5px;
  }

  .table-custom th {
    background: #f8fafc;
    color: #475569;
    font-weight: 700;
    text-align: left;
    padding: 6px 8px;
    border: 1px solid #cbd5e1;
    font-size: 8px;
    text-transform: uppercase;
    letter-spacing: 0.3px;
  }

  .table-custom td {
    padding: 5px 8px;
    border: 1px solid #cbd5e1;
    color: #334155;
    vertical-align: top;
  }

  .table-custom tr:nth-child(even) {
    background: #f8fafc;
  }

  .badge-pass {
    display: inline-block;
    background: #dcfce7;
    color: #15803d;
    font-weight: 700;
    padding: 2px 6px;
    border-radius: 3px;
    font-size: 7.5px;
    border: 1px solid #bbf7d0;
  }

  .badge-info {
    display: inline-block;
    background: #eff6ff;
    color: #1d4ed8;
    font-weight: 700;
    padding: 2px 6px;
    border-radius: 3px;
    font-size: 7.5px;
    border: 1px solid #bfdbfe;
  }

  .badge-warning {
    display: inline-block;
    background: #fffbeb;
    color: #b45309;
    font-weight: 700;
    padding: 2px 6px;
    border-radius: 3px;
    font-size: 7.5px;
    border: 1px solid #fde68a;
  }

  .callout {
    background: #f8fafc;
    border-left: 4px solid #2563eb;
    padding: 8px 12px;
    border-radius: 0 6px 6px 0;
    margin: 10px 0;
    font-size: 9px;
  }

  .callout-success {
    background: #f0fdf4;
    border-left-color: #16a34a;
  }

  .callout-warning {
    background: #fffbeb;
    border-left-color: #d97706;
  }

  .section-tag {
    font-size: 7.5px;
    font-weight: 600;
    background: #f1f5f9;
    color: #475569;
    padding: 2px 6px;
    border-radius: 3px;
    text-transform: uppercase;
    letter-spacing: 0.3px;
  }
"""

def compile_pdf(html_text, filename_base):
    html_file = os.path.join(proto_dir, f"{filename_base}.html")
    pdf_local = os.path.join(proto_dir, f"{filename_base}.pdf")
    pdf_artifact = os.path.join(artifact_dir, f"{filename_base}.pdf")

    with open(html_file, "w", encoding="utf-8") as f:
        f.write(html_text)

    cmd = [
        chrome,
        "--headless=new",
        "--disable-gpu",
        "--no-pdf-header-footer",
        f"--print-to-pdf={pdf_local}",
        html_file
    ]
    subprocess.run(cmd, check=True)
    shutil.copy2(pdf_local, pdf_artifact)

    size = os.path.getsize(pdf_local)
    print(f"[OK] Compiled: {filename_base}.pdf ({size:,} bytes)")
    return pdf_local

print("PDF compilation utility ready.")
