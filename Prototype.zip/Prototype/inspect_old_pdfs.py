import os
import re

with open('build_all_separate_pdfs.py', 'r', encoding='utf-8') as f:
    text = f.read()

for m in re.finditer(r'pdf_local = os\.path\.join\(proto_dir, "([^"]+)"\)', text):
    print("Old generator target:", m.group(1))

titles = re.findall(r'<h1 class="cover-title">([^<]+)</h1>', text)
for t in titles:
    print("Cover title:", t.strip())
