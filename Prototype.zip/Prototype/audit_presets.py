import re

with open('app.js', 'r', encoding='utf-8') as f:
    js = f.read()

presets = re.findall(r'(\'[a-zA-Z0-9.-]+\':\s*\{[\s\S]*?\n    \})', js)
print(f'Found {len(presets)} presets in app.js:\n')

forbidden = [
    'licensing', 'fraud', 'aml', 'anti-scalper', 'blocks vpn connections',
    'enforce region', 'regional catalog', 'historical observation scenarios'
]

warnings = 0
for p in presets:
    name = re.search(r'serviceName:\s*\'([^\']+)\'', p)
    headline = re.search(r'headline:\s*\'([^\']+)\'', p)
    subtext = re.search(r'subtext:\s*\'([^\']+)\'', p)
    hypo = re.search(r'hypothesis:\s*\'([^\']+)\'', p)
    status = re.search(r'vpnStatus:\s*\'([^\']+)\'', p)
    p_name = name.group(1) if name else 'Unknown'
    print(f"Preset: {p_name}")
    print(f"  VPN Status: {status.group(1) if status else '?'}")
    print(f"  Headline: {headline.group(1) if headline else '?'}")
    print(f"  Subtext: {subtext.group(1) if subtext else '?'}")
    print(f"  Hypothesis: {hypo.group(1) if hypo else '?'}")
    for fw in forbidden:
        if fw in p.lower():
            print(f"  --> [WARNING] Forbidden phrase detected: '{fw}'")
            warnings += 1
    print("-" * 50)

print(f"\nAudit complete. Total forbidden phrase warnings: {warnings}")
