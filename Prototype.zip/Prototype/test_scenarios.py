import urllib.request
import json
import re

print("=== STEP 1: Testing Static Assets on HTTP Server ===")
base_url = "http://127.0.0.1:3000"
files_to_check = ["/", "/index.html", "/styles.css", "/app.js", "/favicon.svg"]

for f in files_to_check:
    url = base_url + f
    try:
        req = urllib.request.urlopen(url)
        content_type = req.headers.get("Content-Type")
        length = len(req.read())
        print(f"  [OK] {url} -> Status {req.status}, Size {length} bytes, Type {content_type}")
    except Exception as e:
        print(f"  [FAIL] {url} -> {e}")

print("\n=== STEP 2: Verifying JS Scenario Data & Determinism ===")
with open(r"c:\Users\arbax\Downloads\Prototype\app.js", "r", encoding="utf-8") as f:
    js_content = f.read()

# Verify preset domains exist in app.js
expected_presets = ["netflix.com", "ticketmaster.com", "github.com", "down-example.test", "obscure-site.xyz"]
for p in expected_presets:
    assert f"'{p}'" in js_content or f'"{p}"' in js_content, f"Missing preset: {p}"
    print(f"  [OK] Verified preset configured: {p}")

print("\n=== STEP 3: Verifying HTML Core Requirements ===")
with open(r"c:\Users\arbax\Downloads\Prototype\index.html", "r", encoding="utf-8") as f:
    html_content = f.read()

# Check for crucial principles and copy
assert "Is it down, or is your VPN being blocked?" in html_content, "Missing hero title"
assert "Did it work after disconnecting the VPN?" in html_content, "Missing crucial question in report modal"
assert "Service Availability" in html_content, "Missing service availability pillar"
assert "VPN Accessibility" in html_content, "Missing vpn accessibility pillar"
assert "Evidence Confidence" in html_content, "Missing evidence confidence pillar"
assert "Simulated Multi-Route Telemetry" in html_content, "Missing simulation disclaimer"
assert "Methodology" in html_content, "Missing methodology section"
assert "Hypothesis" in html_content, "Missing hypothesis label"
print("  [OK] All core product principles, pillars, and labels present in HTML.")

print("\n=== ALL SYSTEM TESTS PASSED CLEANLY! ===")
