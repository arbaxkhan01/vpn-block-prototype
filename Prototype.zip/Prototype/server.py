import http.server
import socketserver
import os
import json
import uuid
from datetime import datetime, timezone

PORT = 3000
DATA_FILE = os.path.join(r'c:\Users\arbax\Downloads\Prototype', 'reports.json')

def load_reports():
    if not os.path.exists(DATA_FILE):
        return []
    try:
        with open(DATA_FILE, 'r', encoding='utf-8') as f:
            return json.load(f)
    except Exception as e:
        print(f"Error loading reports: {e}")
        return []

def save_reports(reports):
    try:
        with open(DATA_FILE, 'w', encoding='utf-8') as f:
            json.dump(reports, f, indent=2)
        return True
    except Exception as e:
        print(f"Error saving reports: {e}")
        return False

class PrototypeServerHandler(http.server.SimpleHTTPRequestHandler):
    def end_headers(self):
        self.send_header('Cache-Control', 'no-store, no-cache, must-revalidate, max-age=0')
        self.send_header('Pragma', 'no-cache')
        self.send_header('Expires', '0')
        self.send_header('Access-Control-Allow-Origin', '*')
        self.send_header('Access-Control-Allow-Methods', 'GET, POST, OPTIONS')
        self.send_header('Access-Control-Allow-Headers', 'Content-Type')
        self.send_header('X-Content-Type-Options', 'nosniff')
        self.send_header('X-Frame-Options', 'DENY')
        self.send_header('Referrer-Policy', 'no-referrer')
        self.send_header('Permissions-Policy', 'geolocation=(), camera=(), microphone=()')
        self.send_header('Content-Security-Policy', "default-src 'self' 'unsafe-inline' data:; font-src 'self' https://fonts.gstatic.com data:; style-src 'self' 'unsafe-inline' https://fonts.googleapis.com; img-src 'self' data: blob:; connect-src 'self'; frame-ancestors 'none';")
        super().end_headers()

    def do_OPTIONS(self):
        self.send_response(200)
        self.end_headers()

    def do_HEAD(self):
        if self.path == '/api/reports' or self.path.startswith('/api/reports?'):
            reports = load_reports()
            body = json.dumps(reports).encode('utf-8')
            self.send_response(200)
            self.send_header('Content-Type', 'application/json; charset=utf-8')
            self.send_header('Content-Length', str(len(body)))
            self.end_headers()
            return
        if self.path == '/reports' or self.path == '/reports/':
            self.path = '/reports.html'
        super().do_HEAD()

    def do_GET(self):
        # Route: API Reports
        if self.path == '/api/reports' or self.path.startswith('/api/reports?'):
            reports = load_reports()
            body = json.dumps(reports).encode('utf-8')
            self.send_response(200)
            self.send_header('Content-Type', 'application/json; charset=utf-8')
            self.send_header('Content-Length', str(len(body)))
            self.end_headers()
            self.wfile.write(body)
            return

        # Route: Admin Reports View Shortcut
        if self.path == '/reports' or self.path == '/reports/':
            self.path = '/reports.html'

        super().do_GET()

    def do_POST(self):
        if self.path == '/api/reports':
            try:
                content_length = int(self.headers.get('Content-Length', 0))
                post_data = self.rfile.read(content_length).decode('utf-8')
                payload = json.loads(post_data)

                # Format report item
                report_id = f"rep_{uuid.uuid4().hex[:6]}"
                timestamp = payload.get('timestamp') or datetime.now(timezone.utc).isoformat()
                client_ip = self.client_address[0] if self.client_address else '127.0.0.1'

                new_report = {
                    "id": report_id,
                    "domain": payload.get('domain', 'unknown.com').lower().strip(),
                    "symptom": payload.get('symptom', 'General block'),
                    "provider": payload.get('provider', 'Other'),
                    "region": payload.get('region', 'US - East'),
                    "details": payload.get('details', ''),
                    "disconnectedWorked": payload.get('disconnectedWorked', 'Not tested'),
                    "evidence": payload.get('evidence', ''),
                    "clientIp": client_ip,
                    "timestamp": timestamp
                }

                # Load, append, save
                reports = load_reports()
                reports.insert(0, new_report) # Latest first
                save_reports(reports)

                response = {
                    "status": "success",
                    "message": "Report successfully stored in prototype storage (reports.json)",
                    "report": new_report,
                    "total_reports": len(reports)
                }
                body = json.dumps(response).encode('utf-8')

                self.send_response(201)
                self.send_header('Content-Type', 'application/json; charset=utf-8')
                self.send_header('Content-Length', str(len(body)))
                self.end_headers()
                self.wfile.write(body)
                print(f"[Backend] New report stored: {new_report['domain']} via {new_report['provider']} ({report_id})")
                return
            except Exception as e:
                err_resp = json.dumps({"status": "error", "message": str(e)}).encode('utf-8')
                self.send_response(400)
                self.send_header('Content-Type', 'application/json; charset=utf-8')
                self.send_header('Content-Length', str(len(err_resp)))
                self.end_headers()
                self.wfile.write(err_resp)
                return

        self.send_response(404)
        self.end_headers()

if __name__ == '__main__':
    os.chdir(r'c:\Users\arbax\Downloads\Prototype')
    socketserver.TCPServer.allow_reuse_address = True
    with socketserver.TCPServer(('127.0.0.1', PORT), PrototypeServerHandler) as httpd:
        print(f"VPN Access Check Server with Backend API running on http://127.0.0.1:{PORT}...")
        print(f" - Main App: http://127.0.0.1:{PORT}/")
        print(f" - Report Dashboard: http://127.0.0.1:{PORT}/reports.html")
        print(f" - Reports API: http://127.0.0.1:{PORT}/api/reports")
        try:
            httpd.serve_forever()
        except KeyboardInterrupt:
            pass
