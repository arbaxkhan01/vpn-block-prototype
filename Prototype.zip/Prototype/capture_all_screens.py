import os
import subprocess
import shutil

chrome = r"C:\Program Files\Google\Chrome\Application\chrome.exe"
if not os.path.exists(chrome):
    chrome = r"C:\Program Files (x86)\Google\Chrome\Application\chrome.exe"

proto_dir = r"c:\Users\arbax\Downloads\Prototype"
artifact_dir = r"C:\Users\arbax\.gemini\antigravity\brain\3032b61f-a6cf-4a18-af31-464b02d2c35f"
os.makedirs(artifact_dir, exist_ok=True)

targets = [
    # Responsive viewports for Home
    ("screen_v05_1440.png", "http://127.0.0.1:3000/", 1440, 900, 1000),
    ("screen_v05_1024.png", "http://127.0.0.1:3000/", 1024, 768, 1000),
    ("screen_v05_768.png", "http://127.0.0.1:3000/", 768, 1024, 1000),
    ("screen_v05_430.png", "http://127.0.0.1:3000/", 430, 932, 1000),
    ("screen_v05_390.png", "http://127.0.0.1:3000/", 390, 844, 1000),
    ("screen_v05_360.png", "http://127.0.0.1:3000/", 360, 780, 1000),

    # Result views with 3000ms virtual time budget
    ("screen_v05_result_netflix.png", "http://127.0.0.1:3000/?domain=netflix.com", 1280, 900, 3000),
    ("screen_v05_result_custom.png", "http://127.0.0.1:3000/?domain=myunknownsite.io", 1280, 900, 3000),
    ("screen_v05_result_outage.png", "http://127.0.0.1:3000/?domain=down-example.test", 1280, 900, 3000),

    # Reports log views
    ("screen_v05_reports.png", "http://127.0.0.1:3000/reports.html", 1440, 900, 1500),
    ("screen_v05_reports_390.png", "http://127.0.0.1:3000/reports.html", 390, 844, 1500),
    ("screen_v05_reports_360.png", "http://127.0.0.1:3000/reports.html", 360, 780, 1500),
]

print("Starting screenshot capture...")
for filename, url, width, height, budget in targets:
    out_local = os.path.join(proto_dir, filename)
    out_artifact = os.path.join(artifact_dir, filename)
    cmd = [
        chrome,
        "--headless=new",
        "--disable-gpu",
        f"--virtual-time-budget={budget}",
        f"--window-size={width},{height}",
        f"--screenshot={out_local}",
        url
    ]
    res = subprocess.run(cmd, capture_output=True, text=True)
    if os.path.exists(out_local):
        shutil.copy2(out_local, out_artifact)
        size = os.path.getsize(out_local)
        print(f"[OK] {filename:30} ({width}x{height}) -> {size:,} bytes")
    else:
        print(f"[FAIL] {filename:30} failed to capture! Return code: {res.returncode}")

print("\nScreenshot capture process complete!")
