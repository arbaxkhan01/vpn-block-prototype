import json
import re

with open('b64_logos_complete.json', 'r', encoding='utf-8') as f:
    b64_data = json.load(f)

with open('app.js', 'r', encoding='utf-8') as f:
    app_js = f.read()

# Generate javascript object for REAL_BRAND_LOGOS
js_logos = "  // --- AUTHENTIC OFFICIAL BRAND LOGOS (100% GENUINE HIGH-RES DATA URIS) ---\n"
js_logos += "  const REAL_BRAND_LOGOS = " + json.dumps(b64_data, indent=4) + ";\n"

# Replace the old BRAND_LOGOS definition in app.js
old_logos_pattern = r"  // --- BRAND SVG LOGO DICTIONARY.*?\n  };\n"
match = re.search(old_logos_pattern, app_js, re.DOTALL)
if match:
    app_js = app_js[:match.start()] + js_logos + app_js[match.end():]
    print("Replaced BRAND_LOGOS with REAL_BRAND_LOGOS successfully!")
else:
    print("Could not find old BRAND_LOGOS pattern via regex, trying alternative...")
    # Manual replacement around getBrandLogoHtml
    idx_start = app_js.find("// --- BRAND SVG LOGO DICTIONARY")
    idx_end = app_js.find("function getBrandLogoHtml(")
    if idx_start != -1 and idx_end != -1:
        app_js = app_js[:idx_start] + js_logos + "\n" + app_js[idx_end:]
        print("Manual index replacement of BRAND_LOGOS succeeded!")

# Now replace getBrandLogoHtml implementation
new_get_brand_logo = """  function getBrandLogoHtml(domain) {
    const clean = domain ? domain.toLowerCase().trim() : '';
    if (REAL_BRAND_LOGOS[clean]) {
      return `<img src="${REAL_BRAND_LOGOS[clean]}" alt="${clean} logo" class="brand-favicon-img" loading="eager">`;
    }
    // Partial matches
    if (clean.includes('netflix')) return `<img src="${REAL_BRAND_LOGOS['netflix.com']}" alt="Netflix" class="brand-favicon-img">`;
    if (clean.includes('ticketmaster')) return `<img src="${REAL_BRAND_LOGOS['ticketmaster.com']}" alt="Ticketmaster" class="brand-favicon-img">`;
    if (clean.includes('chatgpt') || clean.includes('openai')) return `<img src="${REAL_BRAND_LOGOS['chatgpt.com']}" alt="ChatGPT" class="brand-favicon-img">`;
    if (clean.includes('github')) return `<img src="${REAL_BRAND_LOGOS['github.com']}" alt="GitHub" class="brand-favicon-img">`;
    if (clean.includes('hulu')) return `<img src="${REAL_BRAND_LOGOS['hulu.com']}" alt="Hulu" class="brand-favicon-img">`;
    if (clean.includes('coinbase')) return `<img src="${REAL_BRAND_LOGOS['coinbase.com']}" alt="Coinbase" class="brand-favicon-img">`;
    if (clean.includes('disney')) return `<img src="${REAL_BRAND_LOGOS['disneyplus.com']}" alt="Disney+" class="brand-favicon-img">`;
    if (clean.includes('spotify')) return `<img src="${REAL_BRAND_LOGOS['spotify.com']}" alt="Spotify" class="brand-favicon-img">`;
    if (clean.includes('amazon')) return `<img src="${REAL_BRAND_LOGOS['amazon.com']}" alt="Amazon" class="brand-favicon-img">`;
    if (clean.includes('down') || clean.includes('outage')) return `<img src="${REAL_BRAND_LOGOS['down-example.test']}" alt="Outage" class="brand-favicon-img">`;

    // High-res Google/DuckDuckGo CDN fallback for any custom user-entered website
    return `<img src="https://www.google.com/s2/favicons?domain=${clean}&sz=128" onerror="this.src='https://icons.duckduckgo.com/ip3/${clean}.ico'; this.onerror=function(){this.src='${REAL_BRAND_LOGOS['generic']}';};" alt="${clean} logo" class="brand-favicon-img">`;
  }"""

old_fn_pattern = r"  function getBrandLogoHtml\(domain\) \{.*?\n  \}"
app_js = re.sub(old_fn_pattern, new_get_brand_logo, app_js, flags=re.DOTALL)

# Update VPN logo in displayResult
old_vpn_snippet = r"const logoSvg = BRAND_LOGOS\[vpnLogoKey\] \|\| BRAND_LOGOS\.generic;\s*vpnHtml \+= `\s*<div class=\"working-vpn-row\">\s*\$\{logoSvg\}"
new_vpn_snippet = """const logoSrc = REAL_BRAND_LOGOS[vpnLogoKey] || REAL_BRAND_LOGOS.generic;
        vpnHtml += `
          <div class="working-vpn-row">
            <img src="${logoSrc}" alt="${vpn.name}" class="vpn-logo-img">"""

app_js = re.sub(old_vpn_snippet, new_vpn_snippet, app_js)

with open('app.js', 'w', encoding='utf-8') as f:
    f.write(app_js)

print("Updated app.js with genuine official logos!")
