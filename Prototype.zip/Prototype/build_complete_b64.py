import json

with open('b64_logos.json', 'r', encoding='utf-8') as f:
    b64 = json.load(f)

# Outage warning SVG data URL
outage_svg = '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24"><rect width="24" height="24" rx="5" fill="#EF4444"/><path d="M12 7v6m0 3.5v.5" stroke="#FFFFFF" stroke-width="2.2" stroke-linecap="round"/></svg>'
b64['down-example.test'] = 'data:image/svg+xml;utf8,' + outage_svg.replace('#', '%23')

# Generic globe SVG data URL
generic_svg = '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24"><rect width="24" height="24" rx="5" fill="#64748B"/><circle cx="12" cy="12" r="6" stroke="#FFFFFF" stroke-width="1.8"/><path d="M12 6c-2 2-2.5 3.8-2.5 6s.5 4 2.5 6m0-12c2 2 2.5 3.8 2.5 6s-.5 4-2.5 6M6 12h12" stroke="#FFFFFF" stroke-width="1.4"/></svg>'
b64['generic'] = 'data:image/svg+xml;utf8,' + generic_svg.replace('#', '%23')

with open('b64_logos_complete.json', 'w', encoding='utf-8') as f:
    json.dump(b64, f, indent=2)

print(f"Generated b64_logos_complete.json with {len(b64)} authentic icons!")
